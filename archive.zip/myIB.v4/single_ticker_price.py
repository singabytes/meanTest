import pandas as pd
import logging

import helpers.marketdata.yahoo

start_date = '2010-01-01'
end_date = '2021-01-01'

ticker = 'WLTW'

#Test Yahoo query on IBM :
#Nov 19, 2021	116.49	116.56	115.27	116.05	114.67	5,380,200

md = helpers.marketdata.yahoo.marketdata(ticker = ticker, start_date = start_date, end_date = end_date)

date_start = md.index[0].strftime('%Y-%m-%d')
date_end = md.index[-1].strftime('%Y-%m-%d')

print('{} - {} to {}'.format(ticker, start_date, end_date))
