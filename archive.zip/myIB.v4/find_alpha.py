import pandas as pd
import logging

import helpers.marketdata.yahoo
import helpers.indicators.elhers as indic
import helpers.reports.alpha_report as report
import talib
import matplotlib.pyplot as plt
import numpy as np
import datetime
import math

logger = logging.getLogger(__name__)
#format = '[%(filename)s:%(lineno)s] %(message)s'
format = '%(asctime)s;%(levelname)s;%(message)s'
logging.basicConfig(filename = 'apply_strategy.log', filemode = 'w', format = format)
logger.setLevel(logging.DEBUG)

# get clean ticker
path = './data/yahoo/clean/'

filename = 'saved_ticker.csv'
tickers = pd.read_csv(path + filename, header = None)

signal_all = []
gain_all = []
ticker_all = []
index_all = []
date_entry_all = []
date_exit_all = []
prices_entry_all = []
prices_exit_all = []
stoch_entry_all = []
holding_period_all = []

tickers = ['ATO','ALL','AVY']

for ticker in tickers:
    print(ticker)
    prices = pd.read_csv(path + ticker + '.csv', index_col = 'date')

    #
    # high time frame - weekly
    #
    index_weekly = []
    index_daily = prices.index
    for i in index_daily:
        if datetime.datetime.strptime(i, '%Y-%m-%d').weekday() == 2: # wednesday
            index_weekly.append(i)
    # reindex
    prices_weekly = prices.reindex(index_weekly)
    #indicator
    prices_weekly['itrend_weekly'] = indic.compute_instTrend(prices_weekly.close, 0.31)
    #back to prices
    prices = prices.reset_index().merge(prices_weekly, how = 'left').set_index('date')
    prices['itrend_weekly'] = prices.itrend_weekly.fillna(method = 'ffill')
    #
    # end - high time frame - weekly
    #

    ema13 = talib.EMA(prices.close, 13)
    ema26 = talib.EMA(prices.close, 26)
    itrend_fast = indic.compute_instTrend(prices.close, 0.31)
    itrend_slow = indic.compute_instTrend(prices.close, 0.038)
    stoch_slowk, stoch_slowd = talib.STOCH(prices.high, prices.low, prices.close, fastk_period=14, slowk_period=3, slowk_matype=0, slowd_period=5, slowd_matype=0)

    prices['ema_fast'] = ema13.tolist()
    prices['ema_slow'] = ema26.tolist()
    prices['stoch'] = (stoch_slowk - stoch_slowd).tolist()
    prices['stochK'] = stoch_slowk.tolist()
    prices['itrend_fast'] = itrend_fast
    prices['itrend_slow'] = itrend_slow
    prices.ema_fast = prices.ema_fast.fillna(prices.close)
    prices.ema_slow = prices.ema_slow.fillna(prices.close)
    prices.stoch = prices.stoch.fillna(prices.close)
    prices.stoch = prices.stoch.fillna(prices.close)

    signal_daily = []
    signal_weekly = []

    for i in range(0, len(prices.close)):
        s_daily = 0.8
        if i == 0:
            s_daily = 0.8
        elif prices.itrend_fast[i-1] > prices.itrend_fast[i]:
            s_daily = -0.8
        signal_daily.append(s_daily)

        s_weekly = 0.8
        if i == 0:
            s_weekly = 0.8
        elif prices.itrend_weekly[i - 1] == prices.itrend_weekly[i]:
            s_weekly = signal_weekly[i-1] # price is flat intra-week
        elif prices.itrend_weekly[i - 1] > prices.itrend_weekly[i]:
            s_weekly = -0.8
        signal_weekly.append(s_weekly)

    prices['signal_daily'] = signal_daily
    prices['signal_weekly'] = signal_weekly

    in_market = False
    for i in range(300, len(prices.close) - 10):
        signal_aux = (prices.stochK[i] > 10) and (prices.stochK[i] < 90)
        signal_aux = True

        if (in_market is False) and (prices.signal_daily[i] > 0) and signal_aux and (prices.stoch[i] > 0): # and (prices.signal_weekly[i] > 0):# and (prices.stoch[i] > 0):
            buy_i = i+2
            in_market = True

        #if (in_market is True) and ((prices.close[i] / prices.close[buy_i] -1.) * 100. < -100.0):
        #    in_market = False
        #    signal_all.append(signal_daily[buy_i])
        #    g = (prices.close[i] / prices.close[buy_i] -1.) * 100.
        #    gain_all.append(g)
        #    date_entry_all.append(prices.index[buy_i])
        #    date_exit_all.append(prices.index[i])
        #    prices_entry_all.append(prices.close[buy_i])
        #    prices_exit_all.append(prices.close[i])
        #    stoch_entry_all.append(prices.stoch[buy_i])
        #    ticker_all.append(ticker)

        if (in_market is True) and (prices.signal_daily[i] < 0):
            in_market = False
            signal_all.append(signal_daily[buy_i])
            g = (prices.close[i] / prices.close[buy_i] -1.) * 100.
            gain_all.append(g)
            date_entry_all.append(prices.index[buy_i])
            date_exit_all.append(prices.index[i])
            prices_entry_all.append(prices.close[buy_i])
            prices_exit_all.append(prices.close[i])
            stoch_entry_all.append(prices.stoch[buy_i])
            ticker_all.append(ticker)

            d1 = datetime.datetime.strptime(prices.index[buy_i], '%Y-%m-%d')
            d2 = datetime.datetime.strptime(prices.index[i], '%Y-%m-%d')
            holding_period_all.append((d2 - d1).days)

data = {'date': date_exit_all, 'ticker': ticker_all, 'signal_strategy': signal_all, 'gain': gain_all,
        'date_entry': date_entry_all, 'date_exit': date_exit_all,
        'prices_entry': prices_entry_all, 'prices_exit': prices_exit_all,
        'stoch_entry': stoch_entry_all, 'holding_period': holding_period_all}
results = pd.DataFrame(data = data).set_index('date')

#merge back result sto prices
prices = prices.reset_index().merge(results.reset_index(), how = 'left', on = 'date').set_index('date')

plt.scatter(results.signal_strategy, results.gain)
signal_min = math.floor(results.signal_strategy.min())
signal_max = math.ceil(results.signal_strategy.max())

nb_steps = 50
steps = (signal_max - signal_min) / nb_steps

xx = []
yy = []
yyp = []
yym = []

for i in range(0, nb_steps):
    s = signal_min + i * steps
    std = results.gain.loc[(results.signal_strategy >= s) & (results.signal_strategy <= s + steps)].std()
    avg = results.gain.loc[(results.signal_strategy >= s) & (results.signal_strategy <= s + steps)].mean()
    if math.isnan(avg):
        continue
    xx.append(s)
    yy.append(avg)
    yyp.append(avg + 2. * std)
    yym.append(avg - 2. * std)

plt.plot(xx, yy, 'm*')
plt.plot(xx, yyp, 'm-')
plt.plot(xx, yym, 'm-')
plt.axhline(y = 0., color = 'b', linestyle = '-')

z = np.polyfit(xx, yy, 1)
p = np.poly1d(z)
plt.plot(xx, p(xx), "r-")
plt.show()

plt.figure()
plt = prices.gain.plot()
prices.gain.plot()
prices.close.plot()
prices.itrend_fast.plot()
week_p = prices[prices.signal_weekly > 0.5].index
#for i in week_p:
#    plt.axvline(prices.index.get_loc(i), color = 'g', alpha = 0.03)
daily_p = prices[prices.signal_daily > 0.5].index
#for i in daily_p:
#    plt.axvline(prices.index.get_loc(i), color = 'm', alpha = 0.03)

report.print_alpha_report(results)