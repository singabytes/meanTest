import pandas as pd
import logging

import helpers.marketdata.yahoo
import helpers.indicators.elhers as indic
import helpers.reports.alpha_report as report
import talib
import matplotlib.pyplot as plt
import numpy as np
import datetime
import math

logger = logging.getLogger(__name__)
#format = '[%(filename)s:%(lineno)s] %(message)s'
format = '%(asctime)s;%(levelname)s;%(message)s'
logging.basicConfig(filename = 'apply_strategy.log', filemode = 'w', format = format)
logger.setLevel(logging.DEBUG)

# get clean ticker
path = './data/yahoo/clean/'

filename = 'saved_ticker.csv'
tickers = pd.read_csv(path + filename, header = None)

signal_all = []
gain_all = []
ticker_all = []
index_all = []
date_entry_all = []
date_exit_all = []
prices_entry_all = []
prices_exit_all = []
stoch_entry_all = []
holding_period_all = []

#tickers = ['ATO','ALL','AVY']

for ticker in tickers[0]:
    print(ticker)
    prices = pd.read_csv(path + ticker + '.csv', index_col = 'date')

    in_market = False
    for i in range(300, len(prices.close) - 10):
        #signal_aux = (prices.stochK[i] > 10) and (prices.stochK[i] < 90)

        #signal1 = prices['high'][i] > prices['close'][i]
        #signal2 = prices['low'][i-2] > prices['low'][i]
        #signal3 = prices['high'][i-1] > prices['high'][i]
        #signal4 = prices['high'][i-2] > prices['high'][i-1]
        #signal5 = prices['low'][i] > prices['low'][i-1]
        #signal6 = prices['close'][i] > prices['low'][i-2]
        #signal7 = True

        signal1 = prices['high'][i] > prices['low'][i-1]
        signal2 = prices['low'][i - 2] > prices['high'][i]
        signal3 = prices['high'][i - 1] > prices['low'][i-2]
        signal4 = prices['high'][i - 2] > prices['low'][i - 3]
        signal5 = prices['low'][i-1] > prices['low'][i - 0]
        signal6 = prices['low'][i-3] > prices['high'][i - 1]
        signal7 = prices['high'][i - 3] > prices['high'][i - 2]

        signal8 = prices.close[i] > prices.open[i]
        signal9 = prices.close[i-1] > prices.open[i-1]
        signal10 = prices.close[i-2] > prices.open[i-2]
        signal11 = prices.close[i-3] < prices.open[i-3]
        signal_aux = signal8 and signal9 and signal10 and signal11

        if signal1 and signal2 and signal3 and signal4 and signal5 and signal6 and signal7 and signal11:
            buy = prices['open'][i+1]
            if (prices.open[i+1] / prices.low[i+1] - 1.) * 100. < - 30.:
                sell = prices.low[i + 1]
            elif (prices.open[i+1] / prices.low[i+2] - 1.) * 100. < - 30.:
                sell = prices.low[i + 2]
            elif (prices.open[i+1] / prices.low[i+3] - 1.) * 100. < - 30.:
                sell = prices.low[i + 3]
            else:
                sell = prices['close'][i + 3]

            print(ticker, prices.index[i+1], prices.index[i+3], buy, sell)

            ticker_all.append(ticker)
            gain_all.append((sell / buy - 1.) * 100.)
            signal_all.append(0)
            date_entry_all.append(prices.index[i+1])
            date_exit_all.append(prices.index[i+1])
            prices_entry_all.append(buy)
            prices_exit_all.append(sell)
            stoch_entry_all.append(0)
            holding_period_all.append(0)

            #d1 = datetime.datetime.strptime(prices.index[i], '%Y-%m-%d')
            #d2 = datetime.datetime.strptime(prices.index[i], '%Y-%m-%d')
            #holding_period_all.append((d2 - d1).days)

data = {'date': date_exit_all, 'ticker': ticker_all, 'signal_strategy': signal_all, 'gain': gain_all,
        'date_entry': date_entry_all, 'date_exit': date_exit_all,
        'prices_entry': prices_entry_all, 'prices_exit': prices_exit_all,
        'stoch_entry': stoch_entry_all, 'holding_period': holding_period_all}

results = pd.DataFrame(data = data).set_index('date')

results.gain.mean()
results.gain.std()
