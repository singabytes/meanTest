import pandas as pd
import logging

import helpers.marketdata.yahoo
import helpers.indicators.elhers as indic
import talib
import matplotlib.pyplot as plt
import numpy as np
import datetime
import math

def find_entries(tmp, what):
    res = []
    for i in tmp.index:
        if what in i:
            res.append(True)
        else:
            res.append(False)
    return res

def print_alpha_report(results):

    print('Number of entries : {}'.format(len(results.gain)))

    print('Gain = {0} | Std = {1}'.format(results.gain.mean(), results.gain.std()))
    for year in ['2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020']:
        filter = find_entries(results, year)
        print('{0} : Gain = {1}'.format(year, results.gain.loc[filter].mean()))

    holding_length = []
    stoch_value_entry = []
    gain = []
    for i in results.index:
        date_entry = results.date_entry.loc[results.index == i].values[0]
        date_exit = results.date_exit.loc[results.index == i].values[0]
        d1 = datetime.datetime.strptime(date_entry, '%Y-%m-%d')
        d2 = datetime.datetime.strptime(date_exit, '%Y-%m-%d')
        holding_length.append((d2-d1).days)

        stoch_value_entry.append(results.stoch_entry.loc[results.index == i].values[0])
        gain.append(results.gain.loc[results.index == i].values[0])

    plt.figure()
    plt.scatter(gain, holding_length, color = 'b')
    plt.scatter(gain, stoch_value_entry, color = 'g')


