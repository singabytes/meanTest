#!/usr/bin/env python3
# -*- coding: utf-8 -*-

###
# Historical data from Yahoo
###

from yahooquery import Ticker

import helpers.marketdata.utils.date as helper_date

# https://yahooquery.dpguthrie.com/guide/ticker/historical/
    
def marketdata(ticker, period = '1y', interval = '1d', start_date = None, 
                     end_date = None, adj_timezone = False, adj_ohlc = False):
    
    req = Ticker(ticker)
    
    # need to add one day to get correct days
    if (start_date is not None) or (end_date is not None):
        start_date = helper_date.add_days_to_date(
            date = helper_date.convert_to_datetime(start_date), nb_days = 1)
        end_date = helper_date.add_days_to_date(
            date = helper_date.convert_to_datetime(end_date), nb_days = 1)

    # pull the data from Yahoo
    history= req.history(period = period, interval = interval, start = start_date, 
                         end = end_date, adj_timezone = adj_timezone, 
                         adj_ohlc = adj_ohlc)
    
    #print(history['close'], history['adjclose'])

    # dataframe as multi index
    # MultiIndex([('fb', 2012-05-18),
    # Drop the ticker and make index the date
    new_index = []
    for i in history.index:
        new_index.append(i[1])
    
    history['date'] = new_index
    history.set_index('date', inplace=True)
    return history

