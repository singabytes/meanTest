import math

def compute_decycler(array): ### TO CHECK
    highpassLength = 2.0

    alphaArg = 2 * math.pi / (highpassLength * math.sqrt(2))
    alpha = 0.0
    if (math.cos(alphaArg) != 0):
        alpha = (math.cos(alphaArg) + math.sin(alphaArg) - 1) / math.cos(alphaArg)
    else:
        print('*** Error os(alphaArg) == 0 ***')
    print(alpha)
    alpha = 0.0380388

    hp = []
    hp.append(0)
    hp.append(0)
    for i in range(2, len(array)):
        temp = (1 - (alpha / 2)) ** 2 * (array[i] - 2 * array[i - 1] + array[i - 2])
        + 2 * (1 - alpha) * hp[i - 1] - (1 - alpha) ** 2 * hp[i - 2]
        hp.append(temp)
    decycler = []
    for i in range(0, len(array)):
        decycler.append(array[i] - hp[i])
    return decycler


def compute_instTrend(array, alpha_coef): # alpha = 0.038 or 0.07
    highpassLength = 2.0

    alphaArg = 2 * math.pi / (highpassLength * math.sqrt(2))

    alpha = 0.0
    if (math.cos(alphaArg) != 0):
        alpha = (math.cos(alphaArg) + math.sin(alphaArg) - 1) / math.cos(alphaArg)
    else:
        print('*** Error os(alphaArg) == 0 ***')

    alpha = alpha_coef

    iTrend = []
    iTrend.append(0)
    iTrend.append(0)

    for i in range(2, len(array)):
        temp1 = (alpha - alpha * 0.25 * alpha) * array[i]
        temp2 = + 0.5 * alpha * alpha * array[i - 1]
        temp3 = - (alpha - .75 * alpha * alpha) * array[i - 2]
        temp4 = 2 * (1 - alpha) * iTrend[i - 1] - (1 - alpha) * (1 - alpha) * iTrend[i - 2]
        temp = temp1 + temp2 + temp3 + temp4
        iTrend.append(temp)
    return iTrend
