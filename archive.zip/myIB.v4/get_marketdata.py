import helpers.marketdata.yahoo
import helpers.marketdata.investing

from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.arima_process import ArmaProcess
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import r2_score

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
#import seaborn
#import statsmodels.tsa.stattools as stattools
#from fracdiff import Fracdiff, FracdiffStat, fdiff
#from pandas.plotting import register_matplotlib_converters
import statsmodels.api as sm

start_date = '2021-11-01'
end_date = '2021-11-15'


start_date = '2000-01-01'
end_date = '2022-01-01'

ticker = 'ibm'

md1 = helpers.marketdata.yahoo.marketdata(ticker = ticker, start_date = start_date, end_date = end_date)

path = "/home/patrick/algo/carver/pysystemtrade/data/futures/adjusted_prices_csv/"
file = open(path + 'eq' + ticker + '.csv','w')

for i in range(0, len(md1.index)):
    date = str(md1.index[i]) + " 00:00:00"
    file.write(date + ',' + str(md1['close'][i]) + '\n')
file.close()
    
#md2 = helpers.marketdata.yahoo.marketdata(ticker = 'ibm', period = '1y', interval = '1d')

#print(md1)
#print(md2)

#md3 = helpers.marketdata.investing.marketdata(ticker = 'ibm', start_date = start_date, end_date = end_date)
#print(md3)

# # Augmented dickey fulley
# result = adfuller(md1['close'])
# print('Test stat: {}\np-value: {}\nLags: {}\nNum obs:{}' 
#       .format(result[0], result[1], result[2], result[3]))

# # Augmented dickey fulley
# ret = (md1['close'].shift(-1) - md1['close']).fillna(0)
# result = adfuller(ret)
# print('Test stat: {}\np-value: {}\nLags: {}\nNum obs:{}' 
#       .format(result[0], result[1], result[2], result[3]))

# # Plot acf
# fig = plot_acf(md1['close'], lags = 100)
# fig.set_size_inches(12, 6)

# # Plot pacf
# fig = plot_pacf(md1['close'], lags = 100)
# fig.set_size_inches(12, 6)
#size = 1000
#white_noise = np.random.normal(loc = 0, scale = 1, size = size)

#ret = (md1['close'].shift(-1) - md1['close']).fillna(0)
#test = sm.stats.acorr_ljungbox(ret, lags=[20])
#print(test)
#test = sm.stats.acorr_ljungbox(md1['close'], lags=[20])
#print(test)
#print('white noise')
#test = sm.stats.acorr_ljungbox(white_noise, lags=[20])
#print(test)

#print('arma')
#ar1 = np.array([1, 0.33])
#ma1 = np.array([1, 0.9])
#simulated_ARMA_data = ArmaProcess(ar1, ma1).generate_sample(nsample=1000)
#test = sm.stats.acorr_ljungbox(simulated_ARMA_data, lags=[20])
#print(test)


# fit model
#model = ARIMA(ret[0:len(ret)-10], order=(20,0,1))
#model_fit = model.fit()
# print summary of fit model
#print(model_fit.summary())
#forecast = model_fit.forecast()
#print(forecast, ret[len(ret)-10])



#start_index = len(ret)-10
#end_index = len(ret)
#forecast = model_fit.predict(start=start_index, end=end_index)
#print(forecast)

#model_fit.plot_predict(dynamic=False)
#plt.show()

#r2 = r2_score(ret[len(ret)-10:len(ret)], forecast)
#print('r2 score for perfect model is', r2)

# fracdiff
#plt.figure(figsize=(24, 24))
#plt.tight_layout()
#plt.subplots_adjust(hspace=0.4)

#data = md1['close']
#for i, d in enumerate(np.linspace(0.1, 0.9, 9)):
#    diff = fdiff(data, d, mode="valid")
#    diff = pd.Series(diff, index=data.index[-diff.size :])
#    plt.subplot(9, 1, i + 1)
#    plt.title(f"ticker, {d:.1f}th differentiated")
#    plt.plot(diff, linewidth=0.4)
#plt.show()


