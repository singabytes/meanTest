import pandas as pd
import logging

import helpers.marketdata.yahoo
import helpers.indicators.elhers as indic
import talib
import matplotlib.pyplot as plt
import numpy as np

logger = logging.getLogger(__name__)
#format = '[%(filename)s:%(lineno)s] %(message)s'
format = '%(asctime)s;%(levelname)s;%(message)s'
logging.basicConfig(filename = 'apply_strategy.log', filemode = 'w', format = format)
logger.setLevel(logging.DEBUG)

# reference
# CSCO
# close - iTrend - decycler
# 2020-12-01 - 42.05 - 40.13 - 38.47
# 2020-12-02 - 42.39 - 40.49 - 38.74
# 2020-12-03 - 42.60 - 40.84 - 39.02
# 2020-12-04 - 42.86 - 41.19 - 39.29

# 2021-12-01 - 54.71 - 55.13 - 55.65
# 2021-12-02 - 55.82 - 55.13 - 55.63
# 2021-12-03 - 55.90 - 55.21 - 55.65
# 2021-12-06 - 56.63 - 55.34 - 55.70
# 2021-12-07 - 57.74 - 55.58 - 55.82

path = '../data/yahoo/clean/'
ticker = 'CSCO'
prices = pd.read_csv(path + ticker + '.csv')

close = prices['adjclose']
ema13 = talib.EMA(close, 13)
ema26 = talib.EMA(close, 26)
itrend_quick = indic.compute_instTrend(close, 0.07)
itrend_slow = indic.compute_instTrend(close, 0.038)
prices['ema13'] = ema13.tolist()
prices['ema26'] = ema26.tolist()
prices['itrend_quick'] = itrend_quick
prices['itrend_slow'] = itrend_slow

dates = ['2020-12-01', '2020-12-02', '2020-12-03', '2020-12-04']
for d in dates:
    cl = prices.loc[prices['date'] == d]['adjclose'].values[0]
    it = prices.loc[prices['date'] == d]['itrend_slow'].values[0]
    de = prices.loc[prices['date'] == d]['itrend_quick'].values[0]
    print(d, cl, it, de)

