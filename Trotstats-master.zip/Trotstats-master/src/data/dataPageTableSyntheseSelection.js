import React from "react";
import Rating from '@material-ui/lab/Rating';

export const testData = [
  {"id":16313,"selec":3418,"type":"SG","tck":18,"reussite":5.6,"rde":79.2,"solde":14.26},{"id":16323,"selec":4419,"type":"SPL","tck":10,"reussite":20.0,"rde":43.3,"solde":4.33},{"id":16326,"selec":3420,"type":"SG","tck":9,"reussite":11.1,"rde":50.6,"solde":4.55},{"id":16327,"selec":4420,"type":"SG","tck":38,"reussite":10.5,"rde":24.2,"solde":9.21},{"id":16328,"selec":3924,"type":"SPL","tck":13,"reussite":69.2,"rde":22.9,"solde":2.98},{"id":16329,"selec":3420,"type":"SPL","tck":9,"reussite":33.3,"rde":19.6,"solde":1.76},{"id":16330,"selec":4420,"type":"SPL","tck":38,"reussite":28.9,"rde":0.2,"solde":0.07},{"id":16333,"selec":3926,"type":"SPL","tck":1,"reussite":100.0,"rde":92.0,"solde":0.92},{"id":16334,"selec":3421,"type":"SG","tck":3,"reussite":66.7,"rde":175.0,"solde":5.25},{"id":16335,"selec":3421,"type":"SPL","tck":3,"reussite":100.0,"rde":146.0,"solde":4.38},{"id":16336,"selec":4421,"type":"SPL","tck":4,"reussite":25.0,"rde":64.3,"solde":2.57},{"id":16339,"selec":4422,"type":"SG","tck":11,"reussite":9.1,"rde":89.3,"solde":9.82},{"id":16342,"selec":4422,"type":"SPL","tck":11,"reussite":36.4,"rde":24.5,"solde":2.7},{"id":16343,"selec":3928,"type":"SG","tck":2,"reussite":50.0,"rde":93.5,"solde":1.87},{"id":16344,"selec":3423,"type":"SG","tck":30,"reussite":43.3,"rde":23.7,"solde":7.12},{"id":16345,"selec":3928,"type":"SPL","tck":2,"reussite":100.0,"rde":33.0,"solde":0.66},{"id":16350,"selec":3424,"type":"SG","tck":24,"reussite":16.7,"rde":61.9,"solde":14.85},{"id":16352,"selec":3424,"type":"SPL","tck":24,"reussite":45.8,"rde":22.4,"solde":5.38},{"id":16357,"selec":4424,"type":"SPL","tck":36,"reussite":41.7,"rde":22.3,"solde":8.02},{"id":16358,"selec":3930,"type":"SPL","tck":1,"reussite":100.0,"rde":225.0,"solde":2.25},{"id":16359,"selec":4425,"type":"SG","tck":12,"reussite":8.3,"rde":857.1,"solde":102.85},{"id":16360,"selec":3931,"type":"SG","tck":19,"reussite":36.8,"rde":32.2,"solde":6.11},{"id":16361,"selec":4425,"type":"SPL","tck":12,"reussite":16.7,"rde":61.3,"solde":7.35},{"id":16367,"selec":4426,"type":"SG","tck":41,"reussite":9.8,"rde":225.4,"solde":92.42},{"id":16372,"selec":4427,"type":"SG","tck":12,"reussite":8.3,"rde":11.8,"solde":1.41},{"id":16374,"selec":4427,"type":"SPL","tck":12,"reussite":33.3,"rde":128.6,"solde":15.43},{"id":16376,"selec":3428,"type":"SPL","tck":1,"reussite":100.0,"rde":282.0,"solde":2.82},{"id":16379,"selec":4428,"type":"SG","tck":24,"reussite":20.8,"rde":19.0,"solde":4.56},{"id":16381,"selec":3937,"type":"SPL","tck":1,"reussite":100.0,"rde":16.0,"solde":0.16},{"id":16382,"selec":4428,"type":"SPL","tck":24,"reussite":37.5,"rde":5.5,"solde":1.32},{"id":16383,"selec":4429,"type":"SG","tck":46,"reussite":6.5,"rde":16.2,"solde":7.43},{"id":16385,"selec":3938,"type":"SG","tck":2,"reussite":100.0,"rde":280.5,"solde":5.61},{"id":16386,"selec":4429,"type":"SPL","tck":46,"reussite":23.9,"rde":7.8,"solde":3.58},{"id":16388,"selec":3938,"type":"SPL","tck":2,"reussite":100.0,"rde":71.0,"solde":1.42},{"id":16391,"selec":4430,"type":"SPL","tck":3,"reussite":66.7,"rde":66.0,"solde":1.98},{"id":16393,"selec":4431,"type":"SG","tck":10,"reussite":20.0,"rde":2.2,"solde":0.22},{"id":16394,"selec":3432,"type":"SG","tck":1,"reussite":100.0,"rde":484.0,"solde":4.84},{"id":16395,"selec":3432,"type":"SPL","tck":1,"reussite":100.0,"rde":10.0,"solde":0.1},{"id":16396,"selec":3940,"type":"SG","tck":2,"reussite":50.0,"rde":93.5,"solde":1.87},{"id":16397,"selec":4431,"type":"SPL","tck":10,"reussite":40.0,"rde":156.9,"solde":15.69},{"id":16398,"selec":3940,"type":"SPL","tck":2,"reussite":100.0,"rde":33.0,"solde":0.66},{"id":16400,"selec":4432,"type":"SG","tck":12,"reussite":8.3,"rde":857.1,"solde":102.85},{"id":16401,"selec":3942,"type":"SG","tck":1,"reussite":100.0,"rde":505.0,"solde":5.05},{"id":16403,"selec":4432,"type":"SPL","tck":12,"reussite":16.7,"rde":61.3,"solde":7.35},{"id":16404,"selec":3942,"type":"SPL","tck":1,"reussite":100.0,"rde":67.0,"solde":0.67},{"id":16405,"selec":4433,"type":"SG","tck":27,"reussite":14.8,"rde":261.6,"solde":70.64},{"id":16406,"selec":4433,"type":"SPL","tck":27,"reussite":33.3,"rde":83.7,"solde":22.59},{"id":16408,"selec":3434,"type":"SPL","tck":1,"reussite":100.0,"rde":10.0,"solde":0.1},{"id":16410,"selec":3944,"type":"SG","tck":2,"reussite":50.0,"rde":77.0,"solde":1.54},{"id":16411,"selec":3944,"type":"SPL","tck":2,"reussite":100.0,"rde":44.5,"solde":0.89},{"id":16412,"selec":4434,"type":"SPL","tck":22,"reussite":18.2,"rde":46.9,"solde":10.31},{"id":16416,"selec":3946,"type":"SG","tck":12,"reussite":33.3,"rde":14.3,"solde":1.72},{"id":16419,"selec":3436,"type":"SG","tck":27,"reussite":11.1,"rde":49.1,"solde":13.25},{"id":16422,"selec":3436,"type":"SPL","tck":27,"reussite":37.0,"rde":49.3,"solde":13.3},{"id":16424,"selec":3949,"type":"SPL","tck":1,"reussite":100.0,"rde":76.0,"solde":0.76},{"id":16425,"selec":4437,"type":"SG","tck":34,"reussite":8.8,"rde":23.3,"solde":7.92},{"id":16427,"selec":3437,"type":"SPL","tck":3,"reussite":66.7,"rde":1.3,"solde":0.04},{"id":16429,"selec":3438,"type":"SG","tck":27,"reussite":3.7,"rde":5.2,"solde":1.41},{"id":16433,"selec":3950,"type":"SPL","tck":20,"reussite":55.0,"rde":10.8,"solde":2.16},{"id":16436,"selec":4439,"type":"SG","tck":26,"reussite":11.5,"rde":21.8,"solde":5.68},{"id":16437,"selec":3439,"type":"SPL","tck":97,"reussite":32.0,"rde":15.7,"solde":15.23},{"id":16438,"selec":4439,"type":"SPL","tck":26,"reussite":46.2,"rde":117.2,"solde":30.48},{"id":16441,"selec":3440,"type":"SG","tck":625,"reussite":43.7,"rde":16.4,"solde":102.19},{"id":16443,"selec":4440,"type":"SPL","tck":36,"reussite":41.7,"rde":22.3,"solde":8.02},{"id":16448,"selec":4441,"type":"SPL","tck":27,"reussite":14.8,"rde":78.4,"solde":21.17},{"id":16450,"selec":3441,"type":"SPL","tck":66,"reussite":28.8,"rde":27.2,"solde":17.92},{"id":16455,"selec":3442,"type":"SPL","tck":522,"reussite":22.8,"rde":0.8,"solde":4.15},{"id":16466,"selec":3444,"type":"SPL","tck":1,"reussite":100.0,"rde":879.0,"solde":8.79},{"id":16467,"selec":3445,"type":"SG","tck":8,"reussite":12.5,"rde":46.4,"solde":3.71},{"id":16471,"selec":3445,"type":"SPL","tck":8,"reussite":50.0,"rde":38.2,"solde":3.06},{"id":16472,"selec":3963,"type":"SPL","tck":3,"reussite":66.7,"rde":8.0,"solde":0.24},{"id":16473,"selec":3446,"type":"SG","tck":49,"reussite":14.3,"rde":20.0,"solde":9.81},{"id":16475,"selec":4446,"type":"SPL","tck":11,"reussite":36.4,"rde":286.9,"solde":31.56},{"id":16476,"selec":3446,"type":"SPL","tck":49,"reussite":34.7,"rde":54.8,"solde":26.87},{"id":16478,"selec":3447,"type":"SG","tck":19,"reussite":52.6,"rde":30.6,"solde":5.82},{"id":16480,"selec":3447,"type":"SPL","tck":19,"reussite":63.2,"rde":1.5,"solde":0.29},{"id":16489,"selec":3969,"type":"SG","tck":2,"reussite":50.0,"rde":38.0,"solde":0.76},{"id":16490,"selec":3449,"type":"SG","tck":3,"reussite":66.7,"rde":495.3,"solde":14.86},{"id":16491,"selec":4449,"type":"SG","tck":2,"reussite":50.0,"rde":519.0,"solde":10.38},{"id":16492,"selec":3969,"type":"SPL","tck":2,"reussite":50.0,"rde":14.0,"solde":0.28},{"id":16493,"selec":3449,"type":"SPL","tck":3,"reussite":66.7,"rde":117.3,"solde":3.52},{"id":16494,"selec":4449,"type":"SPL","tck":2,"reussite":50.0,"rde":121.5,"solde":2.43},{"id":16501,"selec":3451,"type":"SG","tck":3,"reussite":33.3,"rde":208.7,"solde":6.26},{"id":16503,"selec":3451,"type":"SPL","tck":3,"reussite":33.3,"rde":11.3,"solde":0.34},{"id":16507,"selec":3975,"type":"SG","tck":2,"reussite":50.0,"rde":38.0,"solde":0.76},{"id":16508,"selec":3452,"type":"SPL","tck":1,"reussite":100.0,"rde":283.0,"solde":2.83},{"id":16509,"selec":3975,"type":"SPL","tck":2,"reussite":50.0,"rde":14.0,"solde":0.28},{"id":16512,"selec":3453,"type":"SG","tck":101,"reussite":14.9,"rde":96.3,"solde":97.3},{"id":16515,"selec":3453,"type":"SPL","tck":101,"reussite":32.7,"rde":31.7,"solde":32.01},{"id":16516,"selec":4453,"type":"SPL","tck":25,"reussite":20.0,"rde":1.2,"solde":0.31},{"id":16519,"selec":4454,"type":"SG","tck":12,"reussite":16.7,"rde":172.4,"solde":20.69},{"id":16523,"selec":3455,"type":"SG","tck":96,"reussite":10.4,"rde":51.7,"solde":49.6},{"id":16526,"selec":3981,"type":"SG","tck":5,"reussite":40.0,"rde":56.6,"solde":2.83},{"id":16528,"selec":3981,"type":"SPL","tck":5,"reussite":60.0,"rde":64.8,"solde":3.24},{"id":16530,"selec":4456,"type":"SG","tck":10,"reussite":30.0,"rde":21.9,"solde":2.19},{"id":16533,"selec":3457,"type":"SG","tck":39,"reussite":15.4,"rde":7.3,"solde":2.83},{"id":16537,"selec":4457,"type":"SPL","tck":25,"reussite":36.0,"rde":61.9,"solde":15.48},{"id":16542,"selec":3985,"type":"SPL","tck":1,"reussite":100.0,"rde":212.0,"solde":2.12},{"id":16543,"selec":3458,"type":"SPL","tck":133,"reussite":30.8,"rde":24.8,"solde":32.99},{"id":16549,"selec":4459,"type":"SPL","tck":4,"reussite":50.0,"rde":107.2,"solde":4.29},{"id":16551,"selec":4460,"type":"SG","tck":41,"reussite":9.8,"rde":225.4,"solde":92.42},{"id":16553,"selec":3460,"type":"SG","tck":137,"reussite":6.6,"rde":18.7,"solde":25.65},{"id":16555,"selec":3460,"type":"SPL","tck":137,"reussite":22.6,"rde":101.1,"solde":138.55},{"id":16556,"selec":3988,"type":"SPL","tck":1,"reussite":100.0,"rde":92.0,"solde":0.92},{"id":16565,"selec":3462,"type":"SG","tck":3,"reussite":66.7,"rde":455.3,"solde":13.66},{"id":16568,"selec":3462,"type":"SPL","tck":3,"reussite":66.7,"rde":101.0,"solde":3.03},{"id":16570,"selec":4463,"type":"SG","tck":26,"reussite":11.5,"rde":21.8,"solde":5.68},{"id":16571,"selec":3991,"type":"SG","tck":2,"reussite":50.0,"rde":77.0,"solde":1.54},{"id":16572,"selec":4463,"type":"SPL","tck":26,"reussite":46.2,"rde":117.2,"solde":30.48},{"id":16573,"selec":3991,"type":"SPL","tck":2,"reussite":100.0,"rde":44.5,"solde":0.89},{"id":16574,"selec":3463,"type":"SPL","tck":25,"reussite":56.0,"rde":23.8,"solde":5.95},{"id":16577,"selec":3993,"type":"SG","tck":12,"reussite":33.3,"rde":14.3,"solde":1.72}
];


  const defaultCellStyle = { fontSize: '14px'}


  // {index, name, label, display, empty, filter, sort, print, searchable, download, viewColumns, sortDirection, customHeadRender, customBodyRender, setCellProps, setCellHeaderProps}
  export const columns = [
    
    {
      label: "id",
      name: "id",
      options: {
        filter: true,
        display: false,
        sort: true,
        customBodyRender: (data) => {
          return (
          <span>{data}</span>
             
          )
        },
        setCellProps: () => {
          return {
           align:'left',
           style: defaultCellStyle 
          };
        },
        setCellHeaderProps: () => {
          return {
            align: 'left',
            style: defaultCellStyle 
        };
      },
    }
    },
    {
      label: "Pari",
      name: "type",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
          <span>{data}</span>
             
          )
        },
        setCellProps: () => {
          return {
           align:'left',
           style: defaultCellStyle 
          };
        },
        setCellHeaderProps: () => {
          return {
            align: 'left',
            style: defaultCellStyle 
        };
      },
    }
    },
    {
      label: "Exp.",
      name: "tck",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          return (
            <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         align:'left',
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          align:'left',
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "R.",
      name: "reussite",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          if (data >= 0 && data < 30) {
            return (
              <span style= {{color:"#D50000"}}> {data} %</span>
            )}
            else {

              if (data >= 30 && data < 60) {
                return (
                  <span style= {{color:"#FF9200"}}> {data} %</span>
                )}
                else{

              return (
                <span style= {{color:"#1AA001"}}> {data} %</span>
              ) 
                }
            }
      },
      setCellProps: () => {
        return {
          align:'left',
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          align:'left',
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Rde.",
      name: "rde",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          if (data > 0) {
            return (
              <span style= {{color:"#1AA001"}}> {data} %</span>
            )}
            else {
              return (
                <span style= {{color:"#D50000"}}> {data} %</span>
              ) 
            }
      },
      setCellProps: () => {
        return {
          align:'left',
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          align:'left',
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Gain",
      name: "solde",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          if (data > 0) {
            return (
              <span style= {{color:"#1AA001"}}> {data} €</span>
            )}
            else {
              return (
                <span style= {{color:"#D50000"}}> {data} €</span>
              ) 
            }
      },
      setCellProps: () => {
        return {
          align:'left',
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          align:'left',
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Score",
      name: "score",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          return (
            <Rating name="read-only" value={data} readOnly />
               
            )
          
      },
      setCellProps: () => {
        return {
          align:'left',
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          align:'left',
          style: defaultCellStyle 
      };
    },
    }
    },
  ];

 