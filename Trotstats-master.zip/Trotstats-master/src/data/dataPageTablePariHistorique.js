import React from "react";

export const testData = [
  {"date":"2019-11-09","heure":"16:30","hippodrome":"CHATEAUBRIANT","course":"C5","combinaison":"9","partant":"ELISA DU MOTTAY","typePari":"SPL","statutPari":"PERDANT","mise":"1.0","gain":"0.0","solde":"-270.42"},
  {"date":"2019-11-11","heure":"16:30","hippodrome":"CHATEAUBRIANT","course":"C5","combinaison":"9","partant":"ESCAMPETTE","typePari":"SPL","statutPari":"PERDANT","mise":"1.0","gain":"0.0","solde":"-2.42"}
];


  const defaultCellStyle = { fontSize: '12px' }

  // {index, name, label, display, empty, filter, sort, print, searchable, download, viewColumns, sortDirection, customHeadRender, customBodyRender, setCellProps, setCellHeaderProps}
  export const columns = [
    {
      label: "Date",
      name: "date",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
        },
        setCellProps: () => {
          return {
           style: defaultCellStyle 
          };
        },
        setCellHeaderProps: () => {
          return {
            style: defaultCellStyle 
        };
      },
    }
    },
    {
      label: "Hippodrome",
      name: "hippodrome",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
            <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Course",
      name: "course",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
            <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Heure",
      name: "heure",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Numero",
      name: "combinaison",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>N°{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Trotteur",
      name: "partant",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Mise",
      name: "mise",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data} €</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Gain",
      name: "gain",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data} €</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Solde",
      name: "solde",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data} €</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
  ];

 