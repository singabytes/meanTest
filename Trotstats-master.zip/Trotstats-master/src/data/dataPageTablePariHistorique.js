import React from "react";

  const defaultCellStyle = { fontSize: '12px' }

  // {index, name, label, display, empty, filter, sort, print, searchable, download, viewColumns, sortDirection, customHeadRender, customBodyRender, setCellProps, setCellHeaderProps}
  export const columns = [
    {
      label: "Date",
      name: "date",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
        },
        setCellProps: () => {
          return {
           style: defaultCellStyle 
          };
        },
        setCellHeaderProps: () => {
          return {
            style: defaultCellStyle 
        };
      },
    }
    },
    {
      label: "Hippodrome",
      name: "hippodrome",
      options: {
        filter: true,
        sort: true,
        customBodyRender: (data) => {
          var display = data
          if (data.length > 10)
            display = data.substring(0,7).concat('...')
          return (
            <span>{display}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Course",
      name: "course",
      options: {
        filter: false,
        sort: false,
        customBodyRender: (data) => {
          return (
            <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Heure",
      name: "heure",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Numero",
      name: "combinaison",
      options: {
        filter: false,
        sort: false,
        customBodyRender: (data) => {
          return (
             <span>N°{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Trotteur",
      name: "trotteur",
      options: {
        filter: false,
        sort: false,
        customBodyRender: (data) => {
          return (
             <span>{data}</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Mise",
      name: "mise",
      options: {
        filter: false,
        sort: false,
        customBodyRender: (data) => {
          return (
             <span>{data} €</span>
          )
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "G/P",
      name: "gain",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          if (data > 0) {
            return (
              <span style= {{color:"#1AA001"}}> {data} €</span>
            )}
            else {
              return (
                <span style= {{color:"#D50000"}}> {data} €</span>
              ) 
            }
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
    {
      label: "Solde",
      name: "solde",
      options: {
        filter: false,
        sort: true,
        customBodyRender: (data) => {
          if (data > 0) {
            return (
              <span style= {{color:"#1AA001"}}> {data} €</span>
            )}
            else {
              return (
                <span style= {{color:"#D50000"}}> {data} €</span>
              ) 
            }
      },
      setCellProps: () => {
        return {
         style: defaultCellStyle 
        };
      },
      setCellHeaderProps: () => {
        return {
          style: defaultCellStyle 
      };
    },
    }
    },
  ];

 