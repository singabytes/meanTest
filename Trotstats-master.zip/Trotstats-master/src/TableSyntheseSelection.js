import React from "react";
import MUIDataTable from "mui-datatables";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { testData, columns } from './data/dataPageTableSyntheseSelection';
import Button from '@material-ui/core/Button';

//https://github.com/gregnb/mui-datatables/blob/master/README.md

class TableSyntheseSelection extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [{"id":0,"selec":0,"type":"NA","tck":0,"reussite":0,"rde":0,"solde":0, "score":0}],
      apiKey : props.apiKey
    }
  }

  componentDidMount() {
    fetch(`http://vps36407.ovh.net:8080/tableSelectionsWS?token=${this.state.apiKey}`)
    .then(res => res.json())
    .then((data) => {
      this.setState({ data: data.table })
    })
    .catch(console.log)
  }

  render() {
  const options = {
    filter: false,
    filterType: 'dropdown',
    responsive: 'scrollFullHeight',
    selectableRowsHeader: false,
    selectableRows:false, // remove checkbox
    expandableRows: false,
    expandableRowsOnClick: false,
    pagination: true,
    viewColumns: false,
    print: false,
    download: false,
    sort: true,
    filter: false,
    search: false,
    
    onRowClick: (rowData, rowState) => {
      // On recupere l'ID de la selection... 
      // call du ws 
      // http://vps36407.ovh.net:8080/detailSelectionWS?id=16441&token=777
      console.log(this.state.apiKey);
      console.log(rowData[0].props.children);
    },
     setTableProps: () => {
       return {
        size: "small",
       };
     },
      setCellHeaderProps: () => {
        return {
        };
    },
  };
  
    const theme = createMuiTheme({
      overrides: {
        MUIDataTableSelectCell: {
          expandDisabled: {
            // Soft hide the button.
            visibility: 'hidden',
          },
        },
      },
    });

 
    return (
      <div style={{width:'100%'}}>
      <MuiThemeProvider theme={theme}>
           <MUIDataTable title={""} 
          data={this.state.data} columns={columns} options={options} />
      </MuiThemeProvider>
    </div>
    );

  }
}

export default TableSyntheseSelection;
