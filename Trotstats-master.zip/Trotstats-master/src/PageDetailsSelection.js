import AppBar from '@material-ui/core/AppBar';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Container from '@material-ui/core/Container';
import CssBaseline from '@material-ui/core/CssBaseline';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Tab from '@material-ui/core/Tab';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Tabs from '@material-ui/core/Tabs';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import React from 'react';
import { BrowserRouter, Link, Route, Switch } from "react-router-dom";
import TablePariHistorique from './TablePariHistorique';
import TablePronostics from './TablePronostics';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import IconButton from '@material-ui/core/IconButton';
import Chip from '@material-ui/core/Chip';
import CircularProgress from '@material-ui/core/CircularProgress'
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import SwitchT from '@material-ui/core/Switch';
import TimelineIcon from '@material-ui/icons/Timeline';
import BarChartIcon from '@material-ui/icons/BarChart';
import TestBarChart from './TestBarChart'
import TestLineChart from './TestLineChart'


const drawerWidth = 240;

class PageDetailsSelection extends React.Component {

  

    constructor(props) {
      super(props);
      this.state = {
        data: null,
        apiKey: this.props.apiKey,
        detail: "",
        typeChart: 1,
        titleChart: "Gain / Perte par course",
        showAll: false
      }

      fetch(`http://vps36407.ovh.net:8080/detailSelectionWS?token=${this.state.apiKey}&id=${this.props.showDetailsSelection}`)
      .then(res => res.json())
      .then((data) => {
        this.setState({ detail: data })
        console.log("donnee " + this.state.detail.requete);
      })
      .catch(console.log)
      
    }
  

  classes = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
    },
    title: {
      flexGrow: 1,
    },
  }),
);

  retour() {
    this.props.callbackRetourDetails()
  }
  
  showlineChart(){
    this.setState({ typeChart: 0, titleChart: "Gain / Perte cumulés" })
  }

  showBarChart(){
    this.setState({ typeChart: 1, titleChart: "Gain / Perte par course" })
  }

  // show all races on graph or just last ones

    handleChangeShowAll = name => event => {
      console.log(this.state.showAll)
      this.setState({ showAll: event.target.checked })
  }

  render() {
  return (
  <div className={this.classes.root}>
      <CssBaseline />
      <AppBar position="fixed">
      <Toolbar>
        <img width='75' src={"/images/logo3.png"}></img>
        <Typography variant="h6" className={this.classes.title}></Typography>
      </Toolbar>
      </AppBar>

      <Container style={{marginTop:'5em', minWidth:'950px', maxWidth:'950px', backgroundColor: '#FAFBFC',height: '100%' }}>

      {/* Section bouton retour */}

      <IconButton onClick={() => this.retour('') } color="primary" >
        <ArrowBackIcon/>
      </IconButton >

      {/* Section display critere */}

      <div style={{width:'900px', marginTop:"0.5em"}}>
        <Card style={{width:'100%'}}>
          <CardContent>
            <Typography className={this.classes.title} color="textSecondary" gutterBottom>
              Les critères de la sélection
            </Typography>
            <div style={{marginTop:"1em"}}>
              {/* if the critere array is null (time to load the data) then display the spinning wheel */}
              { (this.state.detail.critere != null) && ( 
                  this.state.detail.critere.map((value) =>
                  <Chip label={value.critere} color="primary" style={{marginRight:"0.5em", marginBottom:"0.5em"}} /> ))}
              { (this.state.detail.critere == null) && (<center><CircularProgress disableShrink /></center>) }
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Section display info courses */} 

        <div style={{width:'900px'}}>
        <div style={{float:'left', marginTop:'1em', width:'49%'}}>
        <Card style={{width:'100%'}}>
      <CardContent>
      <Typography className={this.classes.title} color="textSecondary" gutterBottom>
          Informations sur les courses
        </Typography>

           <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Période analysée</TableCell>
              <TableCell align="right">{this.state.detail.periode}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Nombre de jours retenus</TableCell>
              <TableCell align="right">{this.state.detail.jour}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Nombre de courses jouées</TableCell>
              <TableCell align="right">{this.state.detail.ticket}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Dynamique de jeu</TableCell>
              <TableCell align="right">{this.state.detail.dynamique}</TableCell>    
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>

      {/* Section Bilan  */}

        <div style={{float:'right',marginTop:'1em', width:'49%'}}>
        <Card style={{witdh:'100%'}}>
      <CardContent>
      <Typography className={this.classes.title} color="textSecondary" gutterBottom>
          Bilan des performances
        </Typography>

          <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Type de pari</TableCell>
              {(this.state.detail.type == "SPL") && (
                <TableCell align="right">Simple placé</TableCell>
              )} 
              {(this.state.detail.type == "SG") && (
                <TableCell align="right">Simple gagnant</TableCell>
              )} 

          </TableRow>
          <TableRow>
              <TableCell align="left">Réussite</TableCell>
              {(this.state.detail.reussite >= 0) && (this.state.detail.reussite < 30) && (
                <TableCell align="right" style={{color:"#D50000"}}>{this.state.detail.reussite} %</TableCell>
              )}
              {(this.state.detail.reussite >= 30) && (this.state.detail.reussite < 60) && (
                <TableCell align="right" style={{color:"#FF9200"}}>{this.state.detail.reussite} %</TableCell>
              )}
              {(this.state.detail.reussite >= 60) && (
                <TableCell align="right" style={{color:"#1AA001"}}>{this.state.detail.reussite} %</TableCell>
              )}

          </TableRow>
          <TableRow>
              <TableCell align="left">Rendement</TableCell>
              {(this.state.detail.rde > 0) && (
                <TableCell align="right" style={{color:"#1AA001"}}>{this.state.detail.rde} %</TableCell>
              )}
              {(this.state.detail.rde < 0) && (
                <TableCell align="right" style={{color:"#D50000"}}>{this.state.detail.rde} %</TableCell>
              )}   

          </TableRow>
          <TableRow>
              <TableCell align="left">Gain / Perte</TableCell>
              {(this.state.detail.solde > 0) && (
                <TableCell align="right" style={{color:"#1AA001"}}>{this.state.detail.solde} €</TableCell>
              )}
              {(this.state.detail.solde < 0) && (
                <TableCell align="right" style={{color:"#D50000"}}>{this.state.detail.solde} €</TableCell>
              )}
                  
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>
        
        </div>

      {/* Section Graph  */}

      <div style={{width:'900px', marginTop:'22em'}}>

          <Card style={{width:'100%'}}>
      <CardContent>
      <Typography className={this.classes.title} color="textSecondary" gutterBottom>
                {this.state.titleChart}
                <div style={{float:"right"}}>
      <IconButton onClick={() => {this.showlineChart()}} color="primary" component="span">
          <TimelineIcon />
      </IconButton>
      <IconButton onClick={() => {this.showBarChart()}} color="primary" component="span">
          <BarChartIcon />
      </IconButton>
      </div>
      </Typography>
     <div style={{marginTop:'1.5em'}}>
        {/* BAR CHART */}
        { (this.state.typeChart == 1) && (this.state.detail.ligneHisto != null ) && (!this.state.showAll) && (<TestBarChart data = { this.state.detail.ligneHisto } />)}
        {/* we have data and last races */}
        { (this.state.typeChart == 1) && (this.state.detail.ligneHisto != null ) && (this.state.showAll) && (<TestBarChart data = { this.state.detail.ligneHisto.slice(this.state.detail.ligneHisto.length-20, this.state.detail.ligneHisto.length) } style={{marginTop:'10em'}}/>)}
        
        {/* LINE CHART*/}
        { (this.state.typeChart == 0) && (this.state.detail.ligneHisto != null ) && (!this.state.showAll) && (<TestLineChart data = { this.state.detail.ligneHisto } />)}
        {/* we have data and last races */}
        { (this.state.typeChart == 0) && (this.state.detail.ligneHisto != null ) && (this.state.showAll) && (<TestLineChart data = { this.state.detail.ligneHisto.slice(this.state.detail.ligneHisto.length-20, this.state.detail.ligneHisto.length) } style={{marginTop:'10em'}}/>)}
        </div>
        <FormGroup row >
      <FormControlLabel
        control={ <SwitchT checked={ this.state.showAll } onChange={ this.handleChangeShowAll('showAll') } value = 'showAll'/> }
        label="Afficher les 100 Derniers paris"
      />
      </FormGroup>
     
      </CardContent>
      
    </Card>

        
        </div>

 <div style={{width:'900px'}}>
        <div style={{float:'left', marginTop:'1em', width:'49%'}}>
        <Card style={{width:'100%'}}>
      <CardContent>
      <Typography className={this.classes.title} color="textSecondary" gutterBottom>
          Informations sur les écarts
        </Typography>

           <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Suite actuelle de course perdante</TableCell>
              <TableCell align="right">{this.state.detail.suitePerdante}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Suite maximun rencontrée</TableCell>
              <TableCell align="right">{this.state.detail.suitePerdanteMax}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Suite actuelle de course gagnante</TableCell>
              <TableCell align="right">{this.state.detail.suiteGagnant}</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Suite maximun rencontrée</TableCell>
              <TableCell align="right">{this.state.detail.suiteGagnantMax}</TableCell>    
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>

      {/* Section Bilan  */}

        <div style={{float:'right',marginTop:'1em', marginBottom:'1em', width:'49%'}}>
        <Card style={{witdh:'100%'}}>
      <CardContent>
      <Typography className={this.classes.title} color="textSecondary" gutterBottom>
          Informations sur les rapports
        </Typography>

          <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Rapport minimum</TableCell>
              <TableCell align="right">{this.state.detail.rapportMin} €</TableCell>  
          </TableRow>
          <TableRow>
              <TableCell align="left">Rapport maximum</TableCell>
              <TableCell align="right">{this.state.detail.rapportMax} €</TableCell>  
          </TableRow>
          <TableRow>
              <TableCell align="left">Rapport moyen</TableCell>
              <TableCell align="right">{this.state.detail.rapportMoy} €</TableCell>  
          </TableRow>
          <TableRow>
              <TableCell align="left">Pourcentage de favori</TableCell>
              <TableCell align="right">{this.state.detail.favori} %</TableCell>  
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>
        
        </div>


<div style={{width:'900px'}}>
        <BrowserRouter>
<AppBar position="static">
<Tabs 
// onChange={handleChange}
value={0}
indicatorColor="primary"
textColor="white"
centered
>
<Tab label="Pronostics" component= { Link } to= '/pronostics' />
<Tab label="Historique des paris" component= { Link } to= '/historique' />


</Tabs>
</AppBar>
<Switch>
<Route path='/historique'>
{/* if the critere array is null (time to load the data) then display the spinning wheel */}
      { (this.state.detail.ligneHisto != null) && (
       <TablePariHistorique histo={this.state.detail.ligneHisto}/>) }
      { (this.state.detail.ligneHisto == null) && (<center><CircularProgress disableShrink /></center>) }

  
</Route>

<Route path='/pronostics'>
{/* if the critere array is null (time to load the data) then display the spinning wheel */}
      { (this.state.detail.pronostics != null) && (
       <TablePronostics pronostics={this.state.detail.pronostics}/> ) }
      { (this.state.detail.pronostics == null) && (<center><CircularProgress disableShrink /></center>) }
</Route>

</Switch>
</BrowserRouter>
</div>
      </Container>
    </div>
  );
}
}

export default PageDetailsSelection;