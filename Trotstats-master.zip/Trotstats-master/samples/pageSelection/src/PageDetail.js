import React from 'react';
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import ListAltIcon from '@material-ui/icons/ListAlt';
import AllInboxIcon from '@material-ui/icons/AllInbox';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';

function TabPanel(props: TabPanelProps) {
const { children, value, index, ...other } = props;
return (
<Typography
component="div"
role="tabpanel"
hidden={value !== index}
id={`scrollable-force-tabpanel-${index}`}
aria-labelledby={`scrollable-force-tab-${index}`}
{...other}
>
{value === index && 
<Box p={3}>{children}</Box>
}
</Typography>
);
}
function a11yProps(index: any) {
return {
id: `scrollable-force-tab-${index}`,
'aria-controls': `scrollable-force-tabpanel-${index}`,
};
}
const useStyles = makeStyles((theme: Theme) =>
createStyles({
root: {
flexGrow: 1,
},
formControl: {
margin: theme.spacing(1),
minWidth: 120,
},
selectEmpty: {
marginTop: theme.spacing(2),
},
button: {
margin: theme.spacing(1),
},
}),
);
interface TabPanelProps {
children?: React.ReactNode;
index: any;
value: any;
}
export default function SimpleContainer() {
const classes = useStyles();
const [value, setValue] = React.useState(0);
const handleChange = (event: React.ChangeEvent<{}>, newValue: number) => {
setValue(newValue);
};
return (
<div className={classes.root}>
  <Card>
    <CardContent>
   
      <Grid container spacing={3}>
      <Grid item xs={12} xl={12}>
          <Card>
              <CardContent>
                Nom + description de la selection + QueryDTF
              </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} xl={8}>
          <Card>
              <CardContent>
                Graphique LINECHART evolution des gains
              </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} xl={4}>
          <Card>
              <CardContent>
                information stats / reussite / solde etc.. a voir se qu'on display et sous quelle forme
              </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} xl={4}>
          <Card>
              <CardContent>
                Graphique SCATTERCHART sur la distribution de gain (nuage de point)
              </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} xl={4}>
          <Card>
              <CardContent>
                Graphique BARCHART sur la distribution des ecarts perdant
              </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} xl={4}>
          <Card>
              <CardContent>
                information ... (?)
              </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} xl={12}>
          <Card>
            <CardContent>
              <AppBar position="static" color="default">
                <Tabs
                  value={value}
                  onChange={handleChange}
                  variant="scrollable"
                  scrollButtons="on"
                  indicatorColor="primary"
                  textColor="primary"
                  aria-label="scrollable force tabs example"
                  >
                  <Tab label="Pronostics du jour" icon={
                  <ListAltIcon />
                  } {...a11yProps(0)} />
                  <Tab label="Historique des paris" icon={
                  <AllInboxIcon />
                  } {...a11yProps(1)} />
                </Tabs>
              </AppBar>
              <TabPanel value={value} index={0}>
              TablePariDuJour callbackFunction=callbackSelectionTable data=dataTableParis
              </TabPanel>
              <TabPanel value={value} index={1}>
              TablePariHistorique callbackFunction=callbackSelectionTable data=dataTableParis
              </TabPanel>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </CardContent>
  </Card>
</div>
);
}