import React from 'react';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardHeader from '@material-ui/core/CardHeader';
import Select from '@material-ui/core/Select';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Grid from '@material-ui/core/Grid';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Fab from '@material-ui/core/Fab';
import SearchIcon from '@material-ui/icons/Search';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Link from '@material-ui/core/Link';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormLabel from '@material-ui/core/FormLabel';


const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    button: {
      margin: theme.spacing(1),
    },
  
  }),
);

export default function SimpleContainer() {
  const classes = useStyles();
 
  return (
    <div className={classes.root}>
      
      <Card>
    
      <CardContent>
      <Breadcrumbs aria-label="breadcrumb">
        <Link color="inherit" href="#">
          Dataturf
        </Link>
        <Typography color="textPrimary">Rechercher</Typography>
      </Breadcrumbs>
      <Typography color="textPrimary">!!! Un texte explicatif sur les requêtes DTF !!! </Typography>
      <Grid container spacing={3} >
        <Grid item xl={12}>
        <TextField marginTop={3} fullWidth="true" rows="3" id="outlined-basic" label="Requête DTF" variant="outlined" />  
        
        </Grid> 

     <Typography color="textPrimary">!!!Ajouter des composants de filtre, exemple : réussite / rentabilite / type de paris, etc.. !!! </Typography>
     <Typography color="textPrimary">!!! idée : proposez un formulaire de recherche complet pour rechercher dans notre POOL de selections/strategies !!! </Typography>   
      </Grid>
      </CardContent>
      <CardActions>
      <Button
        variant="contained"
        color="primary"
        className={classes.button}
        startIcon={<SearchIcon />}
      >
        Rechercher
      </Button> 
      </CardActions>
    </Card>


    
      </div>
    
  );
}
