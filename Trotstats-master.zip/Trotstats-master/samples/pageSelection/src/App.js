import React from 'react';
import logo from './logo.svg';
import './App.css';
import Dashboard from './Dashboard'
import Dashboard2 from './Dashboard2'

function App() {
  return (
    <div className="App">
     <Dashboard2/>
    </div>
  );
}

export default App;
