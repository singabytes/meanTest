import QuantLib as ql
from pymongo import MongoClient
    
cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')

db = cluster['bond']
collection = db['bond_static_data']

#######
# GET #
#######

def get_all_data(drop_ids = True):
    cursor = collection.find({})
    return cursor

def get_data(query, drop_ids = True):
    cursor = collection.find(query)
    return cursor

def get_data_date(date, drop_ids = True):
    return get_data( {'date': f'{date}'})

def get_data_symbol(date, instrument, drop_ids = True):
    return get_data( {'date': f'{date}', 'symbol': f'{instrument}'} )

##########
# INSERT #
##########

def insert_data(data,  drop_ids = True):
    collection.insert_one(data)
    return True



