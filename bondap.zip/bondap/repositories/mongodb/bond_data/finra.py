import QuantLib as ql
from pymongo import MongoClient
    
cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')

db = cluster['bond']
collection = db['bond_static_data']

#######
# GET #
#######

def get_all_bonds(drop_ids = True):
    cursor = collection.find({})
    return cursor

def get_bonds(query, drop_ids = True):
    res = list(collection.find(query))
    # remove key _id as value Object cannot be serialized
    if drop_ids:
        for items in res:
            if '_id' in items:
                del items['_id']
    return res

def get_bonds_date(date, drop_ids = True):
    res =  get_bonds({'lastTradeDate': f'{date}'}, drop_ids)
    return res

def get_bonds_symbol(date, instrument, drop_ids = True):
    res = get_bonds({'lastTradeDate': f'{date}', 'symbol': f'{instrument}'}, drop_ids)
    return res

def get_bonds_fixed(date, callable = False, perpetual = False, drop_ids = True):
    res = get_bonds({'lastTradeDate': f'{date}', 'couponType': 'FXPV', 'isCallable': 'N'}, drop_ids)
    return res

##########
# INSERT #
##########

def insert_data(data,  drop_ids = True):
    collection.insert_one(data)
    return True
