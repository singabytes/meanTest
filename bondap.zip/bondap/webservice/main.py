from fastapi import FastAPI

from typing import List
from sqlalchemy import create_engine
import os
import sys

if os.name == 'posix':
    sys.path.insert(0, r'/home/singapat/github/bondap/orm/')
else:
    sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\orm\\')

from helpers import finra_prices_helpers
from models import finra_prices

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.get("/prices/cusip/{cusip_id}", response_model=List[finra_prices.finra_prices_schema])
def read_item(cusip_id: str, q: str = 'cusip'):
    print(cusip_id, q)
    res = finra_prices_helpers.get_prices(cusip_id)
    print('res',res)
    #res = [{"tradeDate": "2025-03-03", "tradePrice": "89.5", "tradeYield": "8.083231", "cusip": "683712AA1", "timeStamp": "2025-03-04 12:39:26"}]
    return res
    