import cv2
import qrcode
import hashlib
import os
import shutil
from pyzbar.pyzbar import decode
from qreader import QReader

######
# Convert frame / qr to document
# path_root = 'C:\\temp\\' 
# path_frame_folder = path_root + 'frames\\' - folder with frame
# filename_video = 'output.mts' - name of the video
######

print('Si fichier video MTS, reglez le nb fr frame dans le code')
print('')

path_root = 'D:\\temp\\'
path_frame_folder = path_root + 'frames-50\\'
output_filename = 'document55.txt'

filename_video = 'metadata-6.mts'

document = ''
previous_check_code = ''

# number of frames in video
cap = cv2.VideoCapture(path_root + filename_video)
nbframe = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
print('Video ', filename_video) 
print('Length ', nbframe)
print('---')

nbframe = 9000

qreader = QReader(model_size='s')

for i in range(0,nbframe + 200): # 200 is for buffer 
    filename = path_frame_folder + str(i) + '.png'
    if os.path.isfile(filename):
        try:
            #print('Processing file ', filename)
            img = cv2.imread(filename)
            #cv2
            # detect = cv2.QRCodeDetector()
            #value, points, straight_qrcode = detect.detectAndDecode(img)
            #pyzbar                 
            #barcodes = decode(img)
            #print(barcodes)
            #QReader
            # Get the image that contains the QR code
            image = cv2.cvtColor(cv2.imread(filename), cv2.COLOR_BGR2RGB)
            # Use the detect_and_decode function to get the decoded QR data
            barcodes = qreader.detect_and_decode(image=image)
            if barcodes[0] == None:
                continue
            #value = barcodes[0].data.decode() for cv2 / pyzbar
            value = barcodes[0] 
            value = value.rstrip()
            checkcode = value
            if value == '':
                continue
            if checkcode != previous_check_code:
                document = document + value
                previous_check_code = checkcode
            
            #print(value)

            if (i % 100) == 0:
                print(f'Frame {i} - max {nbframe}')
                print(value.encode('utf-8'))

        except Exception as e:
            print('error ', i)
            print(e)

print('-- all decoded ---')
tmp1 = document.replace('{', '\n')
tmp2 = tmp1.replace('^', ' ')
print(tmp2)

f = open(path_root + output_filename, 'w')
f.write(tmp2)
f.close()

print(f'Output document : {output_filename} in {path_root}')
#print('--- md5 ---')
#md5 = hashlib.md5(open(path_root + 'document6.txt','rb').read()).hexdigest()
#print(md5)
