import cv2
import os

#######
# Decode qrvideo and duimp all frames (qr) in folder
# path_root = 'C:\\temp\\' 
# path_frame_folder = path_root + 'frames\\' - folder to dump frames
# path_frame_video = path_root + 'videos\\' - folder where the video is
# filename_video = 'output.mts' - name of the video
#######

path_root = 'D:\\temp\\' 
path_frame_folder = path_root + 'frames-9\\'
path_frame_video = path_root + 'videos\\'

filename_video = 'metadata-9.mts'

def delete_all_files(folder):
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))

# delete all files in frame folder to avoid conflict
delete_all_files(path_frame_folder)

try:
    cam = cv2.VideoCapture(path_frame_video + filename_video)
except:
    print('error loading file')

currentframe = 0

while(True):
    ret, frame = cam.read()
    if ret:
        name = path_frame_folder + str(currentframe) + '.png'
        print('Creating... ' + name)
        cv2.imwrite(name, frame)
        currentframe += 1
    else:
        break

cam.release()
cv2.destroyAllWindows()