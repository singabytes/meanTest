from datetime import datetime, timedelta

t0 = datetime.now()
tm1 = t0 - timedelta(days=1)
tm2 = t0 - timedelta(days=2)
tm3 = t0 - timedelta(days=3)
tp1 = t0 - timedelta(days=1)

t0_stg = t0.strftime('%Y%m%d')
tm1_stg = tm1.strftime('%Y%m%d')
tm2_stg = tm2.strftime('%Y%m%d')
tm3_stg = tm3.strftime('%Y%m%d')
tp1_stg = tp1.strftime('%Y%m%d')

try:
	with open('rundate.t0','w') as file:
		file.write(t0_stg)
except IOError as e:
	print(f'Error writing rundate file : {e}')

try:
	with open('rundate.tp1','w') as file:
		file.write(tp1_stg)
except IOError as e:
	print(f'Error writing rundate file : {e}')

try:
	with open('rundate.tm1','w') as file:
		file.write(tm1_stg)
except IOError as e:
	print(f'Error writing rundate file : {e}')

try:
	with open('rundate.tm2','w') as file:
		file.write(tm2_stg)
except IOError as e:
	print(f'Error writing rundate file : {e}')

try:
	with open('rundate.tm3','w') as file:
		file.write(tm3_stg)
except IOError as e:
	print(f'Error writing rundate file : {e}')

