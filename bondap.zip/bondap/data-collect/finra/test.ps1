$date_from = "2024-09-01"

# cleanup folder to dump web extract
#Remove-Item -LiteralPath ".\dump-finra" -Force -Recurse
$today = Get-Date -Format "yyyyMMdd"
New-Item -Name "dump-finra\$today" -Path "." -ItemType Directory

##################################################################################################
### First pull all coupon types except FXPV and FXZC (too many, need to filter by coupon rate) ###
##################################################################################################

$coupon_types = @('FRBF','FRFX','FRFZ','FRRS','FRSD','FRVR','FRZF'.'FTZR','FXAN','FXDI','FXPM','FXPP','RSFR','TBPD','CNGT','FRFF','FROT','FRPV','FRSU','FXMF','FXRS','FXRV','OTH','RGOT','STRP','VRGR')
#$coupon_types = @('CNGT')

for ($i = 0; $i -lt $coupon_types.Length - 1; $i++) {

    $coupon_type = $coupon_types[$i]
    
    $output_file = ".\dump-finra\$today\dump-$coupon_type"

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "d1ac5988-cc36-4dba-a367-9aa85a224dee", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.1141339115.1725459783", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1725459783547.232023211186473197", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.1741642046.1726158330", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "fco8JD00oEU_Z5FzaDBS6r6sDddtZlBPN2W5DABdar0-1726158323-1.0.1.1-Rr5SUEQrR4SUIo3yVGtVvQJFmXw4mNrsa.oz71foBoQCwxv.VkCWClccLux7K_JvPUiftQEujmkRyiyaE1bCdQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "a454f0b8-d2b1-4202-96f9-63b7d3449ab2", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "GIAfaroXO.Nkalwi6E8gBYm3ryoUzFgM1pJLekvZDNE-1726158326015-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252F", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=wag61w8cbq2t06vj&fst=1715610716448&pst=1725772911158&cst=1726158329539&ns=6&pvt=66&pvis=8&th=1219673.0.2.2.1.1.1715610716452.1715610719746.0.1", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1726158329.6.1.1726158358.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.1576233481.1715610718", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1726158329.6.1.1726158500.60.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "UFd3PuaH_MtOqRAdGEhB1CkCjmsRlgV6gs.WSJ1Thfs-1726158640-1.0.1.1-8lW6mvK._ppYayuDRNugQgVdnWemfJ._tVpGSvzXuGDW8cCzkKWHRsg4rl7cl53doa7ik_BlN7_PNPn0glLQEw", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr-FR;q=0.8,fr;q=0.7"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Chromium`";v=`"128`", `"Not;A=Brand`";v=`"24`", `"Microsoft Edge`";v=`"128`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="a454f0b8-d2b1-4202-96f9-63b7d3449ab2"
    } `
    -OutFile $output_file `
    -ContentType "application/json" `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"couponType`",`"fieldValue`":`"$coupon_type`",`"compareType`":`"EQUAL`"},{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"

    Start-Sleep -Seconds 3
}

Start-Sleep -Seconds 5

##########################
### FXPV + Coupon rate ###
##########################

$value_coupons = @(0, 0.01, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75, 4, 4.25, 4.5, 4.75, 5, 5.25, 5.5, 5.75, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 11, 12, 13, 14, 15, 20, 25, 50)

for ($i = 0; $i -lt $value_coupons.Length - 1; $i++) {

    $coupon_from = $value_coupons[$i]
    $coupon_to = $value_coupons[$i+1]

    $output_file = ".\dump-finra\$today\dump-FXPV-$coupon_from-$coupon_to"

    Write-Host "Coupon : $coupon_from - $coupon_to dump in $output_file"

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "d1ac5988-cc36-4dba-a367-9aa85a224dee", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.1141339115.1725459783", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1725459783547.232023211186473197", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.1741642046.1726158330", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "fco8JD00oEU_Z5FzaDBS6r6sDddtZlBPN2W5DABdar0-1726158323-1.0.1.1-Rr5SUEQrR4SUIo3yVGtVvQJFmXw4mNrsa.oz71foBoQCwxv.VkCWClccLux7K_JvPUiftQEujmkRyiyaE1bCdQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "a454f0b8-d2b1-4202-96f9-63b7d3449ab2", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "GIAfaroXO.Nkalwi6E8gBYm3ryoUzFgM1pJLekvZDNE-1726158326015-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252F", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=wag61w8cbq2t06vj&fst=1715610716448&pst=1725772911158&cst=1726158329539&ns=6&pvt=66&pvis=8&th=1219673.0.2.2.1.1.1715610716452.1715610719746.0.1", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1726158329.6.1.1726158358.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.1576233481.1715610718", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1726158329.6.1.1726158500.60.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "UFd3PuaH_MtOqRAdGEhB1CkCjmsRlgV6gs.WSJ1Thfs-1726158640-1.0.1.1-8lW6mvK._ppYayuDRNugQgVdnWemfJ._tVpGSvzXuGDW8cCzkKWHRsg4rl7cl53doa7ik_BlN7_PNPn0glLQEw", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr-FR;q=0.8,fr;q=0.7"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Chromium`";v=`"128`", `"Not;A=Brand`";v=`"24`", `"Microsoft Edge`";v=`"128`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="a454f0b8-d2b1-4202-96f9-63b7d3449ab2"
    } `
    -OutFile $output_file `
    -ContentType "application/json" `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"couponType`",`"fieldValue`":`"FXPV`",`"compareType`":`"EQUAL`"},{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_from`",`"compareType`":`"GTE`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_to`",`"compareType`":`"LESSER`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"

    Start-Sleep -Seconds 3

}

Start-Sleep -Seconds 5


##########################
### FXZC + Coupon rate ###
##########################

$value_coupons = @(0, 0.01)

for ($i = 0; $i -lt $value_coupons.Length - 1; $i++) {

    $coupon_from = $value_coupons[$i]
    $coupon_to = $value_coupons[$i+1]

    $output_file = ".\dump-finra\$today\dump-FXZC-$coupon_from-$coupon_to"

    Write-Host "Coupon : $coupon_from - $coupon_to dump in $output_file"

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "d1ac5988-cc36-4dba-a367-9aa85a224dee", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.1141339115.1725459783", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1725459783547.232023211186473197", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.1741642046.1726158330", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "fco8JD00oEU_Z5FzaDBS6r6sDddtZlBPN2W5DABdar0-1726158323-1.0.1.1-Rr5SUEQrR4SUIo3yVGtVvQJFmXw4mNrsa.oz71foBoQCwxv.VkCWClccLux7K_JvPUiftQEujmkRyiyaE1bCdQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "a454f0b8-d2b1-4202-96f9-63b7d3449ab2", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "GIAfaroXO.Nkalwi6E8gBYm3ryoUzFgM1pJLekvZDNE-1726158326015-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252F", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=wag61w8cbq2t06vj&fst=1715610716448&pst=1725772911158&cst=1726158329539&ns=6&pvt=66&pvis=8&th=1219673.0.2.2.1.1.1715610716452.1715610719746.0.1", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1726158329.6.1.1726158358.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.1576233481.1715610718", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1726158329.6.1.1726158500.60.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "UFd3PuaH_MtOqRAdGEhB1CkCjmsRlgV6gs.WSJ1Thfs-1726158640-1.0.1.1-8lW6mvK._ppYayuDRNugQgVdnWemfJ._tVpGSvzXuGDW8cCzkKWHRsg4rl7cl53doa7ik_BlN7_PNPn0glLQEw", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr-FR;q=0.8,fr;q=0.7"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Chromium`";v=`"128`", `"Not;A=Brand`";v=`"24`", `"Microsoft Edge`";v=`"128`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="a454f0b8-d2b1-4202-96f9-63b7d3449ab2"
    } `
    -OutFile $output_file `
    -ContentType "application/json" `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"couponType`",`"fieldValue`":`"FXZC`",`"compareType`":`"EQUAL`"},{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_from`",`"compareType`":`"GTE`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_to`",`"compareType`":`"LTE`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"

    Start-Sleep -Seconds 3
}
