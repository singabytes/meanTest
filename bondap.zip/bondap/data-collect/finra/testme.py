from pymongo import MongoClient


cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = cluster['bond']
collection = db['finra_prices']

test = { "cusip": "ABC123", "data": [ {"date": "12-12-25", "price": "100.25", "yield": "5.66"} ] }

result = collection.find_one({"cusip": "ABC123"})

tmp = result['data']
tmp.append({"date": "12-12-31", "price": "110.25", "yield": "4.66"})
test = { "cusip": "ABC123", "data": tmp }

collection.insert_one(test)
