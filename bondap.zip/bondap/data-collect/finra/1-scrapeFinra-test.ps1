#$date_from = "2025-01-22"
#$today = Get-Date -Format "yyyyMMdd"

$T0 = '20250316'
$TM2 = '20250312'

# convert to correct string format
$T0_stg = $T0.Substring(0,4) + '-' + $T0.Substring(4,2) + '-' + $T0.Substring(6,2)
$TM2_stg = $TM2.Substring(0,4) + '-' + $TM2.Substring(4,2) + '-' + $TM2.Substring(6,2)

# set dates
$today = $T0
$date_from = $TM2_stg

# cleanup folder to dump web extract
#Remove-Item -LiteralPath ".\dump-finra" -Force -Recurse
New-Item -Name "dump-finra\$today" -Path "." -ItemType Directory

# change the permission of the folder in Linux (autosys is running as root)
chmod 777 "dump-finra\$today"

##################################################################################################
### First pull all coupon types except FXPV and FXZC (too many, need to filter by coupon rate) ###
##################################################################################################

$coupon_types = @('FRBF','FRFX','FRFZ','FRRS','FRSD','FRVR','FRZF'.'FTZR','FXAN','FXDI','FXPM','FXPP','RSFR','TBPD','CNGT','FRFF','FROT','FRPV','FRSU','FXMF','FXRS','FXRV','OTH','RGOT','STRP','VRGR')
#$coupon_types = @('CNGT')

for ($i = 0; $i -lt $coupon_types.Length - 1; $i++) {

    $coupon_type = $coupon_types[$i]
    
    $output_file = ".\dump-finra\$today\dump-$coupon_type"

    # conditions : coupon_type + date_from

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "cec96a07-5342-4c7d-928e-99ed7d022ab8", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_TSVRDQEJ0X", "GS1.1.1713282798.1.1.1713283439.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_60020H86NR", "GS1.1.1715524406.2.1.1715524862.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_MX9MQ535Z4", "GS1.1.1715524563.2.1.1715526857.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_0469QZC1C3", "GS1.1.1715525932.5.1.1715526861.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.211125516.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1737036155104.707653569390312240", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252Ffinra-data%252Ffixed-income%252Fcorp-and-agency", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.289437369.1737728158", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "kmcpOkg7YFsnnqux7hF3IA.NNnu_auuyBQK.jVREZsg-1737728144-1.0.1.1-I6Tmo6MjXShlgFXxnVTuupOMF25YCaqpcGAd89hSrdLc_1eFOQ70RXxiVpUUhk2MOSp1c_9lFqjYskRcWBleRQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "76467568-8705-46b7-8310-b97d5b838863", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "URzNvwDQPobb6fL8WOWDTrylCJswteSXuUN1ezcWoyQ-1737728147291-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=83crttyjcfz5yv9v&fst=1737036154841&pst=1737558112671&cst=1737728156895&ns=4&pvt=45&pvis=2&th=", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.2037239204.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1737728158.4.1.1737728247.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1737728158.5.1.1737728307.31.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "04fgzsBo_JPtFX9zgEj3tuVjhsn5kHo8U7aFYhIFov8-1737729577-1.0.1.1-tkvbh50Mf5_neBtACqW1b45NodcUsJ3PGMEgtVDlST9xtkbhCiSqrGuLx_zpeBiXQ29u7AznIVxnue6GcEAbSg", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr;q=0.8"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Google Chrome`";v=`"131`", `"Chromium`";v=`"131`", `"Not_A Brand`";v=`"24`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="76467568-8705-46b7-8310-b97d5b838863"
    } `
    -ContentType "application/json" `
    -OutFile $output_file `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"},{`"fieldName`":`"couponType`",`"fieldValue`":`"$coupon_type`",`"compareType`":`"EQUAL`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":50,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"
    
    Start-Sleep -Seconds 3
}

Start-Sleep -Seconds 5

##########################
### FXPV + Coupon rate ###
##########################

$value_coupons = @(0, 0.01, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75, 4, 4.25, 4.5, 4.75, 5, 5.25, 5.5, 5.75, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 11, 12, 13, 14, 15, 20, 25, 50)

for ($i = 0; $i -lt $value_coupons.Length - 1; $i++) {

    $coupon_from = $value_coupons[$i]
    $coupon_to = $value_coupons[$i+1]

    $output_file = ".\dump-finra\$today\dump-FXPV-$coupon_from-$coupon_to"

    Write-Host "Coupon : $coupon_from - $coupon_to dump in $output_file"

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "cec96a07-5342-4c7d-928e-99ed7d022ab8", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_TSVRDQEJ0X", "GS1.1.1713282798.1.1.1713283439.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_60020H86NR", "GS1.1.1715524406.2.1.1715524862.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_MX9MQ535Z4", "GS1.1.1715524563.2.1.1715526857.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_0469QZC1C3", "GS1.1.1715525932.5.1.1715526861.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.211125516.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1737036155104.707653569390312240", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252Ffinra-data%252Ffixed-income%252Fcorp-and-agency", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.289437369.1737728158", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "kmcpOkg7YFsnnqux7hF3IA.NNnu_auuyBQK.jVREZsg-1737728144-1.0.1.1-I6Tmo6MjXShlgFXxnVTuupOMF25YCaqpcGAd89hSrdLc_1eFOQ70RXxiVpUUhk2MOSp1c_9lFqjYskRcWBleRQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "76467568-8705-46b7-8310-b97d5b838863", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "URzNvwDQPobb6fL8WOWDTrylCJswteSXuUN1ezcWoyQ-1737728147291-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=83crttyjcfz5yv9v&fst=1737036154841&pst=1737558112671&cst=1737728156895&ns=4&pvt=45&pvis=2&th=", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.2037239204.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1737728158.4.1.1737728247.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1737728158.5.1.1737728307.31.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "04fgzsBo_JPtFX9zgEj3tuVjhsn5kHo8U7aFYhIFov8-1737729577-1.0.1.1-tkvbh50Mf5_neBtACqW1b45NodcUsJ3PGMEgtVDlST9xtkbhCiSqrGuLx_zpeBiXQ29u7AznIVxnue6GcEAbSg", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr;q=0.8"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Google Chrome`";v=`"131`", `"Chromium`";v=`"131`", `"Not_A Brand`";v=`"24`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="76467568-8705-46b7-8310-b97d5b838863"
    } `
    -ContentType "application/json" `
    -OutFile $output_file `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"couponType`",`"fieldValue`":`"FXPV`",`"compareType`":`"EQUAL`"},{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_from`",`"compareType`":`"GTE`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_to`",`"compareType`":`"LESSER`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"

    Start-Sleep -Seconds 3
}

Start-Sleep -Seconds 5


##########################
### FXZC + Coupon rate ###
##########################

$value_coupons = @(0, 0.01)

for ($i = 0; $i -lt $value_coupons.Length - 1; $i++) {

    $coupon_from = $value_coupons[$i]
    $coupon_to = $value_coupons[$i+1]

    $output_file = ".\dump-finra\$today\dump-FXZC-$coupon_from-$coupon_to"

    Write-Host "Coupon : $coupon_from - $coupon_to dump in $output_file"

    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    $session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "cec96a07-5342-4c7d-928e-99ed7d022ab8", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_TSVRDQEJ0X", "GS1.1.1713282798.1.1.1713283439.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_60020H86NR", "GS1.1.1715524406.2.1.1715524862.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_MX9MQ535Z4", "GS1.1.1715524563.2.1.1715526857.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_0469QZC1C3", "GS1.1.1715525932.5.1.1715526861.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.211125516.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1737036155104.707653569390312240", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252Ffinra-data%252Ffixed-income%252Fcorp-and-agency", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.289437369.1737728158", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "kmcpOkg7YFsnnqux7hF3IA.NNnu_auuyBQK.jVREZsg-1737728144-1.0.1.1-I6Tmo6MjXShlgFXxnVTuupOMF25YCaqpcGAd89hSrdLc_1eFOQ70RXxiVpUUhk2MOSp1c_9lFqjYskRcWBleRQ", "/", ".ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "76467568-8705-46b7-8310-b97d5b838863", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "URzNvwDQPobb6fL8WOWDTrylCJswteSXuUN1ezcWoyQ-1737728147291-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=83crttyjcfz5yv9v&fst=1737036154841&pst=1737558112671&cst=1737728156895&ns=4&pvt=45&pvis=2&th=", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.2037239204.1737036155", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1737728158.4.1.1737728247.0.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1737728158.5.1.1737728307.31.0.0", "/", ".finra.org")))
    $session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "04fgzsBo_JPtFX9zgEj3tuVjhsn5kHo8U7aFYhIFov8-1737729577-1.0.1.1-tkvbh50Mf5_neBtACqW1b45NodcUsJ3PGMEgtVDlST9xtkbhCiSqrGuLx_zpeBiXQ29u7AznIVxnue6GcEAbSg", "/", ".services-dynarep.ddwa.finra.org")))
    Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities" `
    -Method "POST" `
    -WebSession $session `
    -Headers @{
    "authority"="services-dynarep.ddwa.finra.org"
    "method"="POST"
    "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencySecurities"
    "scheme"="https"
    "accept"="application/json, text/plain, */*"
    "accept-encoding"="gzip, deflate, br, zstd"
    "accept-language"="en-US,en;q=0.9,fr;q=0.8"
    "origin"="https://www.finra.org"
    "priority"="u=1, i"
    "referer"="https://www.finra.org/"
    "sec-ch-ua"="`"Google Chrome`";v=`"131`", `"Chromium`";v=`"131`", `"Not_A Brand`";v=`"24`""
    "sec-ch-ua-mobile"="?0"
    "sec-ch-ua-platform"="`"Windows`""
    "sec-fetch-dest"="empty"
    "sec-fetch-mode"="cors"
    "sec-fetch-site"="same-site"
    "x-xsrf-token"="76467568-8705-46b7-8310-b97d5b838863"
    } `
    -ContentType "application/json" `
    -OutFile $output_file `
    -Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"isCallable`",`"productSubTypeCode`",`"couponRate`",`"maturityDate`",`"industryGroup`",`"moodysRating`",`"standardAndPoorsRating`",`"traceGradeCode`",`"lastSalePrice`",`"lastSaleYield`",`"couponType`",`"lastTradeDate`",`"cusip`",`"isConvertible`",`"is144A`",`"isPerpetual`",`"nextCallDate`",`"priceChangeNumber`",`"priceChangePercent`",`"moodyRatingDate`",`"standardAndPoorsRatingDate`"],`"dateRangeFilters`":[],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"couponType`",`"fieldValue`":`"FXZC`",`"compareType`":`"EQUAL`"},{`"fieldName`":`"lastTradeDate`",`"fieldValue`":`"$date_from`",`"compareType`":`"GREATER`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_from`",`"compareType`":`"GTE`"},{`"fieldName`":`"couponRate`",`"fieldValue`":`"$coupon_to`",`"compareType`":`"LTE`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"+issuerName`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"

    Start-Sleep -Seconds 3
}

Start-Sleep -Seconds 5

# persist to database
#C:\Users\singapat\miniconda3\python C:\Users\singapat\code-prod\finra\persist_to_mongo.py
