import json 
import os
import logging
import sys
import csv
import traceback
from datetime import datetime
from pymongo import MongoClient
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.exc import NoResultFound

import sys

if os.name == 'posix':
    sys.path.insert(0, r'/home/singapat/github/bondap/data-collect/metaData')
    sys.path.insert(0, r'/home/singapat/github/bondap/orm')
else:
    sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\data-collect\\metaData\\')
    sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\orm\\')
 

import bond_metadata
from models.finra_bonds import finra_bonds
from models.finra_prices import finra_prices

def get_rundate():
    try:
        with open('rundate.t0','r') as file:
            rundate = file.read()
        return rundate
    except IOError as e:
        logging.info(f'Cannot read rundate file : {e}')
        exit(1)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(f'extractDataFromFinraDump_{get_rundate()}.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

def extract_instruments(date_string = '20200101'):
    
    if date_string == '20200101':
        now = datetime.now()
        date_string = now.strftime("%Y%m%d")
        logging.info(f'Use default date {date_string}')

    # remove potential /n
    date_string = date_string.rstrip()
    path = rf'C:\Users\Patrick\GitHub\bondap\data-collect\finra\dump-finra\{date_string}\\'
    if os.name == 'posix':
        path = rf'./dump-finra/{date_string}/'
    # remove /n see in Linux
    path = path.rstrip()
    dir_list = os.listdir(path)

    logging.info(f'Processing file in {path}')

    count_total_instruments = 0

    # array to store all instrument data
    instrument_data_array= []

    for file in dir_list:
        full_name = path + file
        logging.info(f'Processing {full_name}')
        with open(full_name, 'r',encoding='utf-8') as file:
            text = file.read().replace('\n', '')

        text = text.replace('data":"[{', 'data":[{')
        text = text.replace('}]"}}', '}]}}')
        text = text.replace('\\','')
        data = json.loads(text)
        
        #check number of instruments
        nb_instruments_from_request = data['returnBody']['headers']['Record-Total']
        all_instrument_data = data['returnBody']['data']
        if int(nb_instruments_from_request[0]) > 0: # instrument found in request
            for instrument_data in all_instrument_data:
                # basic check for missing field
                field_missing = False
                for field in ['cusip', 'lastTradeDate', 'lastSalePrice']:
                    if field not in instrument_data.keys():
                        field_missing = True
                if field_missing:
                    logging.info(f'Instrument {instrument_data} missing fields - ignored')
                else:
                    instrument_data_array.append(instrument_data)
        
        nb_instruments = len(instrument_data_array)
        logging.info(f'{nb_instruments} instruments saved')
        logging.info(f'File {full_name} has {nb_instruments} matching request size : {nb_instruments_from_request[0]}')

    return instrument_data_array


def extract_with_metadata(date_string = '20200101'):

    if date_string == '20200101':
        now = datetime.now()
        date_string = now.strftime("%Y%m%d")

    finra_data = extract_instruments(date_string)

    # Get metadata 
    all_metadata = bond_metadata.get_bond_metadata(False)

    # Add metadata to the finra bond if possible
    

if __name__ == "__main__":
    # read date from rundate file
    rundate = get_rundate()
    logging.info(f'Rundate set to {rundate}')

    instruments = extract_instruments(rundate)
    
    logging.info('Instrument Test')
    logging.info(instruments[100]['cusip'])
    logging.info(instruments[100]['lastTradeDate'])
    logging.info(instruments[100]['lastSalePrice'])
    logging.info(instruments[100]['lastSaleYield'])
    
    # check for critical data (key is present but no value)
    instruments_tmp = []
    original_size = len(instruments)
    keys_to_check = ['cusip', 'lastTradeDate', 'lastSalePrice', 'issueSymbolIdentifier']
    for inst in instruments: 
        to_be_deleted = False
        for key in keys_to_check:
            if key in inst and not inst[key]:
                logging.info(f"'{key}' is missing for {inst['issueSymbolIdentifier']}.")
                to_be_deleted = True
        # we will save only the instruments with all data
        if not to_be_deleted:
            instruments_tmp.append(inst)
    logging.info(f'{len(instruments)} remaining, lost {original_size -len(instruments_tmp)} instruments')
    instruments = instruments_tmp #we dump all the instruments with missing data

    # persist to database
    db_name = 'bondap_master'
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'
    engine = create_engine(connection_string, echo=False)
    session = Session(engine)
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    ### add bond metadata     
    if True:
        
        logging.info('----------------------------------------')
        logging.info('Start processing bond metada information')
        logging.info('----------------------------------------')
                
        start_time = datetime.now()
        # stats counter
        stats_new_bonds = 0
        stats_update_bonds = 0

        for inst in instruments:
            try:
                # check if data exists
                # step 1 - check if cusip is in database
                stmt = select(finra_bonds).where(finra_bonds.cusip == f'{inst["cusip"]}')
                try:
                    current_bond = session.scalars(stmt).one()
                    # yes it is in database already- delete it to add the latest version later
                    logging.info(f'Bond {inst} already in database - update it')
                    stats_update_bonds = stats_update_bonds + 1

                    # check what has changed (if any)
                    change_date = False
                    change_price = False
                    if (current_bond.lastTradeDate) != inst['lastTradeDate']: 
                        logging.info(f'[bond metadata] Date has changed from {current_bond.lastTradeDate} to {inst['lastTradeDate']}')
                        change_date = True
                    if (current_bond.lastSaleYield) != inst['lastSaleYield']: 
                        logging.info(f'[bond metadata] Yield has changed from {current_bond.lastSaleYield} to {inst['lastSaleYield']}')
                        change_price = True
                    if (current_bond.lastSalePrice) != inst['lastSalePrice']: 
                        logging.info(f'[bond metadata] Price has changed from {current_bond.lastSalePrice} to {inst['lastSalePrice']}')
                        change_price = True
                    if (change_date == True and change_price == False):
                        logging.error('[bond metadata] Price / Yield changing but no date')

                    session.delete(current_bond)

                except NoResultFound:
                    # not in database, we will insert it later anyway > pass
                    logging.info(f'Bond {inst} is new - add it')
                    stats_new_bonds = stats_new_bonds + 1
                    pass
                
                bond = finra_bonds(inst, timestamp)
                session.add(bond)
                session.commit()

            except Exception as e:
                logging.error(f'Could not persist for cusip : {inst["cusip"]} / symbol : {inst["issueSymbolIdentifier"]}')
                logging.error(e, exc_info=True)

        end_time = datetime.now()
        elapsed_time = end_time - start_time
        logging.info(f'-- stats for bond metadata --')
        logging.info(f'Total number of bonds : {len(instruments)}')
        logging.info(f'- New bonds : {stats_new_bonds}')
        logging.info(f'- Updated bonds : {stats_update_bonds}')
        logging.info(f"Processed in : {elapsed_time} secs.")
        
    ### add bond prices 
    if False:

        logging.info('----------------------------------------')
        logging.info('Start processing bond metada information')
        logging.info('----------------------------------------')

        start_time = datetime.now()

        for inst in instruments:
            # we want to keep only keys : cusip, lastTradeDate, lastSalePrice, lastSaleYield
            # Create a list of keys to delete
            keys_to_delete = [key for key in inst if key not in ['cusip', 'lastTradeDate', 'lastSalePrice', 'lastSaleYield']]
            # Delete the keys from the dictionary
            #for key in keys_to_delete:
            #    del inst[key]
            try:
                # check if data exists
                # step 1 - check if cusip is in database
                stmt = select(finra_prices).where(finra_prices.cusip == f'{inst["cusip"]}') \
                            .where(finra_prices.tradeDate == f'{inst["lastTradeDate"]}') 
                try:
                    current_bond = session.scalars(stmt).one()
                    # yes it is in database alreade- delete it to add the latest version later
                    logging.info(f'Bond prices {inst} already in database - skip it')
                    
                    #check what has changed (if any)
                    if (current_bond.tradePrice) != inst['tradePrice']:
                        logging.info(f'[bond price] Yield has changed from {current_bond.tradePrice} to {inst['lastSalePrice']}')
                    if (current_bond.tradeYield) != inst['tradeYield']: 
                        logging.info(f'[bond price] Price has changed from {current_bond.tradeYield} to {inst['lastSaleYield']}')
                        
                    #session.delete(current_bond)

                except NoResultFound:
                    # not in database, we will insert it later anyway > pass
                    logging.info(f'Bond prices {inst} is new - add it')
                    price = finra_prices(inst, timestamp)
                    session.add(price)
                    session.commit()

            except Exception as e:
                logging.error(f'Could not persist for cusip : {inst["cusip"]} / symbol : {inst["issueSymbolIdentifier"]}')
                logging.error(e, exc_info=True)

        end_time = datetime.now()
        elapsed_time = end_time - start_time
        logging.info(f"Processed in : {elapsed_time} secs.")

'''
'cusip' = 'M0152VAB9'
'is144A' = 'N'
'moodyRatingDate' = '2018-04-03'
'issueSymbolIdentifier' = 'ANZ3764948'
'issuerName' = 'ABU DHABI NATL ENERGY CO PJSC'
'priceChangeNumber' = -1.746
'standardAndPoorsRating' = None
'standardAndPoorsRatingDate' = '2018-06-18'
'isCallable' = 'N'
'couponRate' = 6.5
'maturityDate' = '2036-10-27'
'couponType' = None
'productSubTypeCode' = 'CORP'
'nextCallDate' = None
'lastTradeDate' = '2024-10-16'
'isConvertible' = 'N'
'moodysRating' = None
'isPerpetual' = None
'traceGradeCode' = 'H'
'lastSaleYield' = None
'priceChangePercent' = -1.5
'industryGroup' = None
'lastSalePrice' = 114.645
'''
