#from simplified_scrapy import SimplifiedDoc, utils, req
import requests
import os
import sys
import argparse

def getData(fund, url, date):

    # Clean date (sometimes space prefix)
    date = date.rstrip().lstrip()
    output_path = rf'.\dump-iShare\{date}'
    # Create the folder along with any intermediate directories
    os.makedirs(output_path, exist_ok=True)
        
    # Below code is to save spreadsheet of tyhpe : https://www.ishares.com/us/products/239458/ishares-core-total-us-bond-market-etf/1467271812596.ajax?fileType=csv&fileName=AGG_holdings&dataType=fund
    # basically a csv file 
    response = requests.get(url)
    if response.status_code == 200:
        with open(rf'{output_path}\{fund}-{date}.csv', 'wb') as file:
            file.write(response.content)
        print("File downloaded and saved as data.csv")
    else:
        print("Failed to download the file. Status code:", response.status_code)
    
    # Below code is to save spreadsheet of type : https://www.ishares.com/us/products/239460/ishares-credit-bond-etf/1521942788811.ajax?fileType=xls&fileName=iShares-Broad-USD-Investment-Grade-Corporate-Bond-ETF_fund&dataType=fund
    #xml = req.get(url)
    #xml = xml.read().decode('utf-8')
    #doc = SimplifiedDoc(xml)
    #worksheets = doc.selects('ss:Worksheet') # Get all Worksheets
    #for worksheet in worksheets:
    #    print(worksheet['ss:Name'])
    #    if worksheet['ss:Name'] == 'Holdings':
    #        print(f'Get rows')
    #        rows = worksheet.selects('ss:Row').selects('ss:Cell>text()') # Get all rows
    #        print(f'Save')
    #        utils.save2csv(f'C:\\temp\{fund}-' + worksheet['ss:Name'] + f'-{date}.csv', rows, newline='') # Save data to csv
    

parser = argparse.ArgumentParser(description="A simple argument parser.")
# Define arguments
parser.add_argument("-d", "--date", help="Working date", type=str)
args = parser.parse_args()

date = args.date
if date == None:
    print('Date is missing')
    sys.exit()

funds = [ {'name': 'AGG', 'url' : 'https://www.ishares.com/us/products/239458/ishares-core-total-us-bond-market-etf/1467271812596.ajax?fileType=csv&fileName=AGG_holdings&dataType=fund'},
         {'name': 'IEF', 'url' : 'https://www.ishares.com/us/products/239456/ishares-710-year-treasury-bond-etf/1467271812596.ajax?fileType=csv&fileName=IEF_holdings&dataType=fund'},
         {'name': 'LQD', 'url' : 'https://www.ishares.com/us/products/239566/ishares-iboxx-investment-grade-corporate-bond-etf/1467271812596.ajax?fileType=csv&fileName=LQD_holdings&dataType=fund'},
         {'name': 'USHY', 'url' : 'https://www.ishares.com/us/products/291299/fund/1467271812596.ajax?fileType=csv&fileName=USHY_holdings&dataType=fund'},
         {'name': 'IGSB', 'url' : 'https://www.ishares.com/us/products/239463/ishares-intermediate-credit-bond-etf/1467271812596.ajax?fileType=csv&fileName=IGIB_holdings&dataType=fund'},
         {'name': 'HYG', 'url' :  'https://www.ishares.com/us/products/239565/ishares-iboxx-high-yield-corporate-bond-etf/1467271812596.ajax?fileType=csv&fileName=HYG_holdings&dataType=fund'},
         {'name': 'IGIB', 'url' : 'https://www.ishares.com/us/products/239463/ishares-intermediate-credit-bond-etf/1467271812596.ajax?fileType=csv&fileName=IGIB_holdings&dataType=fund'},
         {'name': 'USIG', 'url' : 'https://www.ishares.com/us/products/239460/ishares-credit-bond-etf/1467271812596.ajax?fileType=csv&fileName=USIG_holdings&dataType=fund'},
         {'name': 'SHYG', 'url' : 'https://www.ishares.com/us/products/258100/ishares-05-year-high-yield-corporate-bond-etf/1467271812596.ajax?fileType=csv&fileName=SHYG_holdings&dataType=fund'}
         ]

for fund in funds:
    getData(fund['name'], fund['url'], date)

print("Positional argument:", args.positional_arg)
