#https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/new-scheduledtask?view=windowsserver2022-ps

#Unregister-ScheduledTask -TaskName 'custom-scrape-data-barchart'
#Unregister-ScheduledTask -TaskName 'custom-scrape-bond-finra'
Unregister-ScheduledTask -TaskName 'custom-scrape-iShare-funds'

$parent_path = "C:\Users\singapat\GitHub\bondap"

# scrape iShare
$actions = (New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-File "run_script.ps1"' -WorkingDirectory "$parent_path\data-collect\iShare\")
$trigger = New-ScheduledTaskTrigger -Daily -At '20:00'
$principal = New-ScheduledTaskPrincipal -UserId 'useme2test\singapat' #-RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -RunOnlyIfNetworkAvailable -WakeToRun
$task = New-ScheduledTask -Action $actions -Principal $principal -Trigger $trigger -Settings $settings

Register-ScheduledTask 'custom-scrape-iShare-funds' -InputObject $task

# scrape bond data finra
#$actions = (New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-File ".\data-collect\finra\1-scrapeFinra.ps1"' -WorkingDirectory $parent_path)
#$trigger = New-ScheduledTaskTrigger -Daily -At '21:00'
#$principal = New-ScheduledTaskPrincipal -UserId 'useme2test\singapat' #-RunLevel Highest
#$settings = New-ScheduledTaskSettingsSet -RunOnlyIfNetworkAvailable -WakeToRun
#$task = New-ScheduledTask -Action $actions -Principal $principal -Trigger $trigger -Settings $settings

#Register-ScheduledTask 'custom-scrape-bond-finra' -InputObject $task

# scrape barchart
#$actions = (New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-File "get_barchart_inst_to_mongo.ps1"' -WorkingDirectory $parent_path)
#$trigger = New-ScheduledTaskTrigger -Daily -At '20:00'
#$principal = New-ScheduledTaskPrincipal -UserId 'useme2test\singapat' #-RunLevel Highest
#$settings = New-ScheduledTaskSettingsSet -RunOnlyIfNetworkAvailable -WakeToRun
#$task = New-ScheduledTask -Action $actions -Principal $principal -Trigger $trigger -Settings $settings

#Register-ScheduledTask 'custom-scrape-data-barchart' -InputObject $task