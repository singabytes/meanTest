from sqlalchemy.orm import Session
from sqlalchemy import create_engine
import os
import sys
import json

if os.name == 'posix':
    sys.path.insert(0, r'/home/singapat/github/bondap/orm/')
else:
    sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\orm\\')

from models.finra_prices import finra_prices

def get_prices(cusip):

    db_name = 'bondap_master'
 
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'
    
    engine = create_engine(connection_string, echo=True)
    session = Session(engine)

    if cusip == 'all':
        prices = session.query(finra_prices).all()
    else:
        prices = session.query(finra_prices).filter(finra_prices.cusip == cusip).all()

    #return prices

    result_list = [price.__dict__ for price in prices]
    # Remove the '_sa_instance_state' entry that SQLAlchemy includes
    for item in result_list:
        item.pop('_sa_instance_state', None)
    res = json.dumps(result_list)#, indent=4)
    #print(result_list[0:100])
    return result_list

if __name__ == "__main__":
    res = get_prices('502160AN4')
    print(res)
