from typing import List
from typing import Optional
from sqlalchemy import ForeignKey
from sqlalchemy import String
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy.exc import ProgrammingError
import json 
import os
import sys

if os.name == 'posix':
    sys.path.insert(0, r'/home/singapat/github/bondap/orm/')
else:
    sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\orm\\')

from models.finra_bonds import finra_bonds

def get_all_users():

    db_name = 'bondap_master'
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'
    
    engine = create_engine(connection_string, echo=True)
    session = Session(engine)

    query = session.query(finra_bonds)

    bonds = query.all()
    result_list = [bond.__dict__ for bond in bonds]
    # Remove the '_sa_instance_state' entry that SQLAlchemy includes
    for item in result_list:
        item.pop('_sa_instance_state', None)
    #res = json.dumps(result_list), indent=4)
    print(result_list[0:100])

# Example usage

if __name__ == "__main__":
    get_all_users()
