from typing import List
from typing import Optional
from sqlalchemy import ForeignKey
from sqlalchemy import String
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy.exc import ProgrammingError

class Base(DeclarativeBase):
    pass

class finra_bonds(Base):
    __tablename__ = "finra_bonds"
    cusip: Mapped[str] = mapped_column(primary_key=True)
    is144A: Mapped[Optional[str]]
    moodyRatingDate: Mapped[Optional[str]]
    issueSymbolIdentifier: Mapped[Optional[str]]
    issuerName: Mapped[Optional[str]]
    priceChangeNumber: Mapped[Optional[str]]
    standardAndPoorsRating: Mapped[Optional[str]]
    standardAndPoorsRatingDate: Mapped[Optional[str]]
    isCallable: Mapped[Optional[str]]
    couponRate: Mapped[Optional[str]]
    maturityDate: Mapped[Optional[str]]
    couponType: Mapped[Optional[str]]
    productSubTypeCode: Mapped[Optional[str]]
    nextCallDate: Mapped[Optional[str]]
    lastTradeDate: Mapped[Optional[str]]
    isConvertible: Mapped[Optional[str]]
    moodysRating: Mapped[Optional[str]]
    isPerpetual: Mapped[Optional[str]]
    traceGradeCode: Mapped[Optional[str]]
    lastSaleYield: Mapped[Optional[str]]
    priceChangePercent: Mapped[Optional[str]]
    industryGroup: Mapped[Optional[str]]
    lastSalePrice: Mapped[Optional[str]]
    timeStamp: Mapped[str]

    def __init__(self, finra_instrument, timestamp):
        self.cusip = finra_instrument['cusip']
        self.is144A = finra_instrument['is144A']
        self.moodyRatingDate = finra_instrument['moodyRatingDate']
        self.issueSymbolIdentifier = finra_instrument['issueSymbolIdentifier']
        self.issuerName = finra_instrument['issuerName']
        self.priceChangeNumber = finra_instrument['priceChangeNumber']
        self.standardAndPoorsRating = finra_instrument['standardAndPoorsRating']
        self.standardAndPoorsRatingDate = finra_instrument['standardAndPoorsRatingDate']
        self.isCallable = finra_instrument['isCallable']
        self.couponRate = finra_instrument['couponRate']
        self.maturityDate = finra_instrument['maturityDate']
        self.couponType = finra_instrument['couponType']
        self.productSubTypeCode = finra_instrument['productSubTypeCode']
        self.nextCallDate = finra_instrument['nextCallDate']
        self.lastTradeDate = finra_instrument['lastTradeDate']
        self.isConvertible = finra_instrument['isConvertible']
        self.moodysRating = finra_instrument['moodysRating']
        self.isPerpetual = finra_instrument['isPerpetual']
        self.traceGradeCode = finra_instrument['traceGradeCode']
        self.lastSaleYield = finra_instrument['lastSaleYield']
        self.priceChangePercent = finra_instrument['priceChangePercent']
        self.industryGroup = finra_instrument['industryGroup']
        self.lastSalePrice = finra_instrument['lastSalePrice']
        self.timeStamp = timestamp

    def __repr__(self) -> str:
        return f"finra_bonds(cusip={self.cusip!r}, is144A={self.is144A!r}, moodyRatingDate={self.moodyRatingDate!r},\
                issueSymbolIdentifier={self.issueSymbolIdentifier!r}, issuerName={self.issuerName!r}, priceChangeNumber={self.priceChangeNumber!r},\
                standardAndPoorsRating={self.standardAndPoorsRating!r}, standardAndPoorsRatingDate={self.standardAndPoorsRatingDate!r}, isCallable={self.isCallable!r},\
                couponRate={self.couponRate!r}, maturityDate={self.maturityDate!r}, couponType={self.couponType!r},\
                productSubTypeCode={self.productSubTypeCode!r}, moodysRating={self.moodysRating!r}, isPerpetual={self.isPerpetual!r},\
                traceGradeCode={self.traceGradeCode!r}, lastSaleYield={self.lastSaleYield!r}, priceChangePercent={self.priceChangePercent!r},\
                industryGroup={self.industryGroup!r}, lastSalePrice={self.lastSalePrice!r}, timeStamp={self.timeStamp!r})"


if __name__ == "__main__":

    #connection_string = 'sqlite:///C:\\temp\\testsql.sqlite3'

    # postgre
    db_name = 'bondap_master'
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'

    print('*** Creating all tables ***')    
    print(f'Going to use connection string : {connection_string}')
    
    engine = create_engine(connection_string, echo=True)
    if not database_exists(engine.url):
        print(f'Created database {db_name} as it did not exists')
        create_database(engine.url)

    Base.metadata.create_all(engine)
