from sqlalchemy import create_engine, Column, Integer, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from typing import List
from typing import Optional
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped,Session
from sqlalchemy.orm import mapped_column
from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy.exc import ProgrammingError

# Define a base class for declarative models
class Base(DeclarativeBase):
    pass

# Define a table with a JSON or JSONB column
class bond_metadata(Base):
    __tablename__ = 'bond_metadata'
    cusip: Mapped[str] = mapped_column(primary_key=True)
    data = Column(JSON)  # Use JSON or JSONB based on your needs

if __name__ == "__main__":

    # postgre
    db_name = 'bondap_master'
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'

    print('*** Creating all tables ***')    
    print(f'Going to use connection string : {connection_string}')
    
    engine = create_engine(connection_string, echo=True)

    if not database_exists(engine.url):
        print(f'Created database {db_name} as it did not exists')
        create_database(engine.url)

    #if not engine.dialect.has_table('finra_prices'):
    #    print('Creating table')
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    #else:
    #    print('Table already exists')
    #    Base.metadata.drop_all(engine)

####
'''      
if __name__ == "__main__":
    
    session = Session(engine)

    user = bond_metadata(
        cusip="Patrick",
        data={"age": 30, "city": "Singapore"}
    )
    session.add(user)
    session.commit()

    #results = session.query(bond_metadata).filter(bond_metadata.data["city"].astext  == "Singapore").all()
    results = session.query(bond_metadata).filter(bond_metadata.cusip  == "Patrick").all()

    for user in results:
        print(user.cusip, user.data["city"])

    results = session.query(bond_metadata).filter(bond_metadata.cusip  == "Patrick").first()
    if results:
        results.data["city"] = "Tokyo"
        session.commit()
    
    results = session.query(bond_metadata).filter(bond_metadata.cusip  == "Patrick").all()

    for user in results:
        print(user.cusip, user.data["city"])
    
    session.close()'
    '''