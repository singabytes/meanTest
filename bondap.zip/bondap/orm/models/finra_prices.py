from typing import List
from typing import Optional
from sqlalchemy import ForeignKey
from sqlalchemy import String
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine, PrimaryKeyConstraint
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy.exc import ProgrammingError
from pydantic import BaseModel

class Base(DeclarativeBase):
    pass

class finra_prices(Base):
    __tablename__ = "finra_prices"
    __table_args__ = (
        PrimaryKeyConstraint('cusip', 'tradeDate'),
    )
    cusip: Mapped[str]
    tradeDate: Mapped[Optional[str]]
    tradeYield: Mapped[Optional[str]]
    tradePrice: Mapped[Optional[str]]
    timeStamp: Mapped[str]

    def __init__(self, finra_instrument, timestamp):
        self.cusip = finra_instrument['cusip']
        self.tradeDate = finra_instrument['lastTradeDate']
        self.tradeYield = finra_instrument['lastSaleYield']
        self.tradePrice = finra_instrument['lastSalePrice']
        self.timeStamp = timestamp

    def __repr__(self) -> str:
        return f"finra_prices(cusip={self.cusip!r}, tradeDate={self.tradeDate!r}, tradeYield={self.tradeYield!r}, tradePrice={self.tradePrice!r}, timeStamp={self.timeStamp!r})"

# Pydantic model
class finra_prices_schema(BaseModel):
    tradeDate: str
    tradePrice: Optional[str]
    tradeYield: Optional[str]
    cusip: str
    timeStamp: str
#[{"tradeDate": "2025-03-03", "tradePrice": "89.5", "tradeYield": "8.083231", "cusip": "683712AA1", "timeStamp": "2025-03-04 12:39:26"}]

if __name__ == "__main__":

    # postgre
    db_name = 'bondap_master'
    connection_string = f'postgresql+psycopg2://postgres:patogas@localhost:5432/{db_name}'

    print('*** Creating all tables ***')    
    print(f'Going to use connection string : {connection_string}')
    
    engine = create_engine(connection_string, echo=True)

    if not database_exists(engine.url):
        print(f'Created database {db_name} as it did not exists')
        create_database(engine.url)

    #if not engine.dialect.has_table('finra_prices'):
    #    print('Creating table')
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    #else:
    #    print('Table already exists')
    #    #Base.metadata.drop_all(engin e0

    
