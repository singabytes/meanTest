import pandas as pd
import logging

import helpers.marketdata.yahoo
import helpers.indicators.elhers as indic
import talib
import matplotlib.pyplot as plt
import numpy as np

logger = logging.getLogger(__name__)
#format = '[%(filename)s:%(lineno)s] %(message)s'
format = '%(asctime)s;%(levelname)s;%(message)s'
logging.basicConfig(filename = 'apply_strategy.log', filemode = 'w', format = format)
logger.setLevel(logging.DEBUG)

# get clean ticker

path = './data/yahoo/clean/'
tickers = pd.read_csv(path + 'saved_ticker.csv', header = None)

close_type = 'close'
total = []

tickers = [['CSCO']]

for ticker in tickers[0]:
    print(ticker)
    prices = pd.read_csv(path + ticker + '.csv')

    close = prices['adjclose']
    ema13 = talib.EMA(close, 13)
    ema26 = talib.EMA(close, 26)
    itrend_quick = indic.compute_instTrend(close, 0.07)
    itrend_slow = indic.compute_instTrend(close, 0.038)
    prices['signal3'] = ema13.tolist()
    prices['signal4'] = ema26.tolist()
    prices['itrend_quick'] = itrend_quick
    prices['itrend_slow'] = itrend_slow


    signal = []
    for i in range(0, len(prices['itrend_quick'])):
        signal.append( ( (prices['itrend_quick'][i] - prices['itrend_slow'][i]) / close[i] ) * 100.)

    x = []
    y = []
    for i in range(0, len(prices) - 10):
        if (signal[i] > 1.0):
            x.append(signal[i])
            y.append((((close[i+5] / close[i] ) -1.) * 100.))

data = {'signal': x, 'gain': y}
df = pd.DataFrame(data)

plt.scatter(df['signal'], df['gain'])

z = np.polyfit(x, y, 1)
p = np.poly1d(z)
plt.plot(x,p(x),"r--")

plt.show()