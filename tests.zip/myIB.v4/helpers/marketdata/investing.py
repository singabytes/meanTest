#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def date(timestamp):
    return timestamp.split(' ')[0]

import investpy
import pickle
import csv
import traceback
import helpers.marketdata.utils as utils

    
def marketdata(ticker, start_date, end_date, asset_type = 'equity', country = 'united states'):
    ohlc = 0

    tmp = start_date.split('-')
    start_date = tmp[2] + '/' + tmp[1] + '/' + tmp[0]
    
    tmp = end_date.split('-')
    end_date = tmp[2] + '/' + tmp[1] + '/' + tmp[0]
    
    try:
        if (asset_type == 'etf'):
            ohlc = investpy.get_etf_historical_data(etf = ticker,
                                                    country = country,
                                                    from_date = start_date,
                                                    to_date = end_date)
        elif (asset_type == 'bond'):
            ohlc = investpy.get_bond_historical_data(bond = ticker,
                                                     from_date = start_date,
                                                     to_date = end_date)
        elif (asset_type == 'commodity'):
            ohlc = investpy.get_commodity_historical_data(commodity = ticker, 
                                                          from_date = start_date,
                                                          to_date = end_date)
        elif (asset_type == 'index'):
            ohlc = investpy.get_index_historical_data(index = ticker,
                                                      country = country,
                                                      from_date = start_date,
                                                      to_date = end_date)
        elif (asset_type == 'equity'):
            ohlc = investpy.get_stock_historical_data(stock = ticker,
                                                      country = country,
                                                      from_date = start_date,
                                                      to_date = end_date)
    except:
        print('*** Ticker cannot be found : ', ticker)
        print(traceback.format_exc())

    return ohlc
