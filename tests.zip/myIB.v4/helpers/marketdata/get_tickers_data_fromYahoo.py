#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def date(timestamp):
    return timestamp.split(' ')[0]

from yahooquery import Ticker
import logging
import pandas as pd  
import pickle
import csv

count = 0

tickers = []
industry_arr = []
sector_arr = []
currentPrice_arr = []
targetHighPrice_arr = []
targetLowPrice_arr = []
targetMeanPrice_arr = []
targetMedianPrice_arr = []
recommendationMean_arr = []
recommendationKey_arr = []
numberOfAnalystOpinions_arr = []

df = pd.DataFrame()  

with open('/home/patrick/algo/myway/russell-1000.csv') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        count = count + 1
        if ('*' in row[0]):
            continue
        ticker = row[1].strip()
        print(count, ticker)
        try:
            req = Ticker(ticker)
            industry = req.asset_profile[ticker]['industry']
            sector = req.asset_profile[ticker]['sector']
            currentPrice  = req.financial_data[ticker]['currentPrice']
            targetHighPrice = req.financial_data[ticker]['targetHighPrice']
            targetLowPrice = req.financial_data[ticker]['targetLowPrice']
            targetMeanPrice = req.financial_data[ticker]['targetMeanPrice']
            targetMedianPrice = req.financial_data[ticker]['targetMedianPrice']
            recommendationMean = req.financial_data[ticker]['recommendationMean']
            recommendationKey = req.financial_data[ticker]['recommendationKey']
            numberOfAnalystOpinions = req.financial_data[ticker]['numberOfAnalystOpinions']
            
            if (industry != '' and sector != '' and targetHighPrice != '' and
                targetLowPrice != '' and targetMeanPrice != '' and
                currentPrice != '' and 
                targetMedianPrice != '' and recommendationMean != '' and
                recommendationKey != '' and numberOfAnalystOpinions != ''):
                tickers.append(ticker)
                industry_arr.append(industry)
                sector_arr.append(sector)
                currentPrice_arr.append(currentPrice)
                targetHighPrice_arr.append(targetHighPrice)
                targetLowPrice_arr.append(targetLowPrice)
                targetMeanPrice_arr.append(targetMeanPrice)
                targetMedianPrice_arr.append(targetMedianPrice)
                recommendationMean_arr.append(recommendationMean)
                recommendationKey_arr.append(recommendationKey)
                numberOfAnalystOpinions_arr.append(numberOfAnalystOpinions)
        except BaseException as error:
            print('An exception occurred: {}'.format(error))
            print('*** Ticker cannot be found : ', ticker)
            continue

data = {'industry': industry_arr, 'sector': sector_arr, 
        'currentPrice': currentPrice_arr, 'targetHighPrice' : targetHighPrice_arr,
        'targetLowPrice': targetLowPrice_arr, 'targetMeanPrice': targetMeanPrice_arr,
        'targetMedianPrice': targetMedianPrice_arr, 'recommendationMean': recommendationMean_arr,
        'recommendationKey' : recommendationKey_arr, 'numberOfAnalystOpinions': numberOfAnalystOpinions_arr }
  
# Creates pandas DataFrame.
df = pd.DataFrame(data, index = tickers)

outfile = open('tickers_data','wb')
pickle.dump(df, outfile)
