import datetime
from datetime import timedelta

# DATE

def today_date(format):
    today = date.today()
    
    # dd/mm/YY
    if format == ('d/m/y'):
        d1 = today.strftime("%d/%m/%Y")
        return d1
    
    d1 = today.strftime("%Y%m%d")
    return d1

def add_days_to_date(date = None, nb_days = 1, format = 'y-m-d'):
    if (date == None):
        date = date.today()
    
    new_date = date + timedelta(days=nb_days)
    
    # dd/mm/YY
    if format == ('d/m/y'):
        d1 = new_date.strftime("%d/%m/%Y")
        return d1
    
    # YY-mm-dd
    if format == ('y-m-d'):
        d1 = new_date.strftime("%Y-%m-%d")
        return d1
    
    d1 = new_date.strftime("%Y%m%d")
    return d1

def convert_to_datetime(date):
        yy = date.split('-')[0]
        mm = date.split('-')[1]
        dd = date.split('-')[2]
        
        if (mm[0] == '0'):
            mm = mm[1]
        if (dd[0] == '0'):
            dd = dd[1]
        
        return datetime.date(int(yy), int(mm), int(dd))
    