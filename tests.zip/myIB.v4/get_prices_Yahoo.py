import pandas as pd
import logging

import helpers.marketdata.yahoo

logger = logging.getLogger(__name__)
#format = '[%(filename)s:%(lineno)s] %(message)s'
format = '%(asctime)s;%(levelname)s;%(message)s'
logging.basicConfig(filename = 'get_prices_yahoo.log', filemode = 'w', format = format)
logger.setLevel(logging.DEBUG)

start_date = '2010-01-01'
end_date = '2021-01-01'
# expected len = 2769

#Test Yahoo query on IBM :
#Nov 19, 2021	116.49	116.56	115.27	116.05	114.67	5,380,200
#Nov 18, 2021	118.36	118.36	116.31	116.66	115.27	5,046,900
#Nov 17, 2021	118.38	119.33	117.78	118.06	116.65	4,043,300
#Nov 16, 2021	118.92	119.90	118.42	118.46	117.05	4,750,800
#Nov 15, 2021	119.54	120.16	118.31	118.87	117.46	5,046,300
#Nov 12, 2021	120.00	120.64	118.78	118.96	117.54	5,414,800
#Nov 11, 2021	120.90	121.79	120.08	120.27	118.84	4,643,300
#Nov 10, 2021	121.00	122.43	119.93	120.22	118.79	6,270,300
#Nov 09, 2021	122.56	122.90	120.26	120.85	119.41	7,236,600


path = './data/'
tickers = pd.read_csv(path + 'sp500_constituents.csv')

saved_tickers = []

for ticker in tickers['Symbol']:
    if ticker[0] == '#':
        continue
    print(ticker)
    md = helpers.marketdata.yahoo.marketdata(ticker = ticker, start_date = start_date, end_date = end_date)
    # report
    date_start = md.index[0].strftime('%Y-%m-%d')
    date_end = md.index[-1].strftime('%Y-%m-%d')
    nb_data = len(md)
    logger.info(ticker + ' - ' + str(nb_data) + ' - ' + date_start + ' - ' + date_end)
    md.to_csv(path + 'yahoo/' + ticker + '.csv')
    # save
    if nb_data > 2500:
        print('saved')
        md.to_csv(path + 'yahoo/clean/' + ticker + '.csv')
        saved_tickers.append(ticker)

with open(path + 'yahoo/clean/saved_ticker.csv', 'w') as outfile:
    outfile.write("\n".join(saved_tickers))

print('Pulled {} tickers - Saved {} tickers'.format(len(tickers), len(saved_tickers)))