import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import SearchIcon from '@material-ui/icons/Search';

import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import TinyBarCharts from './TinyBarCharts'
import Avatar from '@material-ui/core/Avatar';
import Rating from '@material-ui/lab/Rating';
import Tooltip from '@material-ui/core/Tooltip';
import TinyPieCharts from './TinyPieCharts';
import { Hidden } from '@material-ui/core';



const useStyles = makeStyles({

  table: {
    cursor: "pointer",
    minWidth: "400px",
    maxWidth: "400px",
  },
  space: {
    lineHeight: '2px',
  },
  saut:{
    marginBottom: '1em',
    
    
  },
  numeric: {
    fontSize: 'medium',
  },
  divleft: {
    float: 'left',
    verticalAlign: 'middle',
    textAlign: 'center',
    marginRight: '10px',
    marginTop: '8px',
  },
  gagnant: {
    backgroundColor: "#3F51B5",
  },
  place: {
    backgroundColor: "#3F6AB5",
  },
  codeSelection:{
    fontSize: "1.2em",
  },
 

  invisible:{
    backgroundColor: "#FAFAFA",
  },
  title: {
    flex: '1 1 100%',
  },
});



const data = [
  {"id":1,"code":"S-0001","utilisateur":"information@dataturf.fr","backtestDTO":[{"id":1,"idSelection":1,"progression":"up","exp":"1 252","pari":"SIMPLE_PLACE","pourcentageReussite":58,"solde":"-5.8","rendement":"36.8"}]},
  {"id":2,"code":"S-0452","utilisateur":"information@dataturf.fr","backtestDTO":[{"id":1,"idSelection":1,"progression":"down","exp":"45","pari":"SIMPLE_GAGNANT","pourcentageReussite":23,"solde":"10.8","rendement":"2.5"}]},
 ];

function clickit(callbackFunction, data) {
  callbackFunction(data)
}

export default function TableSelections(props) {
  const classes = useStyles();

  return (
   <div>
   
      <Table stickyHeader className={classes.table} size='small'>
        <TableHead>
          <TableRow>
            <TableCell   align="center"><b>Pari</b></TableCell>
            <TableCell  align="center"><b>Exp.</b></TableCell>
            <TableCell  align="center"><b>R.</b></TableCell>
            <TableCell  align="center"><b>Gain</b></TableCell>
            <TableCell  align="center"><b>Rde.</b></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
        {data.map(row => (
            <TableRow key={row.name} onClick={() => clickit(props.callbackFunction, {'id':row.id, 'code':row.code})} >
              
              {(row.backtestDTO[0].pari == 'SIMPLE_PLACE') && (
                    <TableCell align="center"><span style={{fontSize:".900em"}}>SP</span></TableCell>
              )}
              {(row.backtestDTO[0].pari == 'SIMPLE_GAGNANT') && (
                    <TableCell align="center"><span style={{fontSize:".900em"}}>SG</span></TableCell>
              )}

                <TableCell align="center">
                    
                    <span className={classes.numeric} style={{color:"#7B7B7B", fontSize:".900em"}}>
                       {row.backtestDTO[0].exp}</span>
                       </TableCell>

              <TableCell align="center">
                <span style={{fontSize:".875em"}}>{row.backtestDTO[0].pourcentageReussite + " %"}</span>
              </TableCell>
              {(row.backtestDTO[0].solde >= 0) && (
                    <TableCell align="center">
                    
                    <span className={classes.numeric} style={{color:"green", fontSize:".900em"} }>
                      {row.backtestDTO[0].solde + " €"}</span>
                      </TableCell>
              )}
              {(row.backtestDTO[0].solde < 0) && (
                    <TableCell  align="center">
                  
                    <span className={classes.numeric}  style={{color:"#d62728", fontSize:".900em"}}>
                      {row.backtestDTO[0].solde  + " €"}</span>
                     
                      </TableCell>
              )}

              
                    <TableCell align="center">
                    
                   <span className={classes.numeric} style={{color:"#7B7B7B", fontSize:".900em"}}>
                      {row.backtestDTO[0].rendement + " %"}</span>
                      </TableCell>
              

                
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
    </div>
  );
}