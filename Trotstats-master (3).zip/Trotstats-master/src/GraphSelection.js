import React, { PureComponent } from 'react';
import {
  BarChart, Bar, Brush, ReferenceLine, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

const data = [
  { name: '1', gain: 1, pv: 456 },
  { name: '2', gain: -1, pv: 230 },
  { name: '3', gain: -1, pv: 345 },
  { name: '4', gain: -1, pv: 450 },
  { name: '5', gain: 1, pv: 321 },
  { name: '6', gain: 1, pv: 235 },
  { name: '7', gain: -1, pv: 267 },
  { name: '8', gain: 1, pv: -378 },
  { name: '9', gain: -1, pv: -210 },
  { name: '10', gain: 1, pv: -23 },
  { name: '12', gain: -1, pv: 45 },
  { name: '13', gain: -1, pv: 90 },
  { name: '14', gain: -1, pv: 130 },
  { name: '15', gain: -1, pv: 11 },
  { name: '16', gain: -1, pv: 107 },
  { name: '17', gain: -1, pv: 926 },
  { name: '18', gain: -1, pv: 653 },
  { name: '19', gain: 1, pv: 366 },
  { name: '20', gain: 1, pv: 486 },
  { name: '21', gain: 1, pv: 512 },
  { name: '22', gain: 1, pv: 302 },
  { name: '23', gain: 1, pv: 425 },
  { name: '24', gain: 1, pv: 467 },
  { name: '25', gain: 1, pv: -190 },
  { name: '26', gain: -1, pv: 194 },
  { name: '27', gain: -1, pv: 371 },
  { name: '28', gain: -1, pv: 376 },
  { name: '29', gain: -1, pv: 295 },
  { name: '30', gain: -1, pv: 322 },
  { name: '31', gain: -1, pv: 246 },
  { name: '32', gain: 1, pv: 33 },
  { name: '33', gain: 1, pv: 354 },
  { name: '34', gain: 1, pv: 258 },
  { name: '35', gain: -1, pv: 359 },
  { name: '36', gain: -1, pv: 192 },
  { name: '37', gain: -1, pv: 464 },
  { name: '38', gain: -1, pv: -2 },
  { name: '39', gain: -1, pv: 154 },
  { name: '40', gain: -1, pv: 186 },
];

export default class GraphSelection extends PureComponent {
    constructor(props){
        super(props);
        this.state = {
            width: this.props.width,
            height: this.props.height
        }
    }

    // const CustomTooltip = ({ active, payload, label }) => {
    //     if (active) {
    //       return (
    //         <div className="custom-tooltip">
    //           <p className="label">{`${label} : ${payload[0].value}`}</p>
    //           <p className="intro">{'${jockey} '}</p>
    //           <p className="desc">Anything you want can be displayed here.</p>
    //         </div>
    //       );
    //     }

  render() {
    return (
      <BarChart
        width={this.state.width}
        height={this.state.height}
        data={data}
        margin={{
          top: 5, right: 20, left: 20, bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend verticalAlign="top" wrapperStyle={{ lineHeight: '40px' }} />
        <ReferenceLine y={0} stroke="#000" />
        <Brush dataKey="name" height={30} stroke="#8884d8" /> 
        <Bar dataKey="gain" fill="#8884d8" />
      </BarChart>
    );
  }
}
