import React from 'react';
import { makeStyles, createStyles, Theme } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import Avatar from '@material-ui/core/Avatar';
import ImageIcon from '@material-ui/icons/Image';
import WorkIcon from '@material-ui/icons/Work';
import BeachAccessIcon from '@material-ui/icons/BeachAccess';
import UpdateIcon from '@material-ui/icons/Update';


const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    button: {
      margin: theme.spacing(1),
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
  
  }),
);

export default function SimpleContainer() {
  const classes = useStyles();
 
  return (
    <div className={classes.root}>

    <Card>
      <CardContent>
      <Grid container spacing={3}>
      <Grid item xs={12}>
      <Card>
      <CardContent>
      blabla de bienvenue + news
      </CardContent>
      </Card>
      </Grid>


        <Grid item xs={12} lg={6} xl={4}>
        <Card>
      <CardContent>
      <Table aria-label="simple table">
        
        <TableBody>
         
            <TableRow>
              <TableCell component="th" scope="row">
                Nombre de sélections
              </TableCell>
              <TableCell align="right">145</TableCell>
            </TableRow>
            <TableRow>
              <TableCell component="th" scope="row">
                Nombre de stratégies sous-jacentes
              </TableCell>
              <TableCell align="right">452</TableCell>
            </TableRow>
          
        </TableBody>
      </Table>
      </CardContent>
      </Card>
        </Grid>

<Grid item xs={12} lg={6} xl={8}>
        <Card>
      <CardContent>
      <List>
      <ListItem>
        <ListItemAvatar>
          <Avatar>
            <UpdateIcon />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Nouvelle version 1.2 : amélioration de la performance" secondary="12 Janvier 2020 " />
      </ListItem>
      <ListItem>
        <ListItemAvatar>
          <Avatar>
            <UpdateIcon />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Nouveau indicateur statistiques !" secondary="8 Janvier 2020 " />
      </ListItem>
     
    </List>
      </CardContent>
      </Card>
        </Grid>

      </Grid>  
      </CardContent>
    </Card>

      
    


    
    </div>
    
  );
}
