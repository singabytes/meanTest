var testGraph1 = {
    title: {
      text: "Repartition courses gagnantes",
      x: "center"
    },
    tooltip: {
      trigger: "item",
      formatter: "{a} <br/>{b} : {c} ({d}%)"
    },
    legend: {
      orient: "vertical",
      left: "left",
      data: ["Cat I", "Cat II", "Cat III"]
    },
    series: [
      {
        name: "Courses gagnantes",
        type: "pie",
        radius: "80%",
        center: ["50%", "60%"],
        data: [
          {
            value: 50,
            name: "Cat I"
          },
          {
            value: 22,
            name: "Cat II"
          },
          {
            value: 28,
            name: "Cat III"
          }
        ],
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: "rgba(0, 0, 0, 0.5)"
          }
        }
      }
    ]
  }

  export default testGraph1
