import React, { PureComponent } from 'react';
import MUIDataTable from "mui-datatables";
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import {
  BarChart, Bar, Brush, ReferenceLine, Line, ComposedChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { red } from '@material-ui/core/colors';


export default class GraphSelection extends PureComponent {
    constructor(props){
        super(props);
        this.state = {
          courseSelected: 0
      }
    }
    
    // const CustomTooltip = ({ active, payload, label }) => {
    //     if (active) {
    //       return (
    //         <div className="custom-tooltip">
    //           <p className="label">{`${label} : ${payload[0].value}`}</p>
    //           <p className="intro">{'${jockey} '}</p>
    //           <p className="desc">Anything you want can be displayed here.</p>
    //         </div>
    //       );
    //     }

  handleBrushChange(index) {
    const ref = this.props.userSelection.backtestDTO[0].evolution.bilan[index.startIndex].solde
    const length = this.props.userSelection.backtestDTO[0].evolution.bilan.length
    for (let i = 0; i < length; i++) {
      // if (ref < 0) {
      //   this.props.userSelection.backtestDTO[0].evolution.bilan[i].solde = this.props.userSelection.backtestDTO[0].evolution.bilan[i].solde + ref;
      //  } 
      //  else {
          this.props.userSelection.backtestDTO[0].evolution.bilan[i].solde = this.props.userSelection.backtestDTO[0].evolution.bilan[i].solde - ref;
      //  }
    }
  }

    handleBarClick = (data, index) => {
      console.log("click on bar - " + index)
      this.setState({
        courseSelected: index,
      });
    }



    getMuiTheme = () =>
    createMuiTheme({
      overrides: {
        setCellHeaderProps: {
          root: {
            visible: false
          }
        },
        MUIDataTable: {
          root: {
            backgroundColor: "#FF0000",
          },
          paper: {
            boxShadow: "none"
          }
        },
        MUIDataTableBodyCell: {
          root: {
            // backgroundColor: "#FF0000",
            margin: 0,
            padding: 2,
            fontSize: '12px'
          }
        }
      }
    });

  render() {
  
  return (<div>
    <Box display="flex" flexDirection="row" alignItems="flex-top" bgcolor="background.paper">
    <Box flexGrow={1}>
    <ResponsiveContainer width="99%">
    <ComposedChart
    // width={ this.props.width }
    // height={ this.props.height }
    data={ this.props.userSelection.backtestDTO[0].evolution.bilan }
    margin={{
      top: 0, right: 0, bottom: 0, left: 0,
    }}
    >
    <CartesianGrid stroke="#f5f5f5" />
    <XAxis dataKey="date" label={{ value: 'Courses', position: 'insideBottomRight', offset: 0 }} />
    <YAxis yAxisId="left" label={{ value: 'Gain cumule (euros)', angle: -90, position: 'Left' }} />
    <YAxis yAxisId="right" orientation="right" label={{ value: 'Gain (euros)', angle: 90, position: 'Right' }} />
    <Tooltip />
    <Legend verticalAlign="top" wrapperStyle={{ lineHeight: '40px' }} />
    <Bar yAxisId="right" dataKey="gain" barSize={20} fill="#8884d8" onClick={ this.handleBarClick} />
    <Line yAxisId="left" type="monotone" dataKey="solde" stroke="#ff7300" strokeWidth="3" />
    <Brush dataKey="date" heigth={10} stroke="#8884d8" onChange={ this.handleBrushChange.bind(this)} />
  </ComposedChart>
  </ResponsiveContainer>
  </Box>  
  {/* styling https://github.com/gregnb/mui-datatables/issues/201 */}
<Box flexGrow={1}>
      {/* <BasicTreeTable/> */}
      <MuiThemeProvider theme={this.getMuiTheme()}>
      <MUIDataTable
      // title={"Details course"}
      const data = { [
        ["code course = " + this.state.courseSelected ],
        ["heure course = " + this.state.courseSelected ],
        ["Hippo course = " + this.state.courseSelected ],
        ["code course = " + this.state.courseSelected ],
        ["code course = " + this.state.courseSelected ],
        ["heure course = " + this.state.courseSelected ],
        ["Hippo course = " + this.state.courseSelected ],
        ["code course = " + this.state.courseSelected ],
        ["code course = " + this.state.courseSelected ],
        ["heure course = " + this.state.courseSelected ],
        ["Hippo course = " + this.state.courseSelected ],
        ["code course = " + this.state.courseSelected ],
       ] }
      columns={ [ { name: "Info course", label: '', options: { sort: false, viewColumns: false } } ] }
      options={ { selectableRows: false, pagination: false, selectableRowsHeader: false, viewColumns: false, print: false, download: false, sort: false, filter: false, search: false,
      // setTableProps: () => {
      //   return {
      //     size: "small",
      //     background: red,
      //     backgroundColor: "#FF000"
      //   };
      // },
      // setCellProps: () => {
      //   return {
      //     size: "small",
      //     background: red,
      //     backgroundColor: "#FF000"
      //   };
      // },
       setCellHeaderProps: () => {
        return {
          backgroundColor: '#FF0000'
        };
      },
      
       } }  
      />
      </MuiThemeProvider>
</Box></Box>
</div>
  )
}
}
