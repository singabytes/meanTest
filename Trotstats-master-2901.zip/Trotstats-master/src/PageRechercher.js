import React from 'react';
import ReactFilterBox, {SimpleResultProcessing,Expression} from "react-filter-box";
import data from "./data/data";
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import TableSelections from './TableSelections'

import "react-filter-box/lib/react-filter-box.css"

export default class PageRecherche extends React.Component {
 
  constructor(props){
    super(props);
    this.state = {
        data: data,
        searchStatus: 'busy'
    }

     this.options = [
        {
            columnField: "Hippodrome.Nom",
            type:"selection"
        },
        {
            columnField: "Course.Nom",
            type:"selection"
        },
        {
            columnField: "Driver.Nom",
            type:"selection"
        },
    ];
}

onParseOk(expressions){
    console.log('parse ok in page Recherche')
    console.log(expressions)
    this.setState( { searchStatus: 'Parse OK' } )
}
onChange(expressions){
    this.setState( { searchStatus: 'Changing' } )
}
onParseError(expressions){
    this.setState( { searchStatus: 'Parse Error' } )
}
onDataFiltered(expressions){
    this.setState( { searchStatus: 'Data Filtering' } )
}
onBlur(expressions){
    this.setState( { searchStatus: 'Blur ON' } )
}
onFocus(expressions){
    this.setState( { searchStatus: 'Focus ON' } )
}


render(){
    var rows = this.state.data;
    return <div className="main-container"> 
     <Paper>
         
    <ReactFilterBox 
                query={this.state.query}
                data={data}
                options={this.options}
                onParseOk={this.onParseOk.bind(this)}
                onChange={this.onChange.bind(this)}
                 />
      <h3>Status : {this.state.searchStatus}</h3>
      <div style={{float:'right', marginTop:'1em', marginBottom:'1em'}}>
   <Button variant="contained" color="primary">
  Rechercher
</Button>
</div>

          <TableSelections/>
      </Paper>
      </div>
      
}
}
