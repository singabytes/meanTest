import React from 'react'
import ReactFilterBox, {SimpleResultProcessing,Expression} from "react-filter-box"
import data from "./data/data"
import Paper from '@material-ui/core/Paper'
import Tab from '@material-ui/core/Tab'
import Tabs from '@material-ui/core/Tabs'
import TableSelections from './TableSelections'
import GraphSelection from './GraphSelection'
import SplitPane from 'react-split-pane'
import Box from '@material-ui/core/Box'
import UserSelection from './UserSelection'
import AppBar from '@material-ui/core/AppBar'
import { Link, Route, BrowserRouter, Switch } from "react-router-dom";
import "react-filter-box/lib/react-filter-box.css"
import './react-split-pane.css';

export default class PageRecherche extends React.Component {
 
  constructor(props){
    super(props);
    this.state = {
        data: data,
        searchStatus: 'busy',
        userSelection: {"id":0,"code":"0","utilisateur":"0","backtestDTO":[{"id":0,"idSelection":0,"progression":"","exp":"0","pari":"","pourcentageReussite":0,"solde":"0","rendement":"","evolution":{"bilan":[{"date":"0", "solde":"0", "course":"0", "win":"0", "gain":"0"}]}}]},
    }

    this.options = [
      {
        columnField: "Hippodrome.Nom",
        type:"selection"
      },
      {
        columnField: "Course.Nom",
        type:"selection"
      },
      {
        columnField: "Driver.Nom",
        type:"selection"
      },
    ];
  }

  paneStyles = {
    styleA : { marginLeft: '6em', background: '#FFFFFF' },
    styleB : { background: '#aaa4ba' },
    styleC : { background: '#000' },
    styleD : { padding: '2em' } 
  }

  onParseOk(expressions){
    this.setState( { searchStatus: 'Parse OK' } )
  }
  onChange(expressions){
    this.setState( { searchStatus: 'Changing' } )
  }
  onParseError(expressions){
    this.setState( { searchStatus: 'Parse Error' } )
  }

  callbackFromSelectionTable = (selection) => {
    console.log('callback from SelectionTable : selection = ' + selection.id + " -- " + selection.code)
    this.setState( { userSelection: selection })
  }

  render(){
    var rows = this.state.data;
    return <div className="main-container"> 
 
    <SplitPane
      split="vertical"
      minSize={410}
      maxSize={800}
      defaultSize={410}
      className="primary"
      // pane1Style = { this.paneStyles.styleA }
      resizerStyle = { this.paneStyles.styleC } >
      <Box component="div" overflow="auto">
        <TableSelections callbackFunction={this.callbackFromSelectionTable}/>
      </Box>
      <SplitPane 
        split="horizontal"
        // defaultSize={500}
        
        // paneStyle={this.paneStyles.styleD}
        // pane2Style={this.paneStyles.styleB}
        // resizerStyle = { this.paneStyles.styleC } >
        >
        // <Box component="div" overflow="scroll">
        {/* <ReactFilterBox 
          query={this.state.query}
          data={data}
          options={this.options}
          onParseOk={this.onParseOk.bind(this)}
          onChange={this.onChange.bind(this)}
          onParseError={this.onParseError.bind(this)}
          />
          <h5>Status : {this.state.searchStatus}</h5>
          <h5>User selected : { this.state.selectionId } - { this.state.selectionCode } </h5> */}
        <GraphSelection width = {800} height = {300} userSelection= { this.state.userSelection } />
        </Box>
        <Box component="div" overflow="scroll">
        <BrowserRouter>
        <AppBar position="static">
        <Tabs 
            // onChange={handleChange}
            indicatorColor="primary"
            textColor="primary"
            centered
          >
          <Tab label="Item One" component= { Link } to= '/one' />
          <Tab label="Item Two" component= { Link } to= '/two' />
          <Tab label="Item Three" component= {Link} to= '/three' />
        </Tabs>
        </AppBar>
        <Switch>
            <Route path='/one' component={<h1>hello</h1>} />
            <Route path='/two' component={UserSelection} />
        </Switch>
      </BrowserRouter>
      </Box>
      </SplitPane>
    </SplitPane>
    </div>

}
}
