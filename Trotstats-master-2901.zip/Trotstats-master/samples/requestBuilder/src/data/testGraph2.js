  var testGraph2 = {
    tooltip : {
        formatter: "{a} <br/>{b} : {c}%"
    },
    toolbox: {
        feature: {
            restore: {},
            saveAsImage: {}
        }
    },
    series: [
        {
            name: 'Forme Cheval',
            type: 'gauge',
            detail: {formatter:'{value}%'},
            data: [{value: 50, name: 'Forme Factor'}]
        }
    ]
  }

export default testGraph2