import React from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme, Theme, createStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import Button from '@material-ui/core/Button';

import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import SearchIcon from '@material-ui/icons/Search';
import MailIcon from '@material-ui/icons/Mail';
import { Switch, Route, Link, BrowserRouter, Redirect } from "react-router-dom"
import TableSelections from './TableSelections'
import TestBarChart from './TestBarChart'
import TablePariHistorique from './TablePariHistorique'
import PageRechercherWithSplitPane from './PageRechercherWithSplitPane'
import ExtensionIcon from '@material-ui/icons/Extension';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableSyntheseSelection from './TableSyntheseSelection'

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';

import Tab from '@material-ui/core/Tab'
import Tabs from '@material-ui/core/Tabs'



const drawerWidth = 240;


const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
    },
    appBar: {
      zIndex: theme.zIndex.drawer + 1,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
    },
    appBarShift: {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },

  
    title: {
      flexGrow: 1,
    },
    
  
    toolbar: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
    },
    content: {
      flexGrow: 1,
      marginTop: '5em',
      // padding: theme.spacing(3),
    },
  }),
);

export default function Dashboard() {
  const classes = useStyles();
  const theme = useTheme();
  // variable for the drawer
  const [open, setOpen] = React.useState(false);
  // showTableParis = true > show TableParis else show TableSelection
  // click on one TableSelection row to go to showTableParis
  const [showTableParis, setShowTableParis] = React.useState(false);
  // dataTableParis = data passed from TableSelection to TableParis
  const [dataTableParis, setDataTableParis] = React.useState(null);


  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >
        <Toolbar>
         
          <img width='75' src={"/images/logo3.png"}></img>
          <Typography variant="h6" className={classes.title}>
     
    </Typography>
    

        </Toolbar>
      </AppBar>
    
      <Container style={{marginTop:'5em', minWidth:'950px', maxWidth:'950px', backgroundColor: '#FAFBFC',height: '100vh' }}>
      <TextField style={{marginTop:'1em', width:'802px'}} id="outlined-basic" label="Rechercher une sélection" variant="outlined" />
    
      <Fab style={{marginTop:'1em', marginLeft:'2em'}} color="primary" aria-label="Search">
        <SearchIcon />
      </Fab>

        <div style={{width:'900px', marginTop:'10px'}}>
        <ExpansionPanel>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography className={classes.heading}>Sélections pré-calculées</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
        <TableSyntheseSelection/>
        </ExpansionPanelDetails>
      </ExpansionPanel>
        </div>


        <div style={{width:'900px'}}>
        <div style={{float:'left', marginTop:'1em', width:'49%'}}>
        <Card style={{width:'100%'}}>
      <CardContent>
      <Typography className={classes.title} color="textSecondary" gutterBottom>
          Informations sur les courses
        </Typography>

           <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Période analysée</TableCell>
              <TableCell align="right">01/01/2008 - 01/02/2020</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Nombre de jours</TableCell>
              <TableCell align="right">406</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Nombre de courses</TableCell>
              <TableCell align="right">1 205</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Dynamique de jeu</TableCell>
              <TableCell align="right">2</TableCell>    
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>

        <div style={{float:'right',marginTop:'1em', width:'49%'}}>
        <Card style={{witdh:'100%'}}>
      <CardContent>
      <Typography className={classes.title} color="textSecondary" gutterBottom>
          Bilan des performances
        </Typography>

          <Table style={{width:'100%'}} aria-label="simple table">
        
        <TableBody>
          <TableRow>
              <TableCell align="left">Type de pari</TableCell>
              <TableCell align="right">Simple placé</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Réussite</TableCell>
              <TableCell align="right">33 %</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Rendement</TableCell>
              <TableCell align="right">5,6 %</TableCell>    
          </TableRow>
          <TableRow>
              <TableCell align="left">Gain / Perte</TableCell>
              <TableCell align="right">+ 63,5 €</TableCell>    
          </TableRow>
          </TableBody>
      </Table>

      </CardContent>
      
    </Card>
        </div>
        
        </div>

        <div style={{width:'900px', marginTop:'22em'}}>

          <Card style={{width:'100%'}}>
      <CardContent>
      <Typography className={classes.title} color="textSecondary" gutterBottom>
        </Typography>
        <TestBarChart style={{marginTop:'10em'}}/>
          

      </CardContent>
      
    </Card>

        
        </div>

<div style={{width:'900px', marginTop:'1em'}}>
        <BrowserRouter>
<AppBar position="static">
<Tabs 
// onChange={handleChange}
value={0}
indicatorColor="primary"
textColor="white"
centered
>
<Tab label="Pronostics du jour" component= { Link } to= '/two' />
<Tab label="Historique des paris" component= { Link } to= '/three' />
<Tab label="Distribution des écarts" component= { Link } to= '/four' />

</Tabs>
</AppBar>
<Switch>
<Route path='/two' component={TablePariHistorique} />
<Route path='/three' component={TablePariHistorique} />


</Switch>
</BrowserRouter>
</div>
        

      </Container>
    </div>
  );
}
