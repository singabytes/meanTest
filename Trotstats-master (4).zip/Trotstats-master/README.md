# Trotstats  

This is the prototype for the page showing the strategy selection for the user  

to compile  
npm install  
npm link ./third-party/react-filter-box  

to start  
npm start

