import sys
sys.path.insert(0, "./repositories/mongodb/bond_data")
sys.path.insert(1, "./analytics/instruments")

import finra

date = '2024-09-27'
query = {'lastTradeDate': f'{date}'}
res = finra.get_bonds(query)
print(f'Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'couponType': 'FXPV'}
res = finra.get_bonds(query)
print(f'Fixed : Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'couponType': 'FRPV'}
res = finra.get_bonds(query)
print(f'Float : Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'couponType': 'FROT'}
res = finra.get_bonds(query)
print(f'Float2 : Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'couponType': 'FXPV', 'isCallable': 'Y'}
res = finra.get_bonds(query)
print(f'Fixed Callable : Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'couponType': 'FRPV', 'isCallable': 'Y'}
res = finra.get_bonds(query)
print(f'Float Callable : Total bonds for {date} is {len(res)}')

query = {'lastTradeDate': f'{date}', 'isPerpetual': 'Y'}
res = finra.get_bonds(query)
print(f'Perpetual : Total bonds for {date} is {len(res)}')

f = open('dump', 'w')
query = {'lastTradeDate': f'{date}'}
res = finra.get_bonds(query)
for bond in res:
    if bond['couponType'] is None:
        continue
    f.write(bond['couponType'] + '\n')
f.close()

'''
Total bonds for 2024-09-27 is 18407
Fixed : Total bonds for 2024-09-27 is 16385
Float : Total bonds for 2024-09-27 is 95
Float2 : Total bonds for 2024-09-27 is 0
Fixed Callable : Total bonds for 2024-09-27 is 12027
Float Callable : Total bonds for 2024-09-27 is 33
Perpetual : Total bonds for 2024-09-27 is 0

Row Labels	Count of coupon
CNGT	9
FRFF	754 - Fixed then Floating
FROT	51 - Floating: Floating
FRPV	95 - Floating: Fixed Margin over Index
FRSU	24 - StepUp
FXMF	6
FXPV	16385 - Fixed
FXRS	440 - Resetable
FXRV	2
FXZC	295 - Zero coupon
OTH	18
RGOT	102 - Rng 
STRP	17
VRGR	172 - Float then Var
(blank)	
Grand Total	18370
Total Bonds = 18407 so 37 coupon type = None

https://www.finra.org/sites/default/files/AppSupportDoc/p125839.pdf
FXAN Coupon Type Description 
FXDI Fixed: Annuity 
Fixed: Discount 
FXMF Fixed: With Multiple Frequencies of Payment
FXPM Fixed: Pay only at Maturity 
FXPP Fixed: Partly Paid 
FXPV Fixed: Plain Vanilla Fixed Coupon 
FRBF Floating: Bull/Reverse Floating Rate 
FRFF Floating: Fixed then Floating 
FRFX Floating: Floating then Fixed 
FRFZ Floating: Floating then Zero 
FROT Floating: Floating 
FRPM Floating: Pay at Maturity 
FRPV Floating: Fixed Margin over Index 
FRVR Floating: Floating then Variable 
FRZF Floating: Zero then Floating 
FXRV Floating: Fixed then Reverse Float 
VRFR Floating: Variable then Float 
VRDC Variable: Deferred Coupon 
ZCFX Strip: Zero then Fixed 
ZRFX Variable: Zero then Fixed 
ZRVR Variable: Zero then Variable 
FRSD Floating: Step Down-Margin over Index 
FRSU Floating: Step Up-Margin over Index 
VRGR Variable: Step Up/Step Down 
FXZC Fixed: Zero Coupon 
RGOT Range: Range 
STRP Strip 
TBPD To Be Priced

'''
