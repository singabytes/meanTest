$pythonProgramPath = "C:\Users\singapat\miniconda3\python.exe"
$pythonScriptPath = "C:\Users\singapat\code-prod\barchart\get_barchart_inst_to_mongo.py" 
$arg = ""
$pythonOutput = & $pythonProgramPath $pythonScriptPath $arg
$pythonOutput