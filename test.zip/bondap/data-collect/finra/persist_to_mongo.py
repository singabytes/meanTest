import json 
import os
import logging
import sys
from datetime import datetime
from pymongo import MongoClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler('parse_finra_to_mongo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

mode_persist = False

if mode_persist:
    cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    db = cluster['bond']
    collection = db['bond_static_data']

stats_collection = {}

#cleanup
if mode_persist:
    res = collection.delete_many({})
    logging.info(f'MongoDB Cleanup - {res.deleted_count} documents deleted.')
    stats_collection['deleted_docs_previous'] = res.deleted_count

def persist_data_to_mongo(data):
    try:
        collection.insert_one(data)
    except:
        logging.error(f'Could not persist to MongoDB : {data}')

now = datetime.now()
dt_string = now.strftime("%Y%m%d")
path = rf'C:\Users\Patrick\GitHub\bondap\data-collect\finra\dump-finra\{dt_string}'
dir_list = os.listdir(path)

if mode_persist:
    logging.info(f'Mode PERSIST ON')
else:
    logging.info(f'Mode STAT ON')

logging.info(f'Processing file in {path}')

count_total_instruments = 0

for file in dir_list:
    full_name = path + '\\' + file
    logging.info(f'Processing {full_name}')
    with open(full_name, 'r',encoding='utf-8') as file:
        text = file.read().replace('\n', '')

    text = text.replace('data":"[{', 'data":[{')
    text = text.replace('}]"}}', '}]}}')
    text = text.replace('\\','')
    data = json.loads(text)
    
    #check number of instruments
    instruments_from_request = data['returnBody']['headers']['Record-Total']
    all_instrument_data = data['returnBody']['data']

    count_instruments = 0
    if int(instruments_from_request[0]) > 0: # nstrument found in request
        for instrument_data in all_instrument_data:
            instrument_data['timestamp'] = data['returnBody']['headers']['Date'][0]
            #persist data to MongoDB
            if mode_persist:
                persist_data_to_mongo(instrument_data)        
            count_instruments = count_instruments + 1

    logging.info(f'File {full_name} has {count_instruments} matching request size : {instruments_from_request}')
    stats_collection['check_parsing'] = full_name + '-' + str(count_instruments)

    count_total_instruments = count_total_instruments + count_instruments

logging.info(f'Total number of instrument = {count_total_instruments}')
stats_collection['total_instruments'] = count_total_instruments
stats_collection['timestamp'] = dt_string

#persist stats to mongo
if not mode_persist:
    cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    db = cluster['bond']
    collection = db['logs_finra']
    try:
        collection.insert_one(stats_collection)
    except:
        logging.error(f'Could not persist stats_collection to MongoDB')