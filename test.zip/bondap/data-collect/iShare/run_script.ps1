$pythonProgramPath = "C:\Users\singapat\miniconda3\python.exe"
$pythonScriptPath = "iShare.py" 

$date = Get-Date -Format "yyyyMMdd"
$arg = "-d $date"

$pythonOutput = & $pythonProgramPath $pythonScriptPath $arg
$pythonOutput
