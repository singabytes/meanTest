
import sys
sys.path.insert(0, "./repositories/mongodb/bond_data")
sys.path.insert(1, "./analytics/instruments")

import finra
import fixed_bond
import QuantLib as ql

date = '2024-09-27'

bonds = finra.get_bonds_fixed(f'{date}')

#query = {'lastTradeDate': f'{date}', 'couponType': 'FXPV'}
#bonds = finra.get_bonds(query)

print(f'Float : Total bonds for {date} is {len(bonds)}')

bonds_priced = 0
bonds_priced_ok = 0
bonds_priced_nok = 0

f = open(r'c:\temp\dump', 'w')

for b in bonds:
    if (b['lastSaleYield'] is None): 
        #print(b)
        continue
    bonds_priced = bonds_priced + 1
    bond = fixed_bond.FixedRateBond()
    bond.construct_from_mongodoc(b)
    res = bond.get_analytics(ql.Date(27,8,2024), b['lastSalePrice'], 0)
    ytm = res['yield_to_maturity'] * 100
    ytm_finra = float(b['lastSaleYield'])
    error = ytm - ytm_finra
    if error < 0.001:
        bonds_priced_ok = bonds_priced_ok + 1
    else:
        bonds_priced_nok = bonds_priced_nok + 1
    print(b['cusip'], ytm, ytm_finra, error)
    f.write(b['cusip'] + ',' + str(ytm) + ',' + str(ytm_finra) + ',' + str(error) + '\n')

f.close()

print(f'Total bonds : {len(bonds)}')
print(f'Bond priced : {bonds_priced}')
print(f'Priced OK   : {bonds_priced_ok}')
print(f'Priced NOK  : {bonds_priced_nok}')

