import requests
import os
import json
import time
import logging
import sys
from pymongo import MongoClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler('parse_barchart_to_mongo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = cluster['bond']
collection = db['market_data']

#cleanup
#res = collection.delete_many({})
#logging.info(f'MongoDB Cleanup - {res.deleted_count} documents deleted.')

def persist_data_to_mongo(data):
    try:
        logging.info(f'Insert to Mongo : {data}')
        collection.insert_one(data)
    except:
        #logging.error(f'Could not persist to MongoDB : {key}')
        print(f'Could not persist to MongoDB : {data}')

def get_barchart_prices(symbol):
    if 'SQ' in symbol:
        #future
        print(f'Pulling future : {symbol}')
        os.system(f"curl --silent https://www.barchart.com/futures/quotes/{symbol} > output")
    else:
        #swap
        print(f'Pulling swap : {symbol}')
        os.system(f"curl --silent https://www.barchart.com/stocks/quotes/{symbol} > output")

    with open('output') as f:
        message = f.read()

    res = message.index('init({"symbol":"')
    string = message[res:res+100]
    symbol_request = string.split('"')[3]

    if symbol_request != symbol:
       logging.info(f'*** ALERT *** Got {symbol_request} Vs expected {symbol}')

    res = message.index('"quote":')
    string = message[res:res+1000]
    string = string.split('{')[1].split('}')[0] 
    string = '{' + string + '}'
    res_dict = json.loads(string)
    res_dict['symbol'] = symbol
    #change key name
    res_dict['timestamp'] = res_dict.pop('tradeTime')
    res_dict['date'] = res_dict['timestamp'].split('T')[0]
    return res_dict

all_futures = ['SQZ24','SQH25','SQM25','SQU25','SQZ25','SQH26','SQM26','SQU26','SQZ26','SQH27','SQM27','SQU27','SQZ27']
all_swaps = ['SOFR.RT','SOFRM1.RT','SOFRM3.RT','SOFRM6.RT','SOFWAPY1.RT','SOFWAPY2.RT','SOFWAPY5.RT','SOFWAPY7.RT','SOFAPY10.RT','SOFAPY15.RT','SOFAPY30.RT']


for future in all_futures:
    logging.info(f'Getting instrument : {future}')
    res = get_barchart_prices(future)
    time.sleep(1)
    persist_data_to_mongo(res)
    #print(future)
    #print(res)
    #print('---')

for swap in all_swaps:
    logging.info(f'Getting instrument : {swap}')
    res = get_barchart_prices(swap)
    time.sleep(1)
    persist_data_to_mongo(res)
    #print(swap)
    #print(res)
    #print('---')

