$date_from = "20250110"

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"
$session.Cookies.Add((New-Object System.Net.Cookie("__Secure-3PAPISID", "4evHeAu1Linrs11F/AwSUlgrwdoNmyJDZt", "/", ".google.com")))
$session.Cookies.Add((New-Object System.Net.Cookie("__Secure-3PSID", "g.a000sAj9uja3b678lG8R_QUKvuNYAQLyvgB94vd2eL_IO2GSAgNjxKXSkNFOs8TYtIsCz7ZBXAACgYKAfkSARISFQHGX2Mi11iIu5CIcZU-c6lQ4iRRsBoVAUF8yKp5TyQAXdlWAS_n5fn4izZW0076", "/", ".google.com")))
$session.Cookies.Add((New-Object System.Net.Cookie("NID", "520=aqHXKZhKrVyNF51r_5K0yYn0ZV9uLQMjTMubVmHGpHFnw8vCcwf400KGuqY3K5wZ4fzPxu8qR534-O-LUwboTR0YJ2SALe5UVuqDgxrKrjnEmr6dke7SbBntwROHmitgZhqaA2gKum4WZDFJ7kPa0SicKGvyvntB70Epv7UeaTMk5zUuC04f_A2mt7r5Zt211Cq1IHqRBuvyDVArVZonQ2bdMuuxNaGUhAkUwePHQSUn8LQB_507nDGxgs6JKuHS6_qkTHyOo9eMKsG_KRJaukOAAW30GlNAUEzBfSrr4A9BmLgSCJF0Jmp5o4t2e8DPtSjdzC8jqk-r6sWn-s9JHe1-NhoG0S516s9_6GMcjlOEuQ2_mAnasJDmsB2QYQK4W0rKfJzOIVI3xRucXbX_aRn6IKJuiM4wsD3oM8UmboeUvPmPDWstF_-UAatdJrcuNr4bObSk03Fz-DnxsaRYBh2fDhdHEkHJPLnAi2i3D3s9rBOkdo27wKMTRTUaLMAardR9cyGmbis97SEVPXUYAB5l8HxgROaWKDzh_yRE3j19qEisGNV4qqNeLJHI0Is_grdnk73CGJ32p3mYFoWNfHYQlzUWocvuPim-S4AUSZNsSM2N_rhRixwAuh4xS_NjTdevsvinLRwMbwx1or3tWTvSsunTzlvCjOVrN8YtsmIOUVYRO5fI_umqxwna89Jb3bqSPbkp8m3zsATQ8TWg7osAlHbctnurNi-lCp1GFBjAKq37qkaIeh0pAAc0M3M_ewdY7-2OXe1qYUNdFTZYkL3O4tBGHqnUxEyCNjOkA75MmoQVrOMdpGxbvTsU1zae_w2WWImrQKIF_inK2vpuRpcJiB-f8gQ46bNWcZdaQ3lU6AJ9i53ClI5eeBgw_K71", "/", ".google.com")))
$session.Cookies.Add((New-Object System.Net.Cookie("__Secure-3PSIDTS", "sidts-CjEBmiPuTbxHI9vB4HtwA8NB5qs4GCv-l69cMIxRG0Vt0lJt0DrkpMsmLzxtgmjURWlKEAA", "/", ".google.com")))
$session.Cookies.Add((New-Object System.Net.Cookie("__Secure-3PSIDCC", "AKEyXzUFw0kSjJdRgLOp-ZLjfO5xb3WlbfS4JYi0FOqlpZ59FI_1mv3ahFlxn4g8uE45X2kOyg", "/", ".google.com")))
Invoke-WebRequest -UseBasicParsing -Uri "https://analytics.google.com/g/collect?v=2&tid=G-P3LS8SG0QV&gtm=45je51d0v9104334479z8811255690za200zb811255690&_p=1737036064049&_gaz=1&gcd=13l3l3l3l1l1&npa=0&dma=0&tag_exp=101925629~102067555~102067808~102081485~102123608~102198178&cid=1576233481.1715610718&ul=en-us&sr=2560x1440&uaa=x86&uab=64&uafvl=Microsoft%2520Edge%3B131.0.2903.146%7CChromium%3B131.0.6778.265%7CNot_A%2520Brand%3B24.0.0.0&uamb=0&uam=&uap=Windows&uapv=15.0.0&uaw=0&are=1&pae=1&frm=0&pscdl=noapi&_s=12&sid=1737036028&sct=18&seg=1&dl=https%3A%2F%2Fwww.finra.org%2Ffinra-data%2Ffixed-income%2Fcorp-and-agency&dr=https%3A%2F%2Fwww.finra.org%2Ffinra-data%2Ffixed-income%2Fabout-cna-data&dt=Corporate%20and%20Agency%20Bonds%20%7C%20FINRA.org&en=Timer_30sec&_c=1&_et=13408&tfd=30593" `
-Method "POST" `
-WebSession $session `
-Headers @{
"authority"="analytics.google.com"
  "method"="POST"
  "path"="/g/collect?v=2&tid=G-P3LS8SG0QV&gtm=45je51d0v9104334479z8811255690za200zb811255690&_p=1737036064049&_gaz=1&gcd=13l3l3l3l1l1&npa=0&dma=0&tag_exp=101925629~102067555~102067808~102081485~102123608~102198178&cid=1576233481.1715610718&ul=en-us&sr=2560x1440&uaa=x86&uab=64&uafvl=Microsoft%2520Edge%3B131.0.2903.146%7CChromium%3B131.0.6778.265%7CNot_A%2520Brand%3B24.0.0.0&uamb=0&uam=&uap=Windows&uapv=15.0.0&uaw=0&are=1&pae=1&frm=0&pscdl=noapi&_s=12&sid=1737036028&sct=18&seg=1&dl=https%3A%2F%2Fwww.finra.org%2Ffinra-data%2Ffixed-income%2Fcorp-and-agency&dr=https%3A%2F%2Fwww.finra.org%2Ffinra-data%2Ffixed-income%2Fabout-cna-data&dt=Corporate%20and%20Agency%20Bonds%20%7C%20FINRA.org&en=Timer_30sec&_c=1&_et=13408&tfd=30593"
  "scheme"="https"
  "accept"="*/*"
  "accept-encoding"="gzip, deflate, br, zstd"
  "accept-language"="en-US,en;q=0.9,fr-FR;q=0.8,fr;q=0.7"
  "origin"="https://www.finra.org"
  "priority"="u=1, i"
  "referer"="https://www.finra.org/"
  "sec-ch-ua"="`"Microsoft Edge`";v=`"131`", `"Chromium`";v=`"131`", `"Not_A Brand`";v=`"24`""
  "sec-ch-ua-mobile"="?0"
  "sec-ch-ua-platform"="`"Windows`""
  "sec-fetch-dest"="empty"
  "sec-fetch-mode"="no-cors"
  "sec-fetch-site"="cross-site"
}
