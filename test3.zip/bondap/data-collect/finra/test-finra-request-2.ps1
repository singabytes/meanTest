$output_file = ".\dump-finra\trade-histo1"

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$session.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
$session.Cookies.Add((New-Object System.Net.Cookie("AppSession", "cec96a07-5342-4c7d-928e-99ed7d022ab8", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_TSVRDQEJ0X", "GS1.1.1713282798.1.1.1713283439.0.0.0", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_60020H86NR", "GS1.1.1715524406.2.1.1715524862.0.0.0", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_MX9MQ535Z4", "GS1.1.1715524563.2.1.1715526857.0.0.0", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_0469QZC1C3", "GS1.1.1715525932.5.1.1715526861.0.0.0", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_gcl_au", "1.1.211125516.1737036155", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_gid", "GA1.2.1160935674.1737036155", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_fbp", "fb.1.1737036155104.707653569390312240", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "8EqOMubW_l4fE6ynQHIumSPlgv24s5Gv0.Cb9UAaxwk-1737043447-1.0.1.1-EIWdHRkO8lRim7.yWO6.6.t6WseKLtOSv3.TbuhXLkCS_rs8geh8dIOSPR1Pe8scd.zZZp1twtkbDofiIBuSXw", "/", ".ddwa.finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("XSRF-TOKEN", "c2652b8e-6b92-4b6c-956c-7b5acd057f90", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_cfuvid", "lAzgIw9lalkOWShw5YrebY0kejZQWx280L1O_vJ.JUA-1737043450137-0.0.1.1-604800000", "/", ".services-dynarep.ddwa.finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("ABTastySession", "mrasn=&lp=https%253A%252F%252Fwww.finra.org%252Ffinra-data%252Ffixed-income%252Fcorp-and-agency", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("ABTasty", "uid=83crttyjcfz5yv9v&fst=1737036154841&pst=1737036154841&cst=1737043459560&ns=2&pvt=14&pvis=9&th=", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_PJ6P8VS89P", "GS1.2.1737043460.2.1.1737043545.0.0.0", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga", "GA1.2.2037239204.1737036155", "/", ".finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("__cf_bm", "sivk1lyDShT081V5jtcrLFEp.Q26fYwG8TeWBUZ9O58-1737043542-1.0.1.1-fW5gzFquc2OcI8wIHDJCzpuKdC_hQu8.NGUjIJS.aoxx8UPc6TteU5GNv1ISxR_fBrw21BFM3f6ieDP4OnU4kg", "/", ".services-dynarep.ddwa.finra.org")))
$session.Cookies.Add((New-Object System.Net.Cookie("_ga_P3LS8SG0QV", "GS1.1.1737043460.3.1.1737043605.60.0.0", "/", ".finra.org")))
Invoke-WebRequest -UseBasicParsing -Uri "https://services-dynarep.ddwa.finra.org/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencyTradeHistory" `
-Method "POST" `
-WebSession $session `
-Headers @{
"authority"="services-dynarep.ddwa.finra.org"
  "method"="POST"
  "path"="/public/reporting/v2/data/group/FixedIncomeMarket/name/CorporateAndAgencyTradeHistory"
  "scheme"="https"
  "accept"="application/json, text/plain, */*"
  "accept-encoding"="gzip, deflate, br, zstd"
  "accept-language"="en-US,en;q=0.9,fr;q=0.8"
  "origin"="https://www.finra.org"
  "priority"="u=1, i"
  "referer"="https://www.finra.org/"
  "sec-ch-ua"="`"Google Chrome`";v=`"131`", `"Chromium`";v=`"131`", `"Not_A Brand`";v=`"24`""
  "sec-ch-ua-mobile"="?0"
  "sec-ch-ua-platform"="`"Windows`""
  "sec-fetch-dest"="empty"
  "sec-fetch-mode"="cors"
  "sec-fetch-site"="same-site"
  "x-xsrf-token"="c2652b8e-6b92-4b6c-956c-7b5acd057f90"
} `
-OutFile $output_file `
-ContentType "application/json" `
-Body "{`"fields`":[`"issueSymbolIdentifier`",`"issuerName`",`"tradeExecutionDate`",`"reportedTradeVolume`",`"lastSalePrice`",`"lastSaleYield`",`"tradeExecutionTime`",`"tradeModifierCode`",`"tradeModifier2Code`",`"specialPriceFlag`",`"isAsof`",`"reportingPartySideCode`",`"reportingPartyTypeCode`",`"contraPartyTypeCode`",`"tradeStatus`",`"remunerationIndicator`",`"atsFlag`",`"cusip`"],`"dateRangeFilters`":[{`"fieldName`":`"tradeExecutionDate`",`"startDate`":`"2025-01-14`",`"endDate`":`"2025-01-17`"}],`"domainFilters`":[],`"compareFilters`":[{`"fieldName`":`"issueSymbolIdentifier`",`"fieldValue`":`"MMM4544488`",`"compareType`":`"EQUAL`"}],`"multiFieldMatchFilters`":[],`"orFilters`":[],`"aggregationFilter`":null,`"sortFields`":[`"-tradeExecutionDate`",`"-tradeExecutionTime`"],`"limit`":5000,`"offset`":0,`"delimiter`":null,`"quoteValues`":false}"