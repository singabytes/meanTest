import json 
import os
import logging
import sys
import csv
from datetime import datetime
from pymongo import MongoClient

import sys
sys.path.insert(0, r'C:\\Users\\Patrick\\GitHub\\bondap\\data-collect\\metaData\\')

import bond_metadata

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler('parse_finra_to_mongo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

def extract_instruments(date_string = '20200101'):
    
    if date_string == '20200101':
        now = datetime.now()
        date_string = now.strftime("%Y%m%d")

    path = rf'C:\Users\Patrick\GitHub\bondap\data-collect\finra\dump-finra\{date_string}'
    dir_list = os.listdir(path)

    logging.info(f'Processing file in {path}')

    count_total_instruments = 0

    # dict to store all instrument data
    all_data = {}

    for file in dir_list:
        full_name = path + '\\' + file
        logging.info(f'Processing {full_name}')
        with open(full_name, 'r',encoding='utf-8') as file:
            text = file.read().replace('\n', '')

        text = text.replace('data":"[{', 'data":[{')
        text = text.replace('}]"}}', '}]}}')
        text = text.replace('\\','')
        data = json.loads(text)
        
        #check number of instruments
        instruments_from_request = data['returnBody']['headers']['Record-Total']
        all_instrument_data = data['returnBody']['data']
        count_instruments = 0
        if int(instruments_from_request[0]) > 0: # instrument found in request
            for instrument_data in all_instrument_data:
                instrument_data['timestamp'] = data['returnBody']['headers']['Date'][0]
                # save in dictionary
                all_data[instrument_data['cusip']] = instrument_data
                count_instruments = count_instruments + 1

        logging.info(f'File {full_name} has {count_instruments} matching request size : {instruments_from_request}')

        count_total_instruments = count_total_instruments + count_instruments

    logging.info(f'Total number of instrument = {count_total_instruments}')

    return {'date': date_string, 'instruments': all_data, 'total_instrument': count_total_instruments}


def extract_with_metadata(date_string = '20200101'):

    if date_string == '20200101':
        now = datetime.now()
        date_string = now.strftime("%Y%m%d")

    finra_data = extract_instruments(date_string)

    # Get metadata 
    all_metadata = bond_metadata.get_bond_metadata(False)

    # Add metadata to the finra bond if possible
    

if __name__ == "__main__":
    date = '20241204'
    data = extract_instruments(date)
    print(data['date'])
    print(len(data['instruments'].keys()))
    print(data['total_instrument'])
    
    keys_list = list(data['instruments'].keys())
    key = keys_list[0]
    print(data['instruments'][key])



    #all Cusip
    array2Save = []
    for cusip in data['instruments'].keys():
        tmp = {}
        for tag in data['instruments'][cusip]:
            #print(tag, data['instruments'][cusip][tag])
            tmp[tag] = data['instruments'][cusip][tag]
        array2Save.append(tmp)

    #count1 = 0
    #count2 = 0
    #for i in array2Save:
    #    count1 = count1 + 1
    #    if i['lastTradeDate'] == '2024-10-22':
    #        count2 = count2 + 1
    #print(count1)
    #print(count2)

    #with open(f'c:\\temp\\list_finra-{date}.json', 'w', newline='') as jsonfile:
    #    json.dump(array2Save, jsonfile, indent=4)

'''
INSTRUMENT DATA :

'cusip' = 'M0152VAB9'
'is144A' = 'N'
'moodyRatingDate' = '2018-04-03'
'issueSymbolIdentifier' = 'ANZ3764948'
'issuerName' = 'ABU DHABI NATL ENERGY CO PJSC'
'priceChangeNumber' = -1.746
'standardAndPoorsRating' = None
'standardAndPoorsRatingDate' = '2018-06-18'
'isCallable' = 'N'
'couponRate' = 6.5
'maturityDate' = '2036-10-27'
'couponType' = None
'productSubTypeCode' = 'CORP'
'nextCallDate' = None
'lastTradeDate' = '2024-10-16'
'isConvertible' = 'N'
'moodysRating' = None
'isPerpetual' = None
'traceGradeCode' = 'H'
'lastSaleYield' = None
'priceChangePercent' = -1.5
'industryGroup' = None
'lastSalePrice' = 114.645
'''
