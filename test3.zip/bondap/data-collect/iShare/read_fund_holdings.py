import csv
import json 
from pymongo import MongoClient

# encoding utf-8-sig remove the werid char prefix : ['\ufeffiShares Core U.S. Aggregate Bond ETF']
with open(r'C:\Users\Patrick\GitHub\bondap\data-collect\iShare\dump-iShare\None\AGG-None.csv', mode='r', encoding='utf-8-sig') as file:
    csv_reader = csv.reader(file)
    
    name = next(csv_reader) #iShares Core U.S. Aggregate Bond ETF
    fund_holdings_date = ' '.join(next(csv_reader)) #Fund Holdings as of,"Dec 09, 2024"
    inception_date = ' '.join(next(csv_reader)) #Inception Date,"Sep 22, 2003"
    share_outstanding = ' '.join(next(csv_reader)) #Shares Outstanding,"1,221,600,000.00"
    
    read_holdings = False

    all_data = [] 

    for row in csv_reader:
        
        if read_holdings:
            # ignore odd lines
            if len(row) != len(header):
                continue            
            tmp = {}
            for i in range(0, len(header)):
                tmp[header[i]] = row[i]
            all_data.append(tmp)

        if row[0] == 'Name':
            header = row
            read_holdings = True

#json_data = json.dumps(all_data, indent=4)
    
mongo_dict = {}
mongo_dict['fund_name'] = name
mongo_dict['fund_holdings_date'] = fund_holdings_date
mongo_dict['inception_date'] = inception_date
mongo_dict['share_outstanding'] = share_outstanding
mongo_dict['underlyings'] = all_data

cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = cluster['bond']
collection = db['logs_finra']
# Upsert: Insert if not exists, or update if exists
result = collection.update_one(
    {"fund_name": mongo_dict["fund_name"]},  # Query to check if the document exists
    {"$set": mongo_dict},          # Update operation
    upsert=True                       # Set upsert to True
)
