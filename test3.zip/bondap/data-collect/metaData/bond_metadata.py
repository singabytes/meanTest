import csv
from pymongo import MongoClient

def csv_to_dict(file_path):
    with open(file_path, mode='r', encoding='utf-8-sig') as file:
        csv_reader = csv.DictReader(file)
        data = [row for row in csv_reader]
    return data

def find_duplicates(input_list):
    seen = set()
    duplicates = set()
    for item in input_list:
        if item in seen:
            duplicates.add(item)
        else:
            seen.add(item)
    return list(duplicates)

def get_bond_metadata(bond_id_key = 'ISIN', check_data = False):
    # key is the key in the dictionary (ISIN, CUSIP, ESMP)

    files = [1,2,3,4,6,7,8,9]

    all_data = []
    for f in files:
        file_path = rf'.\data-collect\metaData\dump\document-esmp-{f}.txt'
        tmp_dict = csv_to_dict(file_path)
        all_data = all_data + tmp_dict

    if check_data:
        # Check if we have duplicates + empty isin
        tmp_all_isin = []
        tmp_empty_isin = []
        for i in all_data:
            if i['ISIN'] != '':
                tmp_all_isin.append(i['ISIN'])
        if i['ISIN'] == '':
            tmp_empty_isin
 
        duplicates = find_duplicates(tmp_all_isin)
        print('Duplicate ISIN')
        print(duplicates)

    # Transform dict => {'bond_key': key set in the fonction call, 'metadata': metadata}
    bond_metadata = {}
    for metadata in all_data:
        if metadata[bond_id_key] != '':
            bond_metadata[metadata[bond_id_key]] = metadata
    
    return bond_metadata

if __name__ == "__main__":
    
    print('Pull bonds per ISIN')
    all_metadata = get_bond_metadata('ISIN', False)
    print(all_metadata['XS2627121259'])

    print('\n')
    print('Pull bonds per ESMP')
    all_metadata = get_bond_metadata('ESMP', False)
    print(all_metadata['1018323916'])

    print('\n')
    print('Pull bonds per CUSIP')
    all_metadata = get_bond_metadata('CUSIP', False)
    print(all_metadata['R6961PAA7'])



{'MarketSector': 'CORP', 'ESMP': '1018323916', 'ISIN': 'XS2627121259', 'CUSIP': '', 'ACID': 'DBT02273321', 'PTaxID': '6166', 
 'PreferredInstrumentIdType': 'ESMP', 'PreferredInstrumentId': '1018323916', 'IssuerName': 'FERROVIE DELLO STATO ITALIANE SPA', 
 'ProductType': 'BOND', 'SDSID': '10309127', 'IsSovereignIssuer': 'FALSE', 'Description': 'FERROV 4 1/8 05/23/29', 'Currency': 'EUR', 
 'CountryOfRisk': 'IT', 'CountryCurrency': 'EUR', 'IsLocalCcyProduct': 'TRUE', 'SecurityType': 'MEDIUM-TERM-NOTE', 'CouponType': 'FIX', 
 'CalculationType': 'STREET CONVENTION', 'CalculationTypeNumber': '1', 'CollateralType': 'SUN', 'IssuerIndustryGroup': 'TRAN', 'IssuerIndustrySector': 'IND', 
 'IssuerIndustrySubGroup': 'TRRA', 'IssuerIndustry': 'TRRA', 'IsInflationLinked': 'FALSE', 'IsCallable': 'FALSE', 'IsPutable': 'FALSE', 'IsConvertible': 'FALSE', 
 'IsFloater': 'FALSE', 'IsFixToFloat': 'FALSE', 'IsCovered': 'FALSE', 'IsCpnStepupFlt': 'FALSE', 'TaxStatusCode': 'FSE', 'IsCallDiscrete': 'TRUE', 'IsPutDiscrete': 'TRUE', 
 'IsSinkable': 'FALSE', 'IsInDefault': 'FALSE', 'ParValue': '100', 'IssueStatus': 'Active Security', 'MaturityDate': '05/23/2029', 'NoAnalytics': 'FALSE', 'CalledDate': '', 
 'CurrentBaseIndex': '', 'ProductSubType': '', 'RecoveryOption': '', 'InflationIndexName': '', 'InflationLinkedType': '', 'SEDOL': 'BRRF761', 'CallCount': '', 'OptionType': '', 
 'LastCallDate': '', 'Identifier': '', 'Vintage': '', 'CreditRating': '', 'BondClassification': '', 'BondSubClassification': '', 'RIC': '', 'FundAssetClass': '', 'FundStrategy': '', 
 'FundObjective': '', 'FundManager': '', 'FundAdmin': '', 'GlobalPrimaryESMP': '', 'IsPurged': '', 'IssueIndustryGroup': '', 'DerivedProductType': '', 'PutCount': '', 'EODBatch': '', 
 'LastPutDate': '', 'RefIndex': '', 'IndustryGroup': '', 'IsCallDiscreet': '', 'IsPutDiscreet': '', 'MuniType': '', 'HasCreditRisk': ''}