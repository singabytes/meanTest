import QuantLib as ql
import utils

class FixedRateBond:
    
    def __init__(self, symbol=None, cusip=None, issue_date=None, maturity_date=None, settlement_days=None, coupon_rate=None, coupon_type=None, option_dates=None, option_types=None, option_prices=None):
        self.symbol = symbol if symbol is not None else 'na'
        self.cusip = cusip if cusip is not None else 'na'
        self.issue_date = issue_date if issue_date is not None else ql.Date(1,1,2000) # ql.Date(1,1,2024)
        self.maturity_date = maturity_date if maturity_date is not None else ql.Date(1,1,2000) # ql.Date(1,1,2024)
        self.settlement_days = settlement_days if settlement_days is not None else 1 # 1
        self.coupon_rate = coupon_rate if coupon_rate is not None else 0 # 0.0575
        self.accrual_convention = ql.ModifiedFollowing
        self.rule_cashflow_generation = ql.DateGeneration.Backward
        self.end_of_month = False
        self.compounding = ql.Compounded
        self.frequency = ql.Semiannual
        self.tenor = ql.Period(self.frequency)
        self.calendar = ql.UnitedStates(ql.UnitedStates.NYSE)
        self.day_count = ql.Thirty360(ql.Thirty360.ISMA)
        self.redemption_amount = 100.
        self.coupon_type = 'FXPV'
    
    def construct_from_mongodoc(self, document):
    #{'cusip': 'U2100VAB9', 'is144A': 'N', 'moodyRatingDate': '2023-07-31', 'issueSymbolIdentifier': 'TRP5628529', 
    # 'issuerName': 'COLUMBIA PIPELINES OPER CO LLC', 'priceChangeNumber': -0.24779, 'standardAndPoorsRating': None, 
    # 'standardAndPoorsRatingDate': None, 'isCallable': 'N', 'couponRate': 0.0, 'maturityDate': '2033-11-15', 
    # 'couponType': 'FXPV', 'productSubTypeCode': 'CORP', 'nextCallDate': None, 'lastTradeDate': '2024-09-04', 
    # 'isConvertible': 'N', 'moodysRating': 'Baa1', 'isPerpetual': None, 'traceGradeCode': 'I', 'lastSaleYield': None, 
    # 'priceChangePercent': -0.23, 'industryGroup': None, 'lastSalePrice': 106.03221, 'timestamp': 'Fri, 27 Sep 2024 21:00:04 GMT'}
        error = 0
        try:
            self.symbol = document['issueSymbolIdentifier']
            error = error + 1 #1
            self.cusip = document['cusip']
            error = error + 1 #2
            #print(document['maturity'])
            temp = utils.convert_yyymmdd_to_ql(document['maturityDate'])
            error = error + 1 #3
            self.maturity_date = temp
            error = error + 1 #4
            self.coupon_rate = float(document['couponRate']) / 100.
            error = error + 1 #5
            self.coupon_type = document['couponType']
            error = error + 1 #6
            self.latest_sale_price = float(document['lastSalePrice'])
            error = error + 1 #7
            if document['lastSaleYield'] is None:
                self.latest_sale_yield = -99
            else:   
                self.latest_sale_yield = float(document['lastSaleYield'])
            error = error + 1 #8
            self.issue_date = ql.Date(1,1,2020)
        except(Exception):
            print(f'Error while building bond from mongodoc - error = {error}')
            
    def get_coupon_schedule(self):
        coupon_schedule = ql.Schedule(self.issue_date,
                               self.maturity_date, self.tenor, ql.NullCalendar(),
                               ql.Unadjusted, self.accrual_convention,
                               self.rule_cashflow_generation, self.end_of_month)
        return coupon_schedule
    
    def get_analytics(self, calc_date, quote_price, curve):
        results = {}
        calc_date = ql.Date(27,9,2024)
        settle_date = ql.Date(28,9,2024)
        ql.Settings.instance().evaluationDate = calc_date
        
        #ts_handle = ql.YieldTermStructureHandle(curve)
    
        #FixedRateBond self, Integer settlementDays, Real faceAmount, Schedule schedule, DoubleVector coupons, 
        #DayCounter paymentDayCounter, BusinessDayConvention paymentConvention=QuantLib::Following, 
        # Real redemption=100.0, Date issueDate=Date(), Calendar paymentCalendar=Calendar(), 
        # Period exCouponPeriod=Period(), Calendar exCouponCalendar=Calendar(), 
        # BusinessDayConvention exCouponConvention=Unadjusted, bool exCouponEndOfMonth=False) -> FixedRateBond
        fixedRateBond = ql.FixedRateBond(self.settlement_days, self.redemption_amount, 
                                         self.get_coupon_schedule(), [self.coupon_rate], self.day_count,
                                         self.accrual_convention, 100.0, self.issue_date, self.calendar)

        try:
            bond_yield = fixedRateBond.bondYield(quote_price,
                                    self.day_count,
                                    ql.Simple, #ql.Compounded,
                                    ql.Annual)#ql.Semiannual)
        except:
            bond_yield = -999
            
        results['yield_to_maturity'] = bond_yield

        return results
    

# TEST
if __name__ == "__main__":

    document = {'cusip':'00440EAH0B','symbol':'CB3668145','issuerName':'ACE INA HLDGS INC','coupon_type':'fix','coupon_rate':6.7,'maturity':'2036-05-15','latest_sale_price':118.06,'latest_sale_yield':4.564753}
    #document = {'cusip':'002824AV2','symbol':'ABT','issuerName':'ABBOTT','coupon_type':'fix','coupon_rate':6,'maturity':'2039-04-01','latest_sale_price':116.00,'latest_sale_yield':4.487026}

    fixed_bond = FixedRateBond()
    fixed_bond.construct_from_mongodoc(document)
    res = fixed_bond.get_analytics(ql.Date(29,8,2024), document['latest_sale_price'], 0)
    print(res)