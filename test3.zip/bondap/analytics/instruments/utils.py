import QuantLib as ql

def convert_yyymmdd_to_ql(date_stg):
        tmp = date_stg
        day = tmp.split('-')[2]
        if day[0] == '0':
            day = day[1]
        month = tmp.split('-')[1]
        if month[0] == '0':
            month = month[1]
        year = tmp.split('-')[0]
        return ql.Date(int(day), int(month), int(year))