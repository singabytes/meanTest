import QuantLib as ql
import analytics.instruments.utils as utils

class CallableFixedBond:
    
    def __init__(self, symbol=None, cusip=None, issue_date=None, maturity_date=None, settlement_days=None, coupon_rate=None, coupon_type=None, option_dates=None, option_types=None, option_prices=None):
        self.symbol = symbol if symbol is not None else 'na'
        self.cusip = cusip if cusip is not None else 'na'
        self.issue_date = issue_date if issue_date is not None else ql.Date(1,1,2000) # ql.Date(1,1,2024)
        self.maturity_date = maturity_date if maturity_date is not None else ql.Date(1,1,2000) # ql.Date(1,1,2024)
        self.settlement_days = settlement_days if settlement_days is not None else 1 # 1
        self.coupon_rate = coupon_rate if coupon_rate is not None else 0 # 0.0575
        self.option_dates = option_dates if option_dates is not None else [] # [ql.Date(15,9,2024)]
        self.option_types = option_types if option_types is not None else [] # ['Call']
        self.option_prices = option_prices if option_prices is not None else [] # [1000000.0]
        self.accrual_convention = ql.ModifiedFollowing
        self.rule_cashflow_generation = ql.DateGeneration.Backward
        self.end_of_month = False
        self.compounding = ql.Compounded
        self.frequency = ql.Semiannual
        self.tenor = ql.Period(self.frequency)
        self.calendar = ql.UnitedStates(ql.UnitedStates.NYSE)
        self.day_count = ql.Thirty360(ql.Thirty360.ISMA)
        self.redemption_amount = 100.
        self.coupon_type = 'FXPV'
    
    def construct_from_mongodoc(self, document):
        try:
            self.symbol = document['symbol']
            self.cusip = document['cusip']
            print(document['maturity'])
            temp = utils.convert_yyymmdd_to_ql(document['maturity'])
            self.maturity_date = temp
            self.coupon_rate = float(document['coupon_rate']) / 100.
            self.coupon_type = document['coupon_type']
            self.latest_sale_price = float(document['latest_sale_price'])
            self.latest_sale_yield = float(document['latest_sale_yield'])
            self.issue_date = ql.Date(1,1,2024)
        except(Exception):
            print('Error while building bond from mongodoc')
            
    def get_coupon_schedule(self):
        coupon_schedule = ql.Schedule(self.issue_date,
                               self.maturity_date, self.tenor, self.calendar,
                               self.accrual_convention, self.accrual_convention,
                               self.rule_cashflow_generation, self.end_of_month)
        return coupon_schedule
        
    def get_call_schedule(self):
        if len(self.option_dates) == 0:
            return ql.CallabilitySchedule()
        call_schedule = ql.CallabilitySchedule()
        for date in range(0, len(self.option_dates)):
            callability_price = ql.BondPrice(self.option_prices[date], ql.BondPrice.Clean)
            call_schedule.append(ql.Callability(callability_price, self.option_types[date], self.option_dates[date]))
        return call_schedule
    
    def get_analytics(self, calc_date, quote_price, curve):
        calc_date = ql.Date(29,8,2024)
        settle_date = ql.Date(30,8,2024)
        ql.Settings.instance().evaluationDate = calc_date
        
        ts_handle = ql.YieldTermStructureHandle(curve)
    
        bond = ql.CallableFixedRateBond(self.settlement_days,
                                        self.redemption_amount,
                                        self.get_coupon_schedule(),
                                        [self.coupon_rate],
                                        self.day_count,
                                        ql.Following,
                                        self.redemption_amount,
                                        self.issue_date,
                                        self.get_call_schedule())

        a = 0.1
        sigma = 0.27
        grid_points = 100
        model = ql.HullWhite(ts_handle, a, sigma)
        engine = ql.TreeCallableFixedRateBondEngine(model, grid_points)
        bond.setPricingEngine(engine)

        bond_oas = bond.OAS(quote_price,
                            ts_handle,
                            self.day_count,
                            self.compounding,
                            self.frequency)

        bond_yield = bond.bondYield(quote_price,
                                    self.day_count,
                                    ql.Simple(), #self.compounding,
                                    ql.Annual) #self.frequency)
        
        return [bond_yield, bond_oas]
    
    