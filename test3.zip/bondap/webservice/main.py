from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from flasgger import Swagger
from pymongo import MongoClient

app = Flask(__name__)
api = Api(app)
swagger = Swagger(app)

cluster = MongoClient('mongodb+srv://patrick:JP3HgWeDQTBQWqaO@cluster0.krjea.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = cluster['bond']
collection = db['bond_static_data']

class BondResource(Resource):
    def get(self):
        """
        Get all bonds
        ---
        responses:
          200:
            description: A list of bonds
        """
        all_bonds = list(collection.find({}))
        
        # remove key _id as value Object cannot be serialized
        for items in all_bonds:
            if '_id' in items:
                del items['_id']
        
        all_bonds = all_bonds[0:500]
        return all_bonds, 200

class BondItemResource(Resource):
    def get(self, bond_id):
        """
        Get a specific bond (ex bond_id = N00927DA3)
        ---
        parameters:
          - in: path
            name: bond_id
            type: string
            required: true
        responses:
          200:
            description: Details of the requested bond
          404:
            description: Bond not found
        """
        bond = list(collection.find({'cusip': f'{bond_id}'}))
        print(bond)
        if not bond:
            return {'message': 'Bond not found'}, 404     
        else:
            # remove key _id as value Object cannot be serialized
            for items in bond:
                if '_id' in items:
                    del items['_id']
            return bond, 200
        

# API routes
api.add_resource(BondResource, '/bond')
api.add_resource(BondItemResource, '/bond/<string:bond_id>')

if __name__ == '__main__':
    #app.run(debug=True)
    app.run(host='0.0.0.0', port=5000, debug=True)