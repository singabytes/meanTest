import cv2
import qrcode
import hashlib
import os
import shutil
from pyzbar.pyzbar import decode
from qreader import QReader

path_root = 'D:\\temp\\'
path_frame_folder = path_root + 'frames-9\\'
filename = path_frame_folder + '1100.png'

# CV2 OR PYZBAR
print('Processing file ', filename)
img = cv2.imread(filename)
#cv2
#detect = cv2.QRCodeDetector()
#value, points, straight_qrcode = detect.detectAndDecode(img)
#print(value)
#pyzbar                 
barcodes = decode(img)
print(barcodes)
if len(barcodes) != 0:
    value = barcodes[0].data.decode()
    print(value.encode('utf-8'))

# QREADER
print('Processing file QReader', filename)
qreader = QReader(model_size='s')
# Get the image that contains the QR code
image = cv2.cvtColor(cv2.imread(filename), cv2.COLOR_BGR2RGB)
# Use the detect_and_decode function to get the decoded QR data
decoded_text = qreader.detect_and_decode(image=image)
print(decoded_text[0])