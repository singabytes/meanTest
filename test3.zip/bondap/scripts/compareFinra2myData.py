import csv

path = 'C:\\Users\\Patrick\\GitHub\\data\\'

all_isin_mydata = set()
all_isin_finra = set()

# my data
filename = [1, 2, 3, 4, 5, 6, 7, 8]

old_number = 0
for f in filename:
    with open(f'{path}document-esmp-{f}.txt', mode ='r') as file:
        csvFile = csv.reader(file)
        for lines in csvFile:
                all_isin_mydata.add(lines[3]) # CUSIP
    delta = len(all_isin_mydata) - old_number
    old_number = len(all_isin_mydata)
    print(f, len(all_isin_mydata), delta)

#finra
path = 'C:\\temp\\'
filename = 'list_cusip.csv'

with open(f'{path}{filename}', mode ='r') as file:
    csvFile = csv.reader(file)
    for lines in csvFile:
        all_isin_finra.add(lines[0]) # CUSIP

print(filename, len(all_isin_finra))

#compare
print('comparison')
print(f'sample element mydata = {list(all_isin_mydata)[100]}')
print(f'sample element finra  = {list(all_isin_finra)[100]}')
print(f'len elements mydata   = {len(all_isin_mydata)}')
print(f'len elements finra    = {len(all_isin_finra)}')
common_elements = all_isin_mydata.intersection(all_isin_finra)
print(f'len element in common = {len(common_elements)}')
common_elements = all_isin_finra.intersection(all_isin_mydata)
print(f'len element in common = {len(common_elements)}')
#print(common_elements)

# element in mydata but not in finra
print('element in mydata but not in finra')
one_not_two = set(all_isin_mydata).difference(all_isin_finra)
print(one_not_two)
print('element in finra but not in mydata')
two_not_one = set(all_isin_finra).difference(all_isin_mydata)
print(two_not_one)
f = open('finrabutnotinmydata.txt', 'w')
for i in two_not_one:
    f.write(i + '\n')
f.close()