This is the prototype for the page showing the strategy selection for the user


### to compile 


npm install


### to start


npm start