# Test requestBuilder 

## Compilation

Dans le repertoire : npm install

Apres le npm install, prendre le fichier show-hint.js dans le folder fix et le copier dans node_modules/codemirror/addon/show-hint.js (le nouveau fichier show-hint contient le fix pour speedup l'affichage, limitation au 1000iere entrees)

### Build mode dev

Dans le repertoire : npm start

Ca lance un server web de test :

Ouvrir [http://localhost:8080](http://localhost:8080) 

### Build mode prod 

Le mode production est environ 3 fois plus rapide au niveau du remplissage de la 
fenetre de autocompletion - le truc lent c'est l'affichage de toutes les lignes 
par example affichage complet pour le cheval = +50000 lignes !

Dans le repertoire : npm run-script build

### Deployerle site en mode production

Deployer le repertoire "public" dans un serveur web

### Serveur web rapide

Pour demarrer un serveur web rapide (si on en a pas)

npm -g http-server

node http-server (a demarrer dans le repertoire public)

puis ouvrir [http://localhost:8080/index.html](http://localhost:8080/index.html) 

