module.exports = {
    entry: [ './src/App.tsx' ],
    output: {
      path: __dirname + '/public',
      filename: 'build/app.js'
    },
    resolve: {
      extensions: ['.ts', '.tsx', '.js']
    },
    module: {
      rules: [
        { 
            test: /\.tsx?$/, 
            loaders: ['awesome-typescript-loader']
        },
        {
            test: /\.less$/,
            loader: "style-loader!css-loader!less-loader"
        },
        { test: /\.css$/, loader: "style-loader!css-loader" },
        {
            test: /\.pegjs$/,
            loader: "pegjs-loader"
        },
        {
          test: /\.exec\.js$/,
          use: [ 'script-loader' ]
        }
      ]
    }
  }