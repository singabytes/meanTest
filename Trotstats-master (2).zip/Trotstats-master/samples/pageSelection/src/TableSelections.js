import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Tooltip from '@material-ui/core/Tooltip';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import PureTinyLineCharts from './PureTinyLineCharts'
import TinyBarCharts from './TinyBarCharts'
import Avatar from '@material-ui/core/Avatar';


const useStyles = makeStyles({
  root: {
    width: '100%',
    overflowX: 'auto',
  },
  table: {
    minWidth: 650,
  },
  space: {
    lineHeight: '2px',
  },
  icone: {
    width: '3em',
  },
  numeric: {
    fontSize: 'medium',
  },
  divleft: {
    float: 'left',
    verticalAlign: 'middle',
    textAlign: 'center',
    marginRight: '10px',
    marginTop: '8px',
  },
  gagnant: {
    backgroundColor: "#3F51B5",
  },
  place: {
    backgroundColor: "#3F6AB5",
  },

 
});

const data = [
  {"id":1,"code":"ERA","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"up","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-5.8","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":2,"code":"TTT","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-10.8","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":3,"code":"POE","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"9.1","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":4,"code":"LAO","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"up","dernierJeu":3,"pari":"SIMPLE_GAGNANT","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"5.2","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":5,"code":"XXD","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_GAGNANT","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-2.8","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":6,"code":"SED","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"up","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-2.1","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":7,"code":"FRT","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_GAGNANT","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"6.7","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":8,"code":"DFG","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"9.2","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":9,"code":"SRV","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"up","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-1.3","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":10,"code":"JFR","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"up","dernierJeu":3,"pari":"SIMPLE_PLACE","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"-9.3","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":11,"code":"AQF","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"creation":"2019-11-23 11:18","dernierGain":12,"progression":"down","dernierJeu":3,"pari":"SIMPLE_GAGNANT","gestion":"MASSE_EGALE","nombreTicket":"16","pourcentageReussite":"50.0","solde":"8.4","rendement":"136.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]}
 ];

function clickit(callbackFunction, data) {
  callbackFunction(data)
}

export default function TableSelections(props) {
  const classes = useStyles();

  return (
    <Paper className={classes.root}>
     <Typography className={classes.title} style={{marginLeft:'15px', marginTop:'10px;'}} variant="h6" id="tableTitle">
          Stratégies
        </Typography>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell style={{marginLeft:'55px'}}><b>Code</b></TableCell>
            <TableCell align="center"><b>Pari</b></TableCell>
            <TableCell align="center"><b>Nombre paris</b></TableCell>
            <TableCell align="center"><b>Réussite (%)</b></TableCell>
            <TableCell align="center"><b>Rde (%)</b></TableCell>
            <TableCell align="center"><b>Gain (€)</b></TableCell>
            <TableCell align="center"><b>Tendance</b></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map(row => (
            <TableRow key={row.name} onClick={() => clickit(props.callbackFunction, {'id':row.id, 'code':row.code})} >
              
              <TableCell component="th" scope="row">
              <div className={classes.divleft}>
                <img src={"/images/" + row.backtestDTO[0].progression + ".png"}></img>
              </div>
              <div className={classes.space}>
                <h3>{row.code}</h3>
              </div>
              </TableCell>
              
              {(row.backtestDTO[0].pari == 'SIMPLE_PLACE') && (
                    <TableCell align="center"><Avatar variant="square" className={classes.place}>PL</Avatar>   </TableCell>
              )}
              {(row.backtestDTO[0].pari == 'SIMPLE_GAGNANT') && (
                    <TableCell align="center"><Avatar variant="square" className={classes.gagnant}>G</Avatar>   </TableCell>
              )}

              
              <TableCell align="center"><span className={classes.numeric}>{row.backtestDTO[0].nombreTicket}</span></TableCell>
              <TableCell align="center">
              <img className={classes.icone} src={"/images/70.png"}></img>
              </TableCell>
              <TableCell align="center"><span className={classes.numeric}>{row.backtestDTO[0].rendement}</span></TableCell>
              {(row.backtestDTO[0].solde >= 0) && (
                    <TableCell align="center"><span className={classes.numeric} style={{color:"green"}}>
                      {row.backtestDTO[0].solde}</span></TableCell>
              )}
              {(row.backtestDTO[0].solde < 0) && (
                    <TableCell align="center"><span className={classes.numeric}  style={{color:"red"}}>
                      {row.backtestDTO[0].solde}</span></TableCell>
              )}
              <TableCell align="center"><div align="center"><TinyBarCharts data={row.backtestDTO[0].evolution.bilan}/></div></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
}