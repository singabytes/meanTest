 interface Expression {
    conditionType?: "OU" | "ET";
    category?: string;
    operator?: string;
    value?: string;
    expressions?:Expression[];    
}

export default Expression;