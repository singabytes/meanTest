import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import TinyBarCharts from './TinyBarCharts'
import Avatar from '@material-ui/core/Avatar';
import Rating from '@material-ui/lab/Rating';
import Tooltip from '@material-ui/core/Tooltip';
import TinyPieCharts from './TinyPieCharts';



const useStyles = makeStyles({

  table: {
    cursor: "pointer",
    minWidth: 650,
  },
  space: {
    lineHeight: '2px',
  },
  saut:{
    marginBottom: '1em',
    
    
  },
  numeric: {
    fontSize: 'medium',
  },
  divleft: {
    float: 'left',
    verticalAlign: 'middle',
    textAlign: 'center',
    marginRight: '10px',
    marginTop: '8px',
  },
  gagnant: {
    backgroundColor: "#3F51B5",
  },
  place: {
    backgroundColor: "#3F6AB5",
  },
  codeSelection:{
    fontSize: "1.2em",
  },
  separe:{
    borderLeftStyle: "outset",
    borderLeftWidth: "0.1em",
  },

  separeTop:{
    borderLeftStyle: "outset",
    borderLeftWidth: "0.1em",
    borderTopStyle: "outset",
    borderTopWidth: "0.1em",
  },

  separeLeftRight:{
    borderLeftStyle: "outset",
    borderLeftWidth: "0.1em",
    borderRightStyle: "outset",
    borderRightWidth: "0.1em",
  },

  separeLeftRightTop:{
    borderLeftStyle: "outset",
    borderLeftWidth: "0.1em",
    borderRightStyle: "outset",
    borderRightWidth: "0.1em",
    borderTopStyle: "outset",
    borderTopWidth: "0.1em",
  },

  invisible:{
    backgroundColor: "#FAFAFA",
  },
  title: {
    flex: '1 1 100%',
  },
});



const data = [
  {"id":1,"code":"S-0001","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"progression":"up","pari":"SIMPLE_PLACE","score":"1","pourcentageReussite":58,"solde":"-5.8","rendement":"36.8","solde_scope":"2.3","rendement_scope":"10.2","evolution":{"bilan":[{"win":"1"},{"win":"1"},{"win":"-1"},{"win":"1"},{"win":"1"},{"win":"1"},{"win":"-1"},{"win":"1"},{"win":"-1"}]}}]},
  {"id":2,"code":"S-0452","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"progression":"down","pari":"SIMPLE_GAGNANT","score":"3","pourcentageReussite":23,"solde":"10.8","rendement":"2.5","solde_scope":"-4.8","rendement_scope":"26.1","evolution":{"bilan":[{"win":"1"},{"win":"1"},{"win":"1"},{"win":"1"},{"win":"1"},{"win":"1"},{"win":"-1"},{"win":"1"},{"win":"-1"}]}}]},
 ];

function clickit(callbackFunction, data) {
  callbackFunction(data)
}

export default function TableSelections(props) {
  const classes = useStyles();

  return (
   <div>
    
  
  
      <Table className={classes.table} size='small'>
        <TableHead>

        <TableRow>
        <TableCell className={classes.invisible}></TableCell> 
        <TableCell align="center" className={classes.separeTop}><b>Indicateur</b> </TableCell> 
        <TableCell align="center" className={classes.separeTop} colSpan={3}><b>Performance</b> </TableCell> 
        <TableCell align="center" className={classes.separeLeftRightTop} colSpan={3}><b>Tendance</b> </TableCell> 
        </TableRow>

          <TableRow>
            <TableCell className={classes.separe}  align="center"><b>Pari</b></TableCell>
            <TableCell className={classes.separe} align="center">
          
          <b>Score </b>
            </TableCell>
            <TableCell className={classes.separe} align="center"><b>Réussite (%)</b></TableCell>
            <TableCell className={classes.separe} align="center"><b>Gain (€)</b></TableCell>
            <TableCell className={classes.separe} align="center"><b>Rde. (%)</b></TableCell>
            <TableCell className={classes.separe} align="center"><b>Gain (€)</b> </TableCell>
            <TableCell className={classes.separe} align="center"><b>Rde. (%)</b></TableCell>
            <TableCell className={classes.separeLeftRight} align="center">
      
            <b>Historique</b>
            
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
        {data.map(row => (
            <TableRow key={row.name} onClick={() => clickit(props.callbackFunction, {'id':row.id, 'code':row.code})} >
              
            
              
              {(row.backtestDTO[0].pari == 'SIMPLE_PLACE') && (
                    <TableCell className={classes.separe} align="center"><center><Avatar variant="square" className={classes.place}>PL</Avatar> </center></TableCell>
              )}
              {(row.backtestDTO[0].pari == 'SIMPLE_GAGNANT') && (
                    <TableCell className={classes.separe} align="center"><center><Avatar variant="square" className={classes.gagnant}>G</Avatar></center></TableCell>
              )}

              
              <TableCell className={classes.separe} align="center"><Rating name="read-only" value={row.backtestDTO[0].score} readOnly /></TableCell>
              <TableCell className={classes.separe} align="center">
                <div align="center"> <TinyPieCharts data={row.backtestDTO[0].pourcentageReussite} /></div>
              </TableCell>
              {(row.backtestDTO[0].solde >= 0) && (
                    <TableCell className={classes.separe}  align="center">
                    
                    <span className={classes.numeric} style={{color:"green",marginRight:"5px", fontSize:"1.4em"}}>
                      {row.backtestDTO[0].solde}</span>
                      </TableCell>
              )}
              {(row.backtestDTO[0].solde < 0) && (
                    <TableCell className={classes.separe} align="center">
                  
                    <span className={classes.numeric}  style={{color:"#d62728",marginRight: "5px", fontSize:"1.4em"}}>
                      {row.backtestDTO[0].solde}</span>
                     
                      </TableCell>
              )}

              
                    <TableCell className={classes.separe} align="center">
                    
                   <span className={classes.numeric} style={{color:"#7B7B7B", fontSize:"1.4em"}}>
                      {row.backtestDTO[0].rendement}</span>
                      </TableCell>
              

                {(row.backtestDTO[0].solde_scope >= 0) && (
                    <TableCell className={classes.separe} align="center">
                    
                    <span className={classes.numeric} style={{color:"green",marginRight:"5px", fontSize:"1.4em"}}>
                      {row.backtestDTO[0].solde_scope}</span>
                      </TableCell>
              )}
              {(row.backtestDTO[0].solde_scope < 0) && (
                    <TableCell className={classes.separe} align="center">
                  
                    <span className={classes.numeric}  style={{color:"#d62728",marginRight: "5px", fontSize:"1.4em"}}>
                      {row.backtestDTO[0].solde_scope}</span>
                     
                      </TableCell>
              )}

                  <TableCell className={classes.separe} align="center">
                    
                    <span className={classes.numeric} style={{color:"#7B7B7B", fontSize:"1.4em"}}>
                       {row.backtestDTO[0].rendement_scope}</span>
                       </TableCell>
               

              <TableCell className={classes.separeLeftRight} align="center"><div align="center"><TinyBarCharts data={row.backtestDTO[0].evolution.bilan}/></div></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
    </div>
  );
}