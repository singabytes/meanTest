import React from 'react';
import ReactFilterBox, {SimpleResultProcessing,Expression} from "react-filter-box";
import data from "./data/data";
import "react-filter-box/lib/react-filter-box.css"

export default class PageRecherche extends React.Component {
 
  constructor(props){
    super(props);
    this.state = {
        data: data
    }

     this.options = [
        {
            columnField: "Hippodrome.Nom",
            type:"selection"
        },
        {
            columnField: "Course.Nom",
            type:"selection"
        },
        {
            columnField: "Driver.Nom",
            type:"selection"
        },
    ];
}

onParseOk(expressions){
    console.log('parse ok');
}

render(){
    var rows = this.state.data;
    return <div className="main-container"> 
    <ReactFilterBox 
                query={this.state.query}
                data={data}
                options={this.options}
                onParseOk={this.onParseOk.bind(this)}
                 />
      </div>
}
}
