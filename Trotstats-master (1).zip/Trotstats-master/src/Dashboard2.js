import React from 'react';
import clsx from 'clsx';
import { makeStyles, useTheme, Theme, createStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import CssBaseline from '@material-ui/core/CssBaseline';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import SearchIcon from '@material-ui/icons/Search';
import MailIcon from '@material-ui/icons/Mail';
import { Switch, Route, Link, BrowserRouter, Redirect } from "react-router-dom"
import TableSelections from './TableSelections'
import TestBarChart from './TestBarChart'
import TablePariHistorique from './TablePariHistorique'
import PageRechercher from './PageRechercher'
import StarsIcon from '@material-ui/icons/Stars';
import FavoriteIcon from '@material-ui/icons/Favorite';
import ExtensionIcon from '@material-ui/icons/Extension';
import DnsIcon from '@material-ui/icons/Dns';
import PageInformation from './PageInformation'
import PageDetail from './PageDetail'

const drawerWidth = 240;

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
    },
    appBar: {
      zIndex: theme.zIndex.drawer + 1,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
    },
    appBarShift: {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    menuButton: {
      marginRight: 36,
    },
    hide: {
      display: 'none',
    },
    drawer: {
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: 'nowrap',
    },
    drawerOpen: {
      width: drawerWidth,
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    drawerClose: {
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      overflowX: 'hidden',
      width: theme.spacing(7) + 1,
      [theme.breakpoints.up('sm')]: {
        width: theme.spacing(9) + 1,
      },
    },
    toolbar: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
    },
    content: {
      flexGrow: 1,
      padding: theme.spacing(3),
    },
  }),
);

export default function Dashboard2() {
  const classes = useStyles();
  const theme = useTheme();
  // variable for the drawer
  const [open, setOpen] = React.useState(false);
  // showTableParis = true > show TableParis else show TableSelection
  // click on one TableSelection row to go to showTableParis
  const [showTableParis, setShowTableParis] = React.useState(false);
  // dataTableParis = data passed from TableSelection to TableParis
  const [dataTableParis, setDataTableParis] = React.useState(null);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const callbackSelectionTable = (data) => {
    //console.log('callbackSelectionTable : data = ' + data)
    (showTableParis ? setShowTableParis(false) : setShowTableParis(true));
    setDataTableParis(data);
  }

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            className={clsx(classes.menuButton, {
              [classes.hide]: open,
            })}
          >
            <MenuIcon />
          </IconButton>
          <img width='75' src={"/images/logo3.png"}></img>
         
        </Toolbar>
      </AppBar>
      <BrowserRouter>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
        open={open}
      >
        <div className={classes.toolbar}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
          </IconButton>
        </div>
        <Divider />
        <List>
          {/*<ListItem button component={Link} to={ "/info"}>
            <ListItemIcon><DnsIcon/></ListItemIcon>
            <ListItemText primary="Informations"></ListItemText>
      </ListItem>*/}
          <ListItem button component={Link} to={ "/favori"}>
            <ListItemIcon><ExtensionIcon/></ListItemIcon>
            <ListItemText primary="Les sélections"></ListItemText>
          </ListItem>
          <ListItem button component={Link} to={ "/rechercher"}>
            <ListItemIcon><SearchIcon/></ListItemIcon>
            <ListItemText primary="Rechercher"></ListItemText>
          </ListItem>
          
        </List>
        <Divider />
       
      </Drawer>
      <main className={classes.content}>
        <div className={classes.toolbar} />
        <Switch>
        <Route exact path='/favori' render={() => {
          if (!showTableParis) { return <TableSelections callbackFunction={callbackSelectionTable} /> }
          else { return <Redirect to='/Paris' /> } 
        }} />
        <Route exact path='/rechercher' render={() => {
          if (!showTableParis) { return <PageRechercher/> }
          else { return <Redirect to='/Paris' /> } 
        }} />
        <Route exact path='/Paris' render={() => {
          if (showTableParis) { return <PageDetail callbackFunction={callbackSelectionTable} data={dataTableParis}/> }
          else { return <Redirect to='/favori' /> } 
        }} />
        {/*<TablePariHistorique callbackFunction={callbackSelectionTable} data={dataTableParis}/>*/}
        <Route exact path='/info' render={() => {
          if (!showTableParis) { return <PageInformation/> }
          else { return <Redirect to='/favori' /> } 
        }} />
        </Switch>
      </main>
      </BrowserRouter>
    </div>
  );
}
