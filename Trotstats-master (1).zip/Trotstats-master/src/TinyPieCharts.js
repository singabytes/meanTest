import React, { PureComponent } from 'react';
import {
  PieChart, Pie, Sector, Cell,
} from 'recharts';

const data = [
  { name: 'Group A', value: 25 }, { name: 'Group B', value: 85 },
];

const COLORS = ['#3F51B5', '#BDBDBD'];

export default class TinyPieCharts extends PureComponent {
  static jsfiddleUrl = 'https://jsfiddle.net/alidingling/pb1jwdt1/';

  render() {
    return (
      <PieChart width={100} height={60}>
        <Pie dataKey="value" startAngle={180} cy={40} endAngle={0} paddingAngle={2} data={data} outerRadius={40} fill="#8884d8">
        {
          	data.map((entry, index) => <Cell fill={COLORS[index % COLORS.length]}/>)
          }
         </Pie> 
      </PieChart>
    );
  }
}