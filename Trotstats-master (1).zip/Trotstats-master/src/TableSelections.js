import React from 'react';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import TinyBarCharts from './TinyBarCharts'
import Avatar from '@material-ui/core/Avatar';
import Rating from '@material-ui/lab/Rating';
import HelpIcon from '@material-ui/icons/Help';
import Tooltip from '@material-ui/core/Tooltip';
import TinyPieCharts from './TinyPieCharts';
import ExtensionIcon from '@material-ui/icons/Extension';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

const useStyles = makeStyles({
  root: {
    width: '100%',
    overflowX: 'auto',
  },
  table: {
    minWidth: 650,
  },
  space: {
    lineHeight: '2px',
  },
  saut:{
    marginBottom: '1em',
  },
  numeric: {
    fontSize: 'medium',
  },
  divleft: {
    float: 'left',
    verticalAlign: 'middle',
    textAlign: 'center',
    marginRight: '10px',
    marginTop: '8px',
  },
  gagnant: {
    backgroundColor: "#3F51B5",
  },
  place: {
    backgroundColor: "#3F6AB5",
  },
  codeSelection:{
    fontSize: "1.2em",
  }

});

const HtmlTooltip = withStyles((theme: Theme) => ({
  tooltip: {
    backgroundColor: '#f5f5f9',
    color: 'rgba(0, 0, 0, 0.87)',
    maxWidth: 220,
    fontSize: theme.typography.pxToRem(12),
    border: '1px solid #dadde9',
  },
}))(Tooltip);

const data = [
  {"id":1,"code":"ERA","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"progression":"up","pari":"SIMPLE_PLACE","score":"1","pourcentageReussite":"50.0","solde":"-5.8","rendement":"36.0","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
  {"id":2,"code":"TTT","utilisateur":"information@dataturf.fr","requete":"Driver.Nom\u003d\"E. RAFFIN\"","description":"Les engagements du driver E. RAFFIN","creation":"15/11/2019","backtestDTO":[{"id":1,"idSelection":1,"progression":"down","pari":"SIMPLE_GAGNANT","score":"3","pourcentageReussite":"12.0","solde":"-10.8","rendement":"2.5","evolution":{"bilan":[{"gains":"-272.41"},{"gains":"-271.88"},{"gains":"-270.64"},{"gains":"-271.64"},{"gains":"-272.64"},{"gains":"-273.64"},{"gains":"-274.64"},{"gains":"-275.64"},{"gains":"-274.81"},{"gains":"-275.81"},{"gains":"-271.66"},{"gains":"-270.76"},{"gains":"-271.76"},{"gains":"-271.04"},{"gains":"-272.04"},{"gains":"-273.04"},{"gains":"-274.04"},{"gains":"-273.76"},{"gains":"-274.76"},{"gains":"-274.26"},{"gains":"-275.26"},{"gains":"-273.52"},{"gains":"-268.94"},{"gains":"-269.94"},{"gains":"-269.05"}]}}]},
 ];

function clickit(callbackFunction, data) {
  callbackFunction(data)
}

export default function TableSelections(props) {
  const classes = useStyles();

  return (
   <div>
    <Card className={classes.saut}>
    <CardContent>
    <ListItem button>
            <ListItemIcon><ExtensionIcon/></ListItemIcon>
            <ListItemText primary="Les sélections"></ListItemText>
          </ListItem>
    </CardContent>
  </Card>
    
   <Paper className={classes.root}>
      <Table className={classes.table} aria-label="simple table">
        <TableHead>
          <TableRow>
          <TableCell style={{marginLeft:'55px'}}></TableCell>
            <TableCell align="center"><b>Pari</b></TableCell>
            <TableCell align="center">
            <HtmlTooltip
            placement="right-start" 
        title={
          <React.Fragment>
            <Typography color="inherit">Score <i>DTF</i></Typography>
            <em>{"Indication sur la qualité de la sélection"}</em>  <u>{'+ voir documentation + '}</u>
            
          </React.Fragment>
        }
      >
          <b>Score <HelpIcon style={{ fontSize: 15 }}/></b>
      </HtmlTooltip>
            
            
            </TableCell>
            <TableCell align="center"><b>Réussite (%)</b></TableCell>
            <TableCell align="center"><b>Rde (%)</b></TableCell>
            <TableCell align="center"><b>Gain (€)</b></TableCell>
            <TableCell align="center"><b>Tendance</b></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
        {data.map(row => (
            <TableRow key={row.name} onClick={() => clickit(props.callbackFunction, {'id':row.id, 'code':row.code})} >
              
              <TableCell component="th" scope="row">
              <div className={classes.divleft}>
                <img src={"/images/" + row.backtestDTO[0].progression + ".png"}></img>
              </div>
              <div className={classes.space}>
                <h3 className={classes.codeSelection}>{row.code}</h3>
              </div>
              </TableCell>
              
              {(row.backtestDTO[0].pari == 'SIMPLE_PLACE') && (
                    <TableCell align="center"><center><Avatar variant="square" className={classes.place}>PL</Avatar> </center></TableCell>
              )}
              {(row.backtestDTO[0].pari == 'SIMPLE_GAGNANT') && (
                    <TableCell align="center"><center><Avatar variant="square" className={classes.gagnant}>G</Avatar></center></TableCell>
              )}

              
              <TableCell align="center"><Rating name="read-only" value={row.backtestDTO[0].score} readOnly /></TableCell>
              <TableCell align="center">
                <TinyPieCharts/>
              </TableCell>
              <TableCell align="center"><span className={classes.numeric}>{row.backtestDTO[0].rendement}</span></TableCell>
              {(row.backtestDTO[0].solde >= 0) && (
                    <TableCell align="center"><span className={classes.numeric} style={{color:"green"}}>
                      {row.backtestDTO[0].solde}</span></TableCell>
              )}
              {(row.backtestDTO[0].solde < 0) && (
                    <TableCell align="center"><span className={classes.numeric}  style={{color:"red"}}>
                      {row.backtestDTO[0].solde}</span></TableCell>
              )}
              <TableCell align="center"><div align="center"><TinyBarCharts data={row.backtestDTO[0].evolution.bilan}/></div></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
    </Paper>
    </div>
  );
}