import React from 'react';
import './App.css';
import Dashboard2 from './Dashboard2';
import LoginPage from './LoginPage'

const AppContext = React.createContext();

// function App() {
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      apiKey: null 
    }
  }

  handleCallbackLogin = (data) => {
    console.log('callback : data = ' + data)
    this.setState( { 'apiKey': data } )
  }

  render() {
    return (
      <div className="App">
       { (this.state.apiKey == null) && (<LoginPage callbackFunction = { this.handleCallbackLogin }/>) }
       { (this.state.apiKey != null) && (<Dashboard2 apiKey = { this.state.apiKey }/>) } 
      </div>
    );
  }
}
export default App;
