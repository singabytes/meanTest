import React, { Component } from "react";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";

const TABLE_LIST = [
  { name: "1", nombre: 297 },
  { name: "2", nombre: 197 },
  { name: "3", nombre: 111 },
  { name: "4", nombre: 51 },
  { name: "5", nombre: 34 },
  { name: "6", nombre: 33 },
  { name: "7", nombre: 12 },
  { name: "8", nombre: 10 },
  { name: "9", nombre: 5 },
  { name: "10", nombre: 2 },
  { name: "11", nombre: 1 },
  { name: "12", nombre: 0 },
  { name: "13", nombre: 0 },
  { name: "14", nombre: 1 },
  { name: "15", nombre: 1 },
  { name: "16", nombre: 0 },
  { name: "17", nombre: 0 },
  { name: "18", nombre: 0 },
  { name: "19", nombre: 0 },
  { name: "20", nombre: 0 }
];

export default class Chart extends Component {
  state = {
    list: [...TABLE_LIST]
  };

  render() {
    const { list } = this.state;
    return (
      <BarChart
        width={600}
        height={300}
        data={list}
        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="nombre" fill="#8884d8" />
      </BarChart>
    );
  }
}