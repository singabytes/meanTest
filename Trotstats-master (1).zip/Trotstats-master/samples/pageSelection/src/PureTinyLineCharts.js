import React, { PureComponent } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';


export default class PureTinyLineCharts extends PureComponent {
  constructor(props) {
    super(props);
    }
  render() {
   
    return (
      <div>
      <LineChart width={250} height={40} data={this.props.data}>
        <Line type="monotone" dataKey="gains" stroke="#8884d8" dot={false}/>
      </LineChart>
      </div>
    );
  }
}
