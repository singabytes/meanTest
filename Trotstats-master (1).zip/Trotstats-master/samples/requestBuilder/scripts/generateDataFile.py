from sqlalchemy import create_engine
import pandas as pd

db_connection_str = 'mysql+pymysql://api:apimaster@vps36407.ovh.net/DTF'

path4files = './'

def sortArray(tmp):
    ret = []
    for i in tmp.values:
        ret.append(i[0])
    ret.sort()
    return ret

def writeToFile(f, where, what, i):
    try:
        f.write('"' + where + '" : "' + str(what[i]).replace('"', "'").strip() + '",\n')
    except:
        dummy = 0
    return 0  

print('Load data from SQL database')
db_connection = create_engine(db_connection_str)

hippodrome_nom = sortArray(pd.read_sql("SELECT DISTINCT(C_HIPPODROME) FROM COURSES", con=db_connection))
course_heure = sortArray(pd.read_sql("SELECT DISTINCT(C_HEURE) FROM COURSES", con=db_connection))
course_numero = sortArray(pd.read_sql("SELECT DISTINCT(C_NUM_COURSE) FROM COURSES", con=db_connection))
course_nom = sortArray(pd.read_sql("SELECT DISTINCT(C_COURSE) FROM COURSES", con=db_connection))
course_terrain = sortArray(pd.read_sql("SELECT DISTINCT(C_TERRAIN) FROM COURSES", con=db_connection))
course_discipline = sortArray(pd.read_sql("SELECT DISTINCT(C_DISCIPLINE) FROM COURSES", con=db_connection))
course_corde = sortArray(pd.read_sql("SELECT DISTINCT(C_CORDE) FROM COURSES", con=db_connection))
course_autostart = sortArray(pd.read_sql("SELECT DISTINCT(C_AUTOSTART) FROM COURSES", con=db_connection))
course_partant = sortArray(pd.read_sql("SELECT DISTINCT(C_PARTANT) FROM COURSES", con=db_connection))
course_recul = sortArray(pd.read_sql("SELECT DISTINCT(C_RECUL) FROM COURSES", con=db_connection))
course_amateur = sortArray(pd.read_sql("SELECT DISTINCT(C_AMATEUR) FROM COURSES", con=db_connection))
course_apprentis = sortArray(pd.read_sql("SELECT DISTINCT(C_APPRENTIS) FROM COURSES", con=db_connection))
course_piste = sortArray(pd.read_sql("SELECT DISTINCT(C_PISTE) FROM COURSES", con=db_connection))
course_categorie = sortArray(pd.read_sql("SELECT DISTINCT(C_CATEGORIE) FROM COURSES", con=db_connection))
course_distance = sortArray(pd.read_sql("SELECT DISTINCT(C_DISTANCE) FROM COURSES", con=db_connection))
course_allocation = sortArray(pd.read_sql("SELECT DISTINCT(C_ALLOCATION) FROM COURSES", con=db_connection))
course_quinte = sortArray(pd.read_sql("SELECT DISTINCT(QUINTE) FROM COURSES", con=db_connection))
driver_nom = sortArray(pd.read_sql("SELECT DISTINCT(P_DRIVER) FROM PARTANTS", con=db_connection))
entraineur_nom = sortArray(pd.read_sql("SELECT DISTINCT(P_ENTRAINEUR) FROM PARTANTS", con=db_connection))
trotteur_nom = sortArray(pd.read_sql("SELECT DISTINCT(P_TROTTEUR) FROM PARTANTS", con=db_connection))
trotteur_numero = sortArray(pd.read_sql("SELECT DISTINCT(P_NUM) FROM PARTANTS", con=db_connection))
trotteur_deferrage = sortArray(pd.read_sql("SELECT DISTINCT(P_DEF) FROM PARTANTS", con=db_connection))
trotteur_sexe = sortArray(pd.read_sql("SELECT DISTINCT(P_SEXE) FROM PARTANTS", con=db_connection))
trotteur_age = sortArray(pd.read_sql("SELECT DISTINCT(P_AGE) FROM PARTANTS", con=db_connection))
trotteur_poids = sortArray(pd.read_sql("SELECT DISTINCT(P_POIDS) FROM PARTANTS", con=db_connection))
trottteur_gain = sortArray(pd.read_sql("SELECT DISTINCT(P_GAIN) FROM PARTANTS", con=db_connection))
trotteur_cote = sortArray(pd.read_sql("SELECT DISTINCT(P_COTE) FROM PARTANTS", con=db_connection))
trotteur_estFavori = sortArray(pd.read_sql("SELECT DISTINCT(P_FAVO) FROM PARTANTS", con=db_connection))

print('Trotteur   = ', len(trotteur_nom))
print('Driver     = ', len(driver_nom))
print('Entraineur = ', len(entraineur_nom))
print('Course     = ', len(course_nom))
print('Hippodrome = ', len(hippodrome_nom))
print('Categorie  = ', len(course_categorie))
print('Distance   = ', len(course_distance))

f = open('../src/data/data.js', 'w')
f.write('var data = [\n')
for i in range(0, len(trotteur_nom) + 2000): # assumption max = Trotteur ~ 25000 + 2000 pour safety
    f.write('{\n')
    writeToFile(f, "Hippodrome.Nom", hippodrome_nom, i)
    writeToFile(f, "Course.Heure", course_heure, i)
    writeToFile(f, "Course.Numero", course_numero, i)
    writeToFile(f, "Course.Nom", course_nom, i)
    writeToFile(f, "Course.Terrain", course_terrain, i)
    writeToFile(f, "Course.Discipline", course_discipline, i)
    writeToFile(f, "Course.Corde", course_corde, i)
    writeToFile(f, "Course.Autostart", course_autostart, i)
    writeToFile(f, "Course.Partant", course_partant, i)
    writeToFile(f, "Course.Recul", course_recul, i)
    writeToFile(f, "Course.Amateur", course_amateur, i)
    writeToFile(f, "Course.Apprentis", course_apprentis, i)
    writeToFile(f, "Course.Piste", course_piste, i)
    writeToFile(f, "Course.Categorie", course_categorie, i)
    writeToFile(f, "Course.Distance", course_distance, i)
    writeToFile(f, "Course.Allocation", course_allocation, i)
    writeToFile(f, "Course.Quinte", course_quinte, i)
    writeToFile(f, "Driver.Nom", driver_nom, i)
    writeToFile(f, "Entraineur.Nom", entraineur_nom, i)
    writeToFile(f, "Trotteur.Nom", trotteur_nom, i)
    writeToFile(f, "Trotteur.Numero", trotteur_numero, i)
    writeToFile(f, "Trotteur.Deferrage", trotteur_deferrage, i)
    writeToFile(f, "Trotteur.Sexe", trotteur_sexe, i)
    writeToFile(f, "Trotteur.Age", trotteur_age, i)
    writeToFile(f, "Trotteur.Poids", trotteur_poids, i)
    writeToFile(f, "Trotteur.Gain", trottteur_gain, i)
    writeToFile(f, "Trotteur.Cote", trotteur_cote, i)
    #trotteur_estFavori
    f.write('},\n')
f.write(']\n')
f.write('export default data;\n')




# hippodrome.nom -- C_HIPPODROME
# hippodrome.estNational -- ??

# course.heure -- C_HEURE
# course.numero -- C_NUM_COURSE
# course.nom -- C_COURSE
# course.terrain -- C_TERRAIN
# course.discipline -- C_DISCIPLINE
# course.corde -- C_CORDE
# course.autostart -- C_AUTOSTART
# course.partant -- C_PARTANT
# course.recul -- C_RECUL
# course.amateur -- C_AMATEUR
# course.apprentis -- C_APPRENTIS
# course.piste -- C_PISTE
# course.categorie -- C_CATEGORIE
# course.distance -- C_DISTANCE
# course.allocation -- C_ALLOCATION
# course.quinte -- C_QUINTE

# driver.nom -- P_DRIER

# entraineur.nom -- P_ENTRAINEUR

# trotteur.nom -- P_TROTTEUR
# trotteur.numero -- P_NUM
# trotteur.deferrage -- P_DEF
# trotteur.sexe -- P_SEXE
# trotteur.age -- P_AGE
# trotteur.poids -- P_POIDS
# trottteur.gain -- P_GAIN
# trotteur.cote -- P_COTE
# trotteur.estFavori -- P_FAVO

