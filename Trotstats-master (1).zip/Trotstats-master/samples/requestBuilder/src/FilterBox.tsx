import * as React from 'react';
import * as _ from "lodash";

import data from "./data/data.js";

import ReactFilterBox, { AutoCompleteOption, SimpleResultProcessing, Expression } from "./components/react-filter-box/ReactFilterBox";

var request = [
    {
    "Categorie" : "ABY",
    "Operator" : "09:05",
    "Value" : "1"
    }];

export default class FilterBox extends React.Component<any, any> {
    
    options: AutoCompleteOption[];
    constructor(props: any) {
        super(props);
        
        this.state = {
            data: data,
            request: request // resultat = requete en mode json
        }

        this.options = [
        {    
            columnField : "Hippodrome.Nom",
            type: "selection"
        },
        {
            columnField : "Course.Heure",
            type: "selection"
        },
        {
            columnField : "Course.Numero",
            type: "selection"
        },
        {
            columnField : "Course.Nom",
            type: "selection"
        },
        {
            columnField : "Course.Terrain",
            type: "selection"
        },
        {
            columnField : "Course.Discipline",
            type: "selection"
        },
        {
            columnField : "Course.Corde",
            type: "selection"
        },
        {
            columnField : "Course.Autostart",
            type: "selection"
        },
        {
            columnField : "Course.Partant",
            type: "selection"
        },
        {
            columnField : "Course.Recul",
            type : "selection"
        },
        {
            columnField : "Course.Amateur",
            type : "selection"
        },
        {
            columnField : "Course.Apprentis",
            type: "selection"
        },
        {
            columnField : "Course.Piste",
            type: "selection"
        },
        {
            columnField : "Course.Categorie",
            type: "selection"
        },
        {
            columnField : "Course.Distance",
            type: "selection"
        },
        {
            columnField : "Course.Allocation",
            type: "selection"
        },
        {
            columnField : "Course.Quinte",
            type: "selection"
        },
        {
            columnField : "Driver.Nom",
            type: "selection"
        },
        {
            columnField : "Entraineur.Nom",
            type: "selection"
        },
        {
            columnField : "Trotteur.Nom",
            type: "selection"
        },
        {
            columnField : "Trotteur.Numero",
            type: "selection"
        },
        {
            columnField : "Trotteur.Deferrage",
            type: "selection"
        },
        {
            columnField : "Trotteur.Sexe",
            type: "selection"
        },
        {
            columnField : "Trotteur.Age",
            type: "selection"
        },
        {
            columnField : "Trotteur.Poids",
            type: "selection"
        },
        {
            columnField : "Trotteur.Gain",
            type: "selection"
        }
        ];
    }

    onParseOk(expressions: Expression[]) {
        console.log("onParseOk : call SimpleResultProcessing")
        var newData = new SimpleResultProcessing(this.options).process(data, expressions);
        this.setState({ data: newData });
        this.setState({ request: expressions });
        console.log("*** Output : request json format **")
        console.log(expressions);
        console.log(this.state.request);
    }

    render() {
        var rows = this.state.data;
        var request = this.state.request;
        return <div id="toto" className="main-container">
             <h3>Pour limiter le bombre d'entrees dans la popup autocomplete voir show-hint.js</h3>
             <h3>Le resultat est la requete en format json (voir console log : expressions)</h3>
            <ReactFilterBox
                query={this.state.query}
                data={data}
                options={this.options}
                onParseOk={this.onParseOk.bind(this)}
            />
            <h3> Nb Requete : { request.length }</h3>
            <ul>
                {request.map(item => {
                    return <li>{item.category}{item.operator}{item.value}</li>;
                })}
            </ul>
        </div>
    }
}