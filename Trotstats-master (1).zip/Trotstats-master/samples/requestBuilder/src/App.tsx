import * as React from 'react';
import * as ReactDOM from 'react-dom';

import "./components/react-filter-box/ReactFilterBox.less";
import "./App.less";

import FilterBox from "./FilterBox";
import NavBarResults from "./components/nav-bar/NavBarResults"

ReactDOM.render(
    <div>
    <h4>Test</h4>
    <FilterBox />
    <NavBarResults />
    </div>,
    document.getElementById('root')
);