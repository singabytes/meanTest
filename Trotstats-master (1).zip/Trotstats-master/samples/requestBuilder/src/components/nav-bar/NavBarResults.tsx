import * as React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import NavBar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';

import 'bootstrap/dist/css/bootstrap.css';

import Graph from '../Graph';
// import About from '../pages/About';
// import Contact from '../pages/Contact';
// import Status from '../pages/Status';
// import Prices from '../pages/Prices';
// import Stats from '../pages/Stats';

class NavBarResults extends React.Component {
  render() {
    return (
    <Router>
        <div>
          <NavBar bg="light" expand="xl">
            <NavBar.Brand>Results</NavBar.Brand>
            <Nav>
              <Link to="/graph">Graph (click ici)  </Link>
              <Link to="/table">Table (pas encore fait)</Link>
            </Nav>
          </NavBar>
          <Switch>
              <Route path='/graph' component={Graph} />
              {/* <Route path='/table' component={Table} /> */}
          </Switch>
        </div>
      </Router>
    );
  }
}
export default NavBarResults;
