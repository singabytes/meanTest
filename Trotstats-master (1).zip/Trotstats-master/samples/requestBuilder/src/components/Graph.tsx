import * as React from 'react';
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

import ReactEcharts from "echarts-for-react";

import testGraph1 from "../data/testGraph1";
import testGraph2 from "../data/testGraph2";
import testGraph3 from "../data/testGraph3";
import testGraph4 from "../data/testGraph4";

class Graph extends React.Component<any, any>{
  constructor(props: any) {
    super(props);
    
    this.state = {
        graph1 : testGraph1,
        graph2 : testGraph2,
        graph3 : testGraph3,
        graph4 : testGraph4
    }
  }

  getOption1 = () => ( this.state.graph1 );
  getOption2 = () => ( this.state.graph2 );
  getOption3 = () => ( this.state.graph3 );
  getOption4 = () => ( this.state.graph4 );

  render() {
    return (
      <div className="App">
        <h6>Utilise https://echarts.apache.org/examples/en/#chart-type-pie</h6>
        <Container>
          <Row>
            <Col><ReactEcharts option={this.getOption1()} style={{ height: 300 }} /></Col>
            <Col><ReactEcharts option={this.getOption2()} style={{ height: 400 }} /></Col>
            <Col><ReactEcharts option={this.getOption1()} style={{ height: 300 }} /></Col>
          </Row>
          <Row>
            <Col><ReactEcharts option={this.getOption3()} style={{ height: 300 }} /></Col>
            <Col><ReactEcharts option={this.getOption4()} style={{ height: 400 }} /></Col>
            <Col><ReactEcharts option={this.getOption2()} style={{ height: 300 }} /></Col>
          </Row>
        </Container>
      </div>
    );
  }
}
export default Graph;
